const fs = require('fs');
const path = require('path');
const ts = require('../client/node_modules/typescript');

const sourceRoot = path.join(__dirname, '..', 'client', 'src');
const sourceFiles = [];

function collect(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) collect(fullPath);
    else if (/\.(jsx|js)$/.test(entry.name)) sourceFiles.push(fullPath);
  }
}

collect(sourceRoot);
const errors = [];

for (const filePath of sourceFiles) {
  const source = fs.readFileSync(filePath, 'utf8');
  const result = ts.transpileModule(source, {
    fileName: filePath,
    reportDiagnostics: true,
    compilerOptions: {
      jsx: ts.JsxEmit.ReactJSX,
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
    },
  });

  for (const diagnostic of result.diagnostics || []) {
    if (diagnostic.category === ts.DiagnosticCategory.Error) {
      errors.push({
        filePath: path.relative(path.join(__dirname, '..'), filePath),
        message: ts.flattenDiagnosticMessageText(diagnostic.messageText, ' '),
      });
    }
  }
}

if (errors.length) {
  console.error(`Frontend syntax check failed with ${errors.length} error(s):`);
  for (const error of errors) console.error(`- ${error.filePath}: ${error.message}`);
  process.exit(1);
}

console.log(`Frontend syntax check passed for ${sourceFiles.length} JavaScript/JSX files.`);
