# Project update: implementation and remaining checks

## Code changes included
- Transactional email through SMTP (Mailjet-compatible), including login OTP and password-reset OTP, staff email and enquiry replies.
- Sign-in supports email + password and email OTP only. Mobile/SMS OTP sign-in and its API routes have been removed. Student mobile number remains a contact/profile field only.
- Admin and Recruiter Email Center with role-scoped recipient list and send history.
- Enquiry reply composer in Admin, automatic Replied status after accepted send, enquiry reply history and new-enquiry notification setting.
- Homepage live previews and verified Placement Highlights section.
- Public Notices page, About page, responsive footer/map and Admin Website Settings.
- Baseline responsive safety CSS.

## Requires configuration before real use
1. Copy `server/.env.example` to `server/.env`.
2. Set MongoDB URI and JWT secret.
3. Configure Mailjet SMTP credentials and an allowed sender address.
5. Configure Cloudinary and Judge0 separately if those modules are used.

## Verification limitations
- Real email delivery, MongoDB writes, Cloudinary uploads, Gemini responses and Judge0 code execution require the owner's credentials and must be tested locally.
- A full production build and browser-based end-to-end testing were not run in this environment.
- Authentic KMV campus photos are not bundled; the About page links to the official KMV Placement Cell gallery.