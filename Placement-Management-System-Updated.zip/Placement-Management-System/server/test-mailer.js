require("dotenv").config({
  path: require("path").join(__dirname, ".env"),
});

const {
  verifyEmailConnection,
  sendEmail,
} = require("./utils/emailService");

async function testMailer() {
  const result = await verifyEmailConnection();

  if (!result.configured) {
    throw new Error(result.message);
  }
  if (!result.verified) {
    throw new Error(result.message || "SMTP connection could not be verified.");
  }

  console.log("SMTP connection verified successfully.");

  if (process.env.TEST_EMAIL) {
    const info = await sendEmail({
      to: process.env.TEST_EMAIL,
      subject: "Placement Management System - Test Email",
      text: "Mailjet SMTP test successful.",
      html: "<h2>Placement Management System</h2><p>Mailjet SMTP test successful.</p>",
    });
    console.log("Test email accepted by SMTP server.", info.messageId || "");
  } else {
    console.log("SMTP is verified. Add TEST_EMAIL=your-real-email@example.com to server/.env to send a test email.");
  }
}

testMailer().catch((error) => {
  console.error("Mailer test failed:", error.message);
  process.exitCode = 1;
});
