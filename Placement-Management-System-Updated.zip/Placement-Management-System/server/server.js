
const path = require("path");

// IMPORTANT: Load .env before importing controllers and routes.
require("dotenv").config({
  path: path.join(__dirname, ".env"),
});

const express = require("express");
const http = require("http");
const cors = require("cors");
const mongoose = require("mongoose");
const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");

const User = require("./models/User");

// Routes
const applicationRoutes = require("./routes/applicationRoutes");
const authRoutes = require("./routes/authRoutes");
const studentRoutes = require("./routes/studentRoutes");
const recruiterRoutes = require("./routes/recruiterRoutes");
const adminRoutes = require("./routes/adminRoutes");
const driveRoutes = require("./routes/placementDriveRoutes");
const profileRoutes = require("./routes/profileRoutes");
const publicRoutes = require("./routes/publicRoutes");
const announcementRoutes = require("./routes/announcementRoutes");
const resourceRoutes = require("./routes/resourceRoutes");
const successStoryRoutes = require("./routes/successStoryRoutes");
const notificationRoutes = require("./routes/notificationRoutes");
const resumeRoutes = require("./routes/resumeRoutes");
const resumePreviewRoutes = require("./routes/resumePreviewRoutes");
const resumeDraftRoutes = require("./routes/resumeDraftRoutes");
const resumeStudioRoutes = require("./routes/resumeStudioRoutes");
const aptitudeRoutes = require("./routes/aptitudeRoutes");
const advancedRoutes = require("./routes/advancedRoutes");
const careerRoutes = require("./routes/careerRoutes");
const privateFileRoutes = require("./routes/privateFileRoutes");
const reminderRoutes = require("./routes/reminderRoutes");
const staffMailRoutes = require("./routes/staffMailRoutes");

const app = express();
const server = http.createServer(app);

const PORT = Number(process.env.PORT || 5000);

const allowedOrigins = (
  process.env.CLIENT_URL || "http://localhost:5173"
)
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

// Socket.IO
const io = new Server(server, {
  cors: {
    origin: allowedOrigins,
    methods: ["GET", "POST", "PATCH", "PUT", "DELETE"],
    credentials: true,
  },
});

app.set("io", io);

// CORS
app.use(
  cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }

      return callback(new Error("Origin not allowed by CORS."));
    },
    credentials: true,
  })
);

// Request parsers
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

// Health check
app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Placement Management System API is running.",
    database:
      mongoose.connection.readyState === 1
        ? "connected"
        : "disconnected",
  });
});

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/student", studentRoutes);
app.use("/api/recruiter", recruiterRoutes);
app.use("/api/admin", adminRoutes);

app.use("/api/drives", driveRoutes);
app.use("/api/placement-drives", driveRoutes);

app.use("/api/profile", profileRoutes);
app.use("/api/applications", applicationRoutes);

app.use("/api/public", publicRoutes);
app.use("/api/announcements", announcementRoutes);
app.use("/api/resources", resourceRoutes);
app.use("/api/success-stories", successStoryRoutes);
app.use("/api/notifications", notificationRoutes);

app.use("/api/advanced", advancedRoutes);
app.use("/api/career", careerRoutes);
app.use("/api/files", privateFileRoutes);
app.use("/api/reminders", reminderRoutes);
app.use("/api/staff-mail", staffMailRoutes);
app.use("/api/resume", resumeRoutes);
app.use("/api/resume-preview", resumePreviewRoutes);
app.use("/api/resume-draft", resumeDraftRoutes);
app.use("/api/resume-studio", resumeStudioRoutes);
app.use("/api/aptitude", aptitudeRoutes);

// Invalid API route
app.use("/api", (req, res) => {
  return res.status(404).json({
    success: false,
    message: "API route not found.",
  });
});

// Central error handler
app.use((err, req, res, next) => {
  console.error("Server error:", err.message);

  if (res.headersSent) {
    return next(err);
  }

  if (err.message === "Origin not allowed by CORS.") {
    return res.status(403).json({
      success: false,
      message: "Request origin is not allowed.",
    });
  }

  return res.status(err.status || 500).json({
    success: false,
    message:
      process.env.NODE_ENV === "production"
        ? "An internal server error occurred."
        : err.message || "Internal server error.",
  });
});

// Authenticate Socket.IO connections
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth?.token;

    if (!token || !process.env.JWT_SECRET) {
      return next(new Error("Unauthorized socket connection."));
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.userId || decoded.id || decoded._id;

    const user = await User.findById(userId).select(
      "_id role isActive"
    );

    if (!user || user.isActive === false) {
      return next(new Error("Account is not active."));
    }

    socket.user = user;
    return next();
  } catch (error) {
    return next(new Error("Invalid socket authentication."));
  }
});

io.on("connection", (socket) => {
  const room = `user:${socket.user._id}`;

  socket.join(room);

  if (socket.user.role === "student") {
    socket.join(`student:${socket.user._id}`);
  }

  socket.on("disconnect", () => {
    console.log("Socket disconnected:", socket.id);
  });
});

// Graceful shutdown
let shuttingDown = false;

async function shutdown(signal) {
  if (shuttingDown) return;

  shuttingDown = true;
  console.log(`${signal} received. Shutting down server...`);

  server.close(async (error) => {
    try {
      io.close();

      if (mongoose.connection.readyState !== 0) {
        await mongoose.connection.close();
      }

      if (error) {
        console.error("HTTP shutdown error:", error.message);
        process.exitCode = 1;
      } else {
        console.log("Server shut down successfully.");
      }
    } catch (shutdownError) {
      console.error("Shutdown error:", shutdownError.message);
      process.exitCode = 1;
    }
  });
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

// Start server
async function startServer() {
  try {
    if (!process.env.MONGODB_URI) {
      throw new Error("MONGODB_URI is missing from server/.env.");
    }

    if (!process.env.JWT_SECRET) {
      throw new Error("JWT_SECRET is missing from server/.env.");
    }

    if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
      throw new Error("PORT must be a valid port number.");
    }

    // Check Cloudinary configuration without exposing credentials.
    console.log("Cloudinary environment check:", {
      cloudName: Boolean(process.env.CLOUDINARY_CLOUD_NAME),
      apiKey: Boolean(process.env.CLOUDINARY_API_KEY),
      apiSecret: Boolean(process.env.CLOUDINARY_API_SECRET),
    });

    await mongoose.connect(process.env.MONGODB_URI, {
      serverSelectionTimeoutMS: 10000,
    });

    console.log("MongoDB connected successfully.");

    server.listen(PORT, () => {
      console.log(`Placement Management System API running at http://localhost:${PORT}`);
      console.log(`Health check: http://localhost:${PORT}/api/health`);
      console.log("Authentication and application routes registered.");
      console.log("Resume routes registered.");
      require("./utils/scheduler").startSchedulers();
      console.log("Private file vault and reminder routes registered.");
    });
  } catch (error) {
    console.error("Server startup failed:", error.message);

    try {
      if (mongoose.connection.readyState !== 0) {
        await mongoose.connection.close();
      }
    } catch (closeError) {
      console.error("Database cleanup failed:", closeError.message);
    }

    process.exitCode = 1;
  }
}

startServer();
