
const cloudinary = require("cloudinary").v2;

// Read Cloudinary credentials from server/.env
const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
const apiKey = process.env.CLOUDINARY_API_KEY;
const apiSecret = process.env.CLOUDINARY_API_SECRET;

// Validate configuration without printing secret values.
const missingCredentials = [];

if (!cloudName) missingCredentials.push("CLOUDINARY_CLOUD_NAME");
if (!apiKey) missingCredentials.push("CLOUDINARY_API_KEY");
if (!apiSecret) missingCredentials.push("CLOUDINARY_API_SECRET");

if (missingCredentials.length > 0) {
  console.error(
    "Cloudinary configuration is incomplete. Missing:",
    missingCredentials.join(", ")
  );
} else {
  cloudinary.config({
    cloud_name: cloudName,
    api_key: apiKey,
    api_secret: apiSecret,
    secure: true,
  });

  console.log("Cloudinary configured successfully.");
}

module.exports = cloudinary;
