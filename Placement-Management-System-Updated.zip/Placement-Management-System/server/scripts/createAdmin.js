require("dotenv").config({ path: require("path").join(__dirname, "..", ".env") });
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("../models/User");

async function run() {
  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || "");
  const name = String(process.env.ADMIN_NAME || "KMV Placement Cell Admin").trim();

  if (!process.env.MONGODB_URI) throw new Error("MONGODB_URI is missing in server/.env");
  if (!email || !password) throw new Error("Set ADMIN_EMAIL and ADMIN_PASSWORD in server/.env first.");
  if (password.length < 6) throw new Error("ADMIN_PASSWORD must be at least 6 characters.");

  await mongoose.connect(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  const hashedPassword = await bcrypt.hash(password, 12);
  const user = await User.findOneAndUpdate(
    { email },
    {
      $set: {
        name,
        email,
        password: hashedPassword,
        role: "admin",
        phone: "",
        isActive: true,
        isEmailVerified: true,
      },
      $setOnInsert: { college: "Kanya Maha Vidyalaya, Jalandhar" },
    },
    { upsert: true, new: true, runValidators: true, setDefaultsOnInsert: true }
  );

  console.log(`Admin account is ready: ${user.email}`);
  console.log("You can now sign in with ADMIN_EMAIL and ADMIN_PASSWORD from server/.env.");
  await mongoose.connection.close();
}

run().catch(async (error) => {
  console.error("Admin setup failed:", error.message);
  try { await mongoose.connection.close(); } catch {}
  process.exit(1);
});
