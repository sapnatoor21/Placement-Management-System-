require('dotenv').config({path:require('path').join(__dirname,'..','.env')});
const mongoose=require('mongoose');
async function run(){
 if(!process.env.MONGODB_URI)throw new Error('MONGODB_URI is missing.');
 await mongoose.connect(process.env.MONGODB_URI);
 const collection=mongoose.connection.collection('applications');
 const indexes=await collection.indexes();
 for(const index of indexes){
  const keys=Object.keys(index.key||{});
  if(index.unique===true&&keys.length===1&&keys[0]==='studentId'){
   console.log(`Removing legacy unique index ${index.name} (studentId only).`);
   await collection.dropIndex(index.name);
  }
 }
 await collection.createIndex({studentId:1,driveId:1},{unique:true,name:'studentId_1_driveId_1'});
 console.log('Correct unique constraint is now studentId + driveId. A student can apply to different drives, once per drive.');
 await mongoose.disconnect();
}
run().catch(async e=>{console.error('Index migration failed:',e.message);try{await mongoose.disconnect();}catch{}process.exitCode=1;});
