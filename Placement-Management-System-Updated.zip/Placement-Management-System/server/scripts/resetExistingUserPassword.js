const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const readline = require("readline");
const User = require("../models/User");

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(question, (answer) => {
    rl.close();
    resolve(answer.trim());
  }));
}

function askHidden(question) {
  return new Promise((resolve, reject) => {
    if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== "function") {
      return ask(question).then(resolve, reject);
    }
    process.stdout.write(question);
    let value = "";
    const stdin = process.stdin;
    const onData = (chunk) => {
      for (const char of chunk.toString("utf8")) {
        if (char === "\u0003") {
          cleanup();
          process.stdout.write("\nCancelled.\n");
          reject(new Error("Cancelled"));
          return;
        }
        if (char === "\r" || char === "\n") {
          cleanup();
          process.stdout.write("\n");
          resolve(value);
          return;
        }
        if (char === "\u007f" || char === "\b") {
          value = value.slice(0, -1);
          process.stdout.write("\b \b");
        } else if (char >= " ") {
          value += char;
          process.stdout.write("*");
        }
      }
    };
    function cleanup() {
      stdin.removeListener("data", onData);
      stdin.setRawMode(false);
      stdin.pause();
    }
    stdin.setRawMode(true);
    stdin.resume();
    stdin.setEncoding("utf8");
    stdin.on("data", onData);
  });
}

async function main() {
  if (process.env.NODE_ENV === "production") {
    throw new Error("This local recovery utility is disabled in production.");
  }
  if (!process.env.MONGODB_URI) throw new Error("MONGODB_URI is missing from server/.env");

  const email = (await ask("Existing account email: ")).toLowerCase();
  if (!email || !email.includes("@")) throw new Error("Enter a valid account email.");

  const password = await askHidden("New password (minimum 8 characters; input hidden): ");
  if (password.length < 8) throw new Error("Password must contain at least 8 characters.");
  const confirm = await askHidden("Confirm new password: ");
  if (password !== confirm) throw new Error("Passwords do not match.");

  const approval = await ask(`Type RESET to change only the password for ${email}: `);
  if (approval !== "RESET") {
    console.log("No changes made.");
    return;
  }

  await mongoose.connect(process.env.MONGODB_URI);
  const user = await User.findOne({ email }).select("+password");
  if (!user) throw new Error("No existing account found for that email.");

  user.password = await bcrypt.hash(password, 10);
  await user.save();

  console.log(`Password updated for ${email}. Existing profile, role, applications and other data were not changed.`);
}

main()
  .catch((error) => {
    console.error("Password recovery failed:", error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    if (mongoose.connection.readyState !== 0) await mongoose.disconnect();
  });
