const express = require('express');
const mongoose = require('mongoose');
const Resource = require('../models/Resource');
const ResourceProgress = require('../models/ResourceProgress');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const upload = require('../middleware/upload');
const cloudinary = require('../config/cloudinary');
const streamifier = require('streamifier');
const router = express.Router();
const adminOnly = [protect, allowRoles('admin')];

router.get('/', async (req, res) => {
  try {
    const query = { isPublished: true };
    if (req.query.category && req.query.category !== 'All') query.category = req.query.category;
    if (req.query.search) query.$or = [{ title: { $regex: String(req.query.search), $options: 'i' } }, { description: { $regex: String(req.query.search), $options: 'i' } }];
    const resources = await Resource.find(query).select('-fileUrl').sort({ createdAt: -1 }).lean();
    res.json({ success: true, resources });
  } catch (error) { res.status(500).json({ success: false, message: 'Unable to load resources.' }); }
});

router.get('/my-progress', protect, allowRoles('student'), async (req,res)=>{
  const progress=await ResourceProgress.find({userId:req.user._id}).lean();
  res.json({success:true,progress});
});
router.put('/:id/progress', protect, allowRoles('student'), async (req,res)=>{
  if(!mongoose.isValidObjectId(req.params.id))return res.status(400).json({success:false,message:'Invalid resource ID.'});
  const resource=await Resource.findOne({_id:req.params.id,isPublished:true});
  if(!resource)return res.status(404).json({success:false,message:'Published resource not found.'});
  const update={};if(typeof req.body.bookmarked==='boolean')update.bookmarked=req.body.bookmarked;if(typeof req.body.completed==='boolean')update.completed=req.body.completed;
  const progress=await ResourceProgress.findOneAndUpdate({userId:req.user._id,resourceId:resource._id},{$set:update,$setOnInsert:{userId:req.user._id,resourceId:resource._id}},{new:true,upsert:true,runValidators:true});
  res.json({success:true,progress});
});

router.get('/:id/download', async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid resource ID.' });
    const existing = await Resource.findOne({ _id: req.params.id, isPublished: true });
    if (!existing) return res.status(404).json({ success: false, message: 'Resource not found.' });
    if (!/^https:\/\//i.test(existing.fileUrl)) return res.status(503).json({ success: false, message: 'The resource file URL is not configured.' });
    await Resource.updateOne({ _id: existing._id }, { $inc: { downloadCount: 1 } });
    return res.redirect(existing.fileUrl);
  } catch (error) { res.status(500).json({ success: false, message: 'Unable to download resource.' }); }
});
router.get('/manage/all', ...adminOnly, async (_req, res) => {
  const resources = await Resource.find({}).sort({ createdAt: -1 }).lean();
  res.json({ success: true, resources });
});
router.post('/upload', ...adminOnly, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'Choose a PDF or DOCX file to upload.' });
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) return res.status(503).json({ success: false, message: 'Cloudinary is not configured. Add the three CLOUDINARY variables to server/.env.' });
    const uploaded = await new Promise((resolve, reject) => {
      const stream = cloudinary.uploader.upload_stream({ resource_type: 'raw', folder: 'kmv-placement-resources', public_id: `${Date.now()}-${req.file.originalname.replace(/[^a-zA-Z0-9._-]/g, '-')}` }, (error, result) => error ? reject(error) : resolve(result));
      streamifier.createReadStream(req.file.buffer).pipe(stream);
    });
    const { title, description = '', category, isPublished = 'false' } = req.body;
    if (!title || !category) return res.status(400).json({ success: false, message: 'Resource title and category are required.' });
    const resource = await Resource.create({ title, description, category, fileType: req.file.mimetype, fileSize: `${(req.file.size / 1024 / 1024).toFixed(2)} MB`, fileUrl: uploaded.secure_url, isPublished: isPublished === 'true', createdBy: req.user._id });
    return res.status(201).json({ success: true, resource });
  } catch (error) {
    console.error('Resource upload failed:', error.message);
    return res.status(500).json({ success: false, message: 'Resource upload failed. Verify Cloudinary configuration and try again.' });
  }
});

router.post('/', ...adminOnly, async (req, res) => {
  try {
    const { title, description = '', category, fileType, fileSize = '', fileUrl, isPublished = false } = req.body;
    if (!title || !category || !fileType || !fileUrl || !/^https:\/\//i.test(fileUrl)) return res.status(400).json({ success: false, message: 'Title, category, file type and a valid HTTPS file URL are required.' });
    const resource = await Resource.create({ title, description, category, fileType, fileSize, fileUrl, isPublished: Boolean(isPublished), createdBy: req.user._id });
    res.status(201).json({ success: true, resource });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});
router.patch('/:id', ...adminOnly, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid resource ID.' });
  const allowed = ['title', 'description', 'category', 'fileType', 'fileSize', 'fileUrl', 'isPublished'];
  const update = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
  const resource = await Resource.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
  if (!resource) return res.status(404).json({ success: false, message: 'Resource not found.' });
  res.json({ success: true, resource });
});
router.delete('/:id', ...adminOnly, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid resource ID.' });
  const resource = await Resource.findByIdAndDelete(req.params.id);
  if (!resource) return res.status(404).json({ success: false, message: 'Resource not found.' });
  res.json({ success: true, message: 'Resource deleted.' });
});
module.exports = router;
