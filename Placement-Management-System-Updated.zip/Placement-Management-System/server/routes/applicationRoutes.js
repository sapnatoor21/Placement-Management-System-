
const express = require("express");
const mongoose = require("mongoose");

const Application = require("../models/Application");
const PlacementDrive = require("../models/PlacementDrive");
const User = require("../models/User");
const Notification = require("../models/Notification");
const StudentProfile = require("../models/StudentProfile");
const authMiddleware = require("../middleware/authMiddleware");
const { sendApplicationUpdate } = require("../utils/mailer");

const router = express.Router();

const STATUSES = Application.APPLICATION_STATUSES;

const TERMINAL_STATUSES = ["Selected", "Rejected", "Withdrawn"];

function isValidId(id) {
  return mongoose.isValidObjectId(id);
}

function isStaff(user) {
  return ["admin", "recruiter"].includes(user?.role);
}

function safeMessage(error, fallback) {
  if (error?.code === 11000) {
    return "You have already applied to this placement drive.";
  }
  return fallback;
}

function getStudentId(req) {
  return req.user?._id || req.userId;
}

// GET /api/applications/my-applications
router.get("/my-applications", authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({
        success: false,
        message: "Only students can view their applications here.",
      });
    }

    const applications = await Application.find({
      studentId: getStudentId(req),
    })
      .populate(
        "driveId",
        "companyName jobRole package ctc location applicationDeadline status"
      )
      .sort({ appliedAt: -1 })
      .lean();

    return res.json({ success: true, applications });
  } catch (error) {
    console.error("List applications:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to fetch applications.",
    });
  }
});

// POST /api/applications/apply/:driveId
router.post("/apply/:driveId", authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({
        success: false,
        message: "Only students can apply to placement drives.",
      });
    }

    const { driveId } = req.params;

    if (!isValidId(driveId)) {
      return res.status(400).json({ message: "Invalid placement drive ID." });
    }

    const drive = await PlacementDrive.findById(driveId);

    if (!drive || !drive.isActive || drive.status !== "Open") {
      return res.status(400).json({ success: false, message: "This placement drive is not currently open." });
    }

    const profile = await StudentProfile.findOne({ user: getStudentId(req) }).lean();
    if (!profile) return res.status(400).json({ success: false, message: "Complete your academic profile before applying." });
    if (drive.eligibleCourses?.length && !drive.eligibleCourses.includes(profile.course)) {
      return res.status(403).json({ success: false, message: "Your course does not match this drive's eligibility criteria." });
    }
    if (profile.currentCGPA === null || profile.currentCGPA === undefined || profile.currentCGPA === "") {
      return res.status(403).json({ success: false, message: "Please add your current CGPA in My Profile before applying." });
    }
    if (Number(profile.currentCGPA) < Number(drive.minCGPA || 0)) {
      return res.status(403).json({ success: false, message: `Minimum CGPA required for this drive is ${drive.minCGPA}. Your saved CGPA is ${profile.currentCGPA}.` });
    }
    if (Number(profile.backlogs || 0) > Number(drive.maxBacklogs || 0)) {
      return res.status(403).json({ success: false, message: `This drive allows up to ${drive.maxBacklogs || 0} active backlogs.` });
    }

    if (
      drive.applicationDeadline &&
      new Date(drive.applicationDeadline) < new Date()
    ) {
      return res.status(400).json({
        message: "The application deadline has passed.",
      });
    }

    const existing = await Application.findOne({
      studentId: getStudentId(req),
      driveId,
    });

    if (existing) {
      return res.status(409).json({
        message: "You have already applied to this drive.",
      });
    }

    const student = await User.findById(getStudentId(req));

    const application = await Application.create({
      studentId: getStudentId(req),
      driveId,
      status: "Applied",
      appliedAt: new Date(),
      resumeUrl: student?.resumeUrl || "",
      timeline: [{
        status: "Applied",
        date: new Date(),
        note: "Application submitted successfully.",
      }],
    });

    const populated = await Application.findById(application._id)
      .populate("driveId", "companyName jobRole package ctc location")
      .lean();
    if (drive.recruiter) {
      const recruiterNotification = await Notification.create({ userId: drive.recruiter, title: "New placement application", message: `A student applied for ${drive.jobRole} at ${drive.companyName}.`, type: "application", link: "/recruiter/applicants" });
      req.app.get("io")?.to(`user:${drive.recruiter}`).emit("notification:new", recruiterNotification);
    }

    return res.status(201).json({
      success: true,
      message: "Application submitted successfully.",
      application: populated,
    });
  } catch (error) {
    console.error("Submit application:", error);
    return res.status(error.code === 11000 ? 409 : 500).json({
      success: false,
      message: safeMessage(error, "Unable to submit application."),
    });
  }
});

// PATCH /api/applications/:id/withdraw
router.patch("/:id/withdraw", authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ message: "Student access required." });
    }

    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: "Invalid application ID." });
    }

    const application = await Application.findOne({
      _id: req.params.id,
      studentId: getStudentId(req),
    });

    if (!application) {
      return res.status(404).json({ message: "Application not found." });
    }

    if (TERMINAL_STATUSES.includes(application.status)) {
      return res.status(400).json({
        message: `This application is already ${application.status.toLowerCase()}.`,
      });
    }

    if (["Technical Interview", "HR Interview"].includes(application.status)) {
      return res.status(400).json({
        message: "Withdrawal is not permitted at this interview stage.",
      });
    }

    application.status = "Withdrawn";
    application.withdrawnAt = new Date();
    application.timeline.push({
      status: "Withdrawn",
      date: new Date(),
      note: "Application withdrawn by student.",
    });

    await application.save();

    req.app.get("io")?.to(`student:${getStudentId(req)}`).emit(
      "application:updated",
      { applicationId: application._id, status: "Withdrawn" }
    );

    return res.json({
      success: true,
      message: "Application withdrawn successfully.",
      application,
    });
  } catch (error) {
    console.error("Withdraw application:", error);
    return res.status(500).json({ message: "Unable to withdraw application." });
  }
});

// PATCH /api/applications/:id/status
// Admin/recruiter status updates
router.patch("/:id/status", authMiddleware, async (req, res) => {
  try {
    if (!isStaff(req.user)) {
      return res.status(403).json({
        message: "Only authorized placement staff can update status.",
      });
    }

    const { status, note = "" } = req.body;

    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: "Invalid application ID." });
    }

    if (!STATUSES.includes(status)) {
      return res.status(400).json({ message: "Invalid application status." });
    }

    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ message: "Application not found." });
    }

    if (application.status === "Withdrawn") {
      return res.status(400).json({
        message: "A withdrawn application cannot be updated.",
      });
    }

    if (application.status === "Rejected" || application.status === "Selected") {
      return res.status(400).json({
        message: "A final application status cannot be changed here.",
      });
    }

    application.status = status;
    application.statusUpdatedBy = req.user._id;
    application.timeline.push({
      status,
      date: new Date(),
      note: String(note).slice(0, 1000),
    });

    if (
      ["Shortlisted", "Written Test", "Technical Interview", "HR Interview", "Selected"]
        .includes(status) &&
      !application.roundsCleared.includes(status)
    ) {
      application.roundsCleared.push(status);
    }

    await application.save();
    const statusNotification = await Notification.create({ userId: application.studentId, title: "Application status updated", message: `Your application status is now ${status}.`, type: "application", link: "/student/applications" });
    req.app.get("io")?.to(`user:${application.studentId}`).emit("notification:new", statusNotification);

    const [student, drive] = await Promise.all([
      User.findById(application.studentId).select("email name"),
      PlacementDrive.findById(application.driveId).select("companyName jobRole"),
    ]);

    req.app.get("io")?.to(`student:${application.studentId}`).emit(
      "application:updated",
      { applicationId: application._id, status }
    );

    if (student?.email && drive) {
      sendApplicationUpdate(
        student.email,
        drive.companyName,
        status,
        drive.jobRole
      ).catch((error) => console.error("Status email failed:", error));
    }

    return res.json({
      success: true,
      message: "Application status updated.",
      application,
    });
  } catch (error) {
    console.error("Update application status:", error);
    return res.status(500).json({ message: "Unable to update application status." });
  }
});

// PATCH /api/applications/:id/schedule
router.patch("/:id/schedule", authMiddleware, async (req, res) => {
  try {
    if (!isStaff(req.user)) {
      return res.status(403).json({ message: "Placement staff access required." });
    }

    const { title = "", round = "", date, time = "", venue = "", meetLink = "" } = req.body;

    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: "Invalid application ID." });
    }

    if (meetLink && !/^https:\/\/\S+$/i.test(meetLink)) {
      return res.status(400).json({
        message: "Meeting links must use HTTPS.",
      });
    }

    if (date && Number.isNaN(new Date(date).getTime())) {
      return res.status(400).json({ message: "Invalid schedule date." });
    }

    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ message: "Application not found." });
    }
    if (req.user.role === "recruiter") {
      const ownedDrive = await PlacementDrive.findOne({ _id: application.driveId, recruiter: req.user._id }).select("_id");
      if (!ownedDrive) return res.status(403).json({ message: "You do not have access to this application." });
    }

    application.nextRound = {
      title: String(title).slice(0, 200),
      round: String(round).slice(0, 100),
      date: date ? new Date(date) : null,
      time: String(time).slice(0, 80),
      venue: String(venue).slice(0, 300),
      meetLink,
    };

    await application.save();
    const interviewNotification = await Notification.create({ userId: application.studentId, title: "Interview scheduled", message: `${application.nextRound.round || "Interview"} has been scheduled.`, type: "interview", link: "/student/applications" });
    req.app.get("io")?.to(`user:${application.studentId}`).emit("notification:new", interviewNotification);

    req.app.get("io")?.to(`student:${application.studentId}`).emit(
      "application:updated",
      { applicationId: application._id, scheduleUpdated: true }
    );

    return res.json({
      success: true,
      message: "Schedule updated successfully.",
      application,
    });
  } catch (error) {
    console.error("Update schedule:", error);
    return res.status(500).json({ message: "Unable to update schedule." });
  }
});

// PATCH /api/applications/:id/documents
router.patch("/:id/documents", authMiddleware, async (req, res) => {
  try {
    if (!isStaff(req.user)) {
      return res.status(403).json({ message: "Placement staff access required." });
    }

    const allowed = ["admitCardUrl", "offerLetterUrl"];
    const update = {};

    for (const field of allowed) {
      if (req.body[field] !== undefined) {
        const url = req.body[field];

        if (
          typeof url !== "string" ||
          (url && !/^https:\/\/\S+$/i.test(url))
        ) {
          return res.status(400).json({
            message: `${field} must be an HTTPS URL.`,
          });
        }

        update[field] = url;
      }
    }

    if (!Object.keys(update).length) {
      return res.status(400).json({
        message: "Provide an admit card or offer letter URL.",
      });
    }

    const application = await Application.findByIdAndUpdate(
      req.params.id,
      { $set: update },
      { new: true, runValidators: true }
    );

    if (!application) {
      return res.status(404).json({ message: "Application not found." });
    }

    req.app.get("io")?.to(`student:${application.studentId}`).emit(
      "application:updated",
      { applicationId: application._id, documentsUpdated: true }
    );

    return res.json({
      success: true,
      message: "Document links updated.",
      application,
    });
  } catch (error) {
    console.error("Update application documents:", error);
    return res.status(500).json({ message: "Unable to update documents." });
  }
});

module.exports = router;
