const express = require("express");

const {
  getMe,
  registerUser,
  loginUser,
  verifyLoginOTP,
  sendDirectLoginOTP,
  forgotPassword,
  verifyForgotPasswordOTP,
  resetPassword,
  googleLogin,
  changePassword,
} = require("../controllers/authController");

const router = express.Router();


// =====================================================
// REGISTER
// =====================================================

router.post("/register", registerUser);
router.put("/change-password", require("../middleware/authMiddleware"), changePassword);
router.post("/register-student", (req, res, next) => {
  req.body = { ...(req.body || {}), role: "student" };
  next();
}, registerUser);
router.get("/me", require("../middleware/authMiddleware"), getMe);


// =====================================================
// PASSWORD LOGIN
// =====================================================

router.post(
  "/login",
  loginUser
);


// =====================================================
// LOGIN OTP VERIFICATION
// =====================================================

router.post(
  "/verify-login-otp",
  verifyLoginOTP
);


// =====================================================
// DIRECT OTP LOGIN
// No password required
// =====================================================

router.post(
  "/send-login-otp",
  sendDirectLoginOTP
);



// =====================================================
// FORGOT PASSWORD
// =====================================================

router.post(
  "/forgot-password",
  forgotPassword
);


// =====================================================
// VERIFY FORGOT PASSWORD OTP
// =====================================================

router.post(
  "/verify-forgot-password-otp",
  verifyForgotPasswordOTP
);


// =====================================================
// RESET PASSWORD
// =====================================================

router.post(
  "/reset-password",
  resetPassword
);


// =====================================================
// GOOGLE LOGIN
// =====================================================

router.post(
  "/google",
  googleLogin
);


module.exports = router;