const express = require("express");

const User = require("../models/User");
const PlacementDrive = require("../models/PlacementDrive");
const Application = require("../models/Application");
const Enquiry = require("../models/Enquiry");
const { sendEmail } = require('../utils/emailService');

const router = express.Router();


// Public, non-sensitive footer and contact details.
router.get("/site-settings", async (_req, res) => {
  try {
    const SiteSettings = require("../models/SiteSettings");
    const settings = await SiteSettings.findOne({ key: "public" }).lean();
    return res.json({ success: true, settings: settings || { institutionName: "Kanya Maha Vidyalaya (Autonomous)", address: "Vidyalaya Marg, Jalandhar - 144004, Punjab, India", phonePrimary: "+91 181 2296605", phoneSecondary: "+91 181 2296606", email: "placement@kmv.ac.in", latitude: 31.325986, longitude: 75.576262, officialWebsite: "https://www.kmvjalandhar.ac.in/", placementGallery: "https://www.kmvjalandhar.ac.in/photo_galleries/placement-cell/" } });
  } catch (error) { console.error("PUBLIC SITE SETTINGS:", error.message); return res.status(500).json({ success: false, message: "Unable to load website contact details." }); }
});

// PUBLIC ENQUIRY SUBMISSION
// POST /api/public/enquiries
router.post("/enquiries", async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const phone = String(req.body.phone || "").trim();
    const subject = String(req.body.subject || "General Enquiry").trim();
    const message = String(req.body.message || "").trim();

    if (!name || !email || !/^\S+@\S+\.\S+$/.test(email) || !subject || message.length < 10) {
      return res.status(400).json({ success: false, message: "Please provide a valid name, email, subject and a message of at least 10 characters." });
    }
    if (name.length > 120 || email.length > 180 || phone.length > 30 || subject.length > 180 || message.length > 5000) {
      return res.status(400).json({ success: false, message: "One or more enquiry fields exceed the allowed length." });
    }

    const enquiry = await Enquiry.create({ name, email, phone, subject, message });
    const notifyTo = process.env.ENQUIRY_NOTIFICATION_EMAIL;
    if (notifyTo) {
      sendEmail({ to: notifyTo, subject: `New placement website enquiry: ${subject}`, text: `A new enquiry was submitted.\n\nName: ${name}\nEmail: ${email}\nPhone: ${phone || 'Not provided'}\nSubject: ${subject}\n\nMessage:\n${message}\n\nEnquiry ID: ${enquiry._id}` }).catch((mailError) => console.error('ENQUIRY ADMIN NOTIFICATION FAILED:', mailError.message));
    }
    return res.status(201).json({ success: true, message: "Your enquiry has been received and saved.", enquiryId: enquiry._id });
  } catch (error) {
    console.error("PUBLIC ENQUIRY ERROR:", error.message);
    return res.status(500).json({ success: false, message: "Unable to save your enquiry right now. Please try again." });
  }
});

// =====================================================
// PUBLIC HOME STATISTICS
// =====================================================
// GET /api/public/home-stats
//
// Returns real numbers from MongoDB:
// - Students
// - Recruiters
// - Placement Drives
// - Applications
// =====================================================

router.get("/home-stats", async (req, res) => {
  try {
    const [
      students,
      recruiters,
      placementDrives,
      applications,
    ] = await Promise.all([
      User.countDocuments({
        role: "student",
        isActive: true,
      }),

      User.countDocuments({
        role: "recruiter",
        isActive: true,
      }),

      PlacementDrive.countDocuments({
        isActive: true,
      }),

      Application.countDocuments({}),
    ]);

    return res.status(200).json({
      success: true,

      statistics: {
        students,
        recruiters,
        placementDrives,
        applications,
      },
    });
  } catch (error) {
    console.error(
      "Home statistics error:",
      error.message
    );

    return res.status(500).json({
      success: false,
      message: "Unable to load home statistics.",
    });
  }
});

// =====================================================
// PUBLIC PLACEMENT DRIVES
// =====================================================
// GET /api/public/placement-drives
//
// Optional query parameters:
//
// ?keyword=software
// ?location=jalandhar
//
// Examples:
//
// /api/public/placement-drives
//
// /api/public/placement-drives?keyword=software
//
// /api/public/placement-drives?location=jalandhar
//
// /api/public/placement-drives?keyword=software&location=jalandhar
// =====================================================

router.get("/placement-drives", async (req, res) => {
  try {
    const keyword =
      typeof req.query.keyword === "string"
        ? req.query.keyword.trim()
        : "";

    const location =
      typeof req.query.location === "string"
        ? req.query.location.trim()
        : "";

    const query = {
      isActive: true,
      status: {
        $in: ["Open", "Upcoming"],
      },
    };

    // =================================================
    // KEYWORD SEARCH
    // Searches:
    // companyName
    // jobRole
    // description
    // skills
    // =================================================

    if (keyword) {
      const escapedKeyword = keyword.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&"
      );

      const keywordRegex = new RegExp(
        escapedKeyword,
        "i"
      );

      query.$or = [
        {
          companyName: keywordRegex,
        },
        {
          jobRole: keywordRegex,
        },
        {
          description: keywordRegex,
        },
        {
          skills: keywordRegex,
        },
      ];
    }

    // =================================================
    // LOCATION SEARCH
    // =================================================

    if (location) {
      const escapedLocation = location.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&"
      );

      query.location = new RegExp(
        escapedLocation,
        "i"
      );
    }

    const drives = await PlacementDrive.find(query)
      .sort({ createdAt: -1 })
      .limit(50)
      .lean();
    const normalizedDrives = drives.map((drive) => {
      const inferredType = /\bintern(ship)?\b/i.test(drive.jobRole || "") ? "Internship" : "";
      const type = drive.opportunityType === "All" ? "" : (drive.opportunityType || inferredType || drive.jobType || "Full-time");
      return { ...drive, jobType: type, opportunityType: drive.opportunityType || type };
    });

    return res.status(200).json({
      success: true,

      count: normalizedDrives.length,

      search: {
        keyword,
        location,
      },

      drives: normalizedDrives,
    });
  } catch (error) {
    console.error(
      "Public placement drives error:",
      error.message
    );

    return res.status(500).json({
      success: false,
      message: "Unable to load placement drives.",
    });
  }
});

// Public placement highlights: verified alumni stories only, plus genuine live drive totals.
router.get("/placement-highlights", async (_req, res) => {
  try {
    const SuccessStory = require("../models/SuccessStory");
    const [stories, openDrives, completedDrives] = await Promise.all([
      SuccessStory.find({ isPublished: true, isVerified: true }).select("studentName course batch company role package testimonial createdAt").sort({ createdAt: -1 }).limit(3).lean(),
      PlacementDrive.countDocuments({ isActive: true, status: "Open" }),
      PlacementDrive.countDocuments({ status: { $in: ["Closed", "Completed"] } }),
    ]);
    return res.json({ success: true, highlights: { stories, openDrives, completedDrives } });
  } catch (error) {
    console.error("PLACEMENT HIGHLIGHTS ERROR:", error.message);
    return res.status(500).json({ success: false, message: "Unable to load placement highlights." });
  }
});

// =====================================================
// PUBLIC RECRUITERS
// =====================================================
// GET /api/public/recruiters
//
// Only public-safe information is returned.
// Password, OTP and private information are NOT returned.
// =====================================================

router.get("/recruiters", async (req, res) => {
  try {
    const recruiters = await User.find({
      role: "recruiter",
      isActive: true,
    })
      .select("_id name")
      .sort({
        createdAt: -1,
      })
      .limit(20)
      .lean();

    return res.status(200).json({
      success: true,

      count: recruiters.length,

      recruiters,
    });
  } catch (error) {
    console.error(
      "Public recruiters error:",
      error.message
    );

    return res.status(500).json({
      success: false,
      message: "Unable to load recruiters.",
    });
  }
});

// =====================================================
// PUBLIC LOCATION LIST
// =====================================================
// GET /api/public/locations
//
// Returns actual locations stored in placement drives.
// =====================================================

router.get("/locations", async (req, res) => {
  try {
    const locations =
      await PlacementDrive.distinct("location", {
        isActive: true,
        status: {
          $in: ["Open", "Upcoming"],
        },
      });

    const cleanedLocations = locations
      .filter(
        (location) =>
          typeof location === "string" &&
          location.trim() !== ""
      )
      .map((location) => location.trim())
      .sort();

    return res.status(200).json({
      success: true,

      locations: cleanedLocations,
    });
  } catch (error) {
    console.error(
      "Public locations error:",
      error.message
    );

    return res.status(500).json({
      success: false,
      message: "Unable to load locations.",
    });
  }
});

// =====================================================
// PUBLIC COMPANY LIST
// =====================================================
// GET /api/public/companies
//
// Gets company names from actual placement drives.
// This means Home does NOT use fake companies.
// =====================================================

router.get("/companies", async (req, res) => {
  try {
    const companies =
      await PlacementDrive.distinct(
        "companyName",
        {
          isActive: true,
          status: {
            $in: ["Open", "Upcoming"],
          },
        }
      );

    const cleanedCompanies = companies
      .filter(
        (company) =>
          typeof company === "string" &&
          company.trim() !== ""
      )
      .map((company) => company.trim())
      .sort();

    return res.status(200).json({
      success: true,

      companies: cleanedCompanies,
    });
  } catch (error) {
    console.error(
      "Public companies error:",
      error.message
    );

    return res.status(500).json({
      success: false,
      message: "Unable to load companies.",
    });
  }
});

module.exports = router;