const express = require('express');
const mongoose = require('mongoose');
const SuccessStory = require('../models/SuccessStory');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const router = express.Router();
const adminOnly = [protect, allowRoles('admin')];
router.get('/', async (_req, res) => {
  try {
    const stories = await SuccessStory.find({ isPublished: true, isVerified: true }).sort({ createdAt: -1 }).lean();
    res.json({ success: true, stories });
  } catch { res.status(500).json({ success: false, message: 'Unable to load verified success stories.' }); }
});
router.get('/manage/all', ...adminOnly, async (_req, res) => {
  const stories = await SuccessStory.find({}).sort({ createdAt: -1 }).lean();
  res.json({ success: true, stories });
});
router.post('/', ...adminOnly, async (req, res) => {
  try {
    const story = await SuccessStory.create({ ...req.body, isVerified: false, isPublished: false });
    res.status(201).json({ success: true, story, message: 'Story created as unpublished and unverified. Verify evidence before publishing.' });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});
router.patch('/:id', ...adminOnly, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid story ID.' });
  const allowed = ['studentName', 'course', 'batch', 'company', 'role', 'package', 'testimonial', 'isPublished', 'isVerified'];
  const update = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
  if (update.isPublished === true && update.isVerified !== true) {
    const current = await SuccessStory.findById(req.params.id).select('isVerified');
    if (!current || !current.isVerified) return res.status(400).json({ success: false, message: 'Verify placement evidence before publishing this story.' });
  }
  if (update.isVerified === true) update.verifiedBy = req.user._id;
  if (update.isVerified === false) update.verifiedBy = null;
  const story = await SuccessStory.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
  if (!story) return res.status(404).json({ success: false, message: 'Story not found.' });
  res.json({ success: true, story });
});
router.delete('/:id', ...adminOnly, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid story ID.' });
  const story = await SuccessStory.findByIdAndDelete(req.params.id);
  if (!story) return res.status(404).json({ success: false, message: 'Story not found.' });
  res.json({ success: true, message: 'Story deleted.' });
});
module.exports = router;
