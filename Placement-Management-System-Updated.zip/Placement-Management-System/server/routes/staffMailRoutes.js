const express = require('express');
const mongoose = require('mongoose');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const User = require('../models/User');
const PlacementDrive = require('../models/PlacementDrive');
const Application = require('../models/Application');
const EmailLog = require('../models/EmailLog');
const { sendEmail } = require('../utils/emailService');
const router = express.Router();
router.use(protect, allowRoles('admin', 'recruiter'));

async function allowedRecipientIds(user) {
  if (user.role === 'admin') return (await User.find({ role: 'student', isActive: true }).select('_id')).map((row) => row._id);
  const drives = await PlacementDrive.find({ recruiter: user._id }).select('_id');
  const driveIds = drives.map((drive) => drive._id);
  return Application.distinct('studentId', { driveId: { $in: driveIds } });
}

router.get('/recipients', async (req, res) => {
  try {
    const ids = await allowedRecipientIds(req.user);
    const students = await User.find({ _id: { $in: ids }, role: 'student', isActive: true }).select('name email course semester').sort({ name: 1 }).lean();
    return res.json({ success: true, students });
  } catch (error) { console.error('STAFF MAIL RECIPIENTS:', error.message); return res.status(500).json({ success: false, message: 'Unable to load student recipients.' }); }
});

router.get('/history', async (req, res) => {
  try {
    const filter = req.user.role === 'admin' ? {} : { senderId: req.user._id };
    const logs = await EmailLog.find(filter).sort({ createdAt: -1 }).limit(100).lean();
    return res.json({ success: true, emails: logs });
  } catch (error) { return res.status(500).json({ success: false, message: 'Unable to load email history.' }); }
});

router.post('/send', async (req, res) => {
  try {
    const recipientIds = Array.isArray(req.body.recipientIds) ? [...new Set(req.body.recipientIds.map(String))] : [];
    const subject = String(req.body.subject || '').trim();
    const body = String(req.body.body || '').trim();
    if (!recipientIds.length || recipientIds.length > 50) return res.status(400).json({ success: false, message: 'Select between 1 and 50 student recipients.' });
    if (recipientIds.some((id) => !mongoose.isValidObjectId(id))) return res.status(400).json({ success: false, message: 'One or more recipient IDs are invalid.' });
    if (!subject || subject.length > 180 || body.length < 2 || body.length > 10000) return res.status(400).json({ success: false, message: 'Enter a subject (up to 180 characters) and message (2–10,000 characters).' });
    const allowedIds = await allowedRecipientIds(req.user);
    const allowedSet = new Set(allowedIds.map(String));
    if (recipientIds.some((id) => !allowedSet.has(id))) return res.status(403).json({ success: false, message: 'You can email only students permitted for your account. Recruiters can contact applicants to their own drives.' });
    const students = await User.find({ _id: { $in: recipientIds }, role: 'student', isActive: true }).select('name email').lean();
    if (students.length !== recipientIds.length || students.some((student) => !student.email)) return res.status(400).json({ success: false, message: 'One or more selected students do not have an active email address.' });

    const results = [];
    for (const student of students) {
      try {
        const result = await sendEmail({ to: student.email, subject, text: `${body}\n\nRegards,\n${req.user.name || (req.user.role === 'admin' ? 'Placement Cell' : 'Recruitment Team')}\nPlacement Management System`, replyTo: req.user.email || undefined });
        const log = await EmailLog.create({ senderId: req.user._id, senderRole: req.user.role, senderName: req.user.name || '', recipientId: student._id, recipientName: student.name, recipientEmail: student.email, subject, body, status: 'sent', provider: result.provider, providerMessageId: result.messageId });
        results.push({ email: student.email, status: 'sent', id: log._id });
      } catch (error) {
        await EmailLog.create({ senderId: req.user._id, senderRole: req.user.role, senderName: req.user.name || '', recipientId: student._id, recipientName: student.name, recipientEmail: student.email, subject, body, status: 'failed', errorMessage: String(error.message || 'Email failed').slice(0, 500) });
        results.push({ email: student.email, status: 'failed', message: error.message });
      }
    }
    const sent = results.filter((row) => row.status === 'sent').length;
    return res.status(sent ? 200 : 502).json({ success: sent > 0, message: `${sent} of ${results.length} email(s) accepted by the configured provider.`, sent, failed: results.length - sent, results });
  } catch (error) { console.error('STAFF MAIL SEND:', error.message); return res.status(500).json({ success: false, message: error.message || 'Unable to send email.' }); }
});
module.exports = router;
