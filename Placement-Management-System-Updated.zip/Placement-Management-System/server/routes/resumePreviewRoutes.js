const express = require("express");

const router = express.Router();

const protect = require("../middleware/authMiddleware");

router.get("/", protect, async (req, res) => {
  try {
    const { url } = req.query;

    if (!url) {
      return res.status(400).json({
        success: false,
        message: "Resume URL is required.",
      });
    }

    let resumeUrl;

    try {
      resumeUrl = new URL(url);
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: "Invalid resume URL.",
      });
    }

    // Only allow Cloudinary URLs
    if (
      resumeUrl.protocol !== "https:" ||
      resumeUrl.hostname !== "res.cloudinary.com"
    ) {
      return res.status(403).json({
        success: false,
        message: "Only Cloudinary resume URLs are allowed.",
      });
    }

    const response = await fetch(resumeUrl.toString(), {
      method: "GET",
      redirect: "follow",
    });

    if (!response.ok) {
      return res.status(502).json({
        success: false,
        message: "Unable to fetch resume PDF from Cloudinary.",
      });
    }

    const pdfBuffer = Buffer.from(
      await response.arrayBuffer()
    );

    if (!pdfBuffer.length) {
      return res.status(502).json({
        success: false,
        message: "Resume PDF is empty.",
      });
    }

    res.status(200);

    res.setHeader(
      "Content-Type",
      "application/pdf"
    );

    res.setHeader(
      "Content-Disposition",
      'inline; filename="resume.pdf"'
    );

    res.setHeader(
      "Content-Length",
      pdfBuffer.length
    );

    res.setHeader(
      "Cache-Control",
      "private, max-age=300"
    );

    res.end(pdfBuffer);
  } catch (error) {
    console.error(
      "Resume Preview Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Server error while preparing resume preview.",
      error: error.message,
    });
  }
});

module.exports = router;