const express = require('express');
const ResumeDraft = require('../models/ResumeDraft');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const router = express.Router();
router.use(protect, allowRoles('student'));
router.get('/', async (req,res)=>{try{const draft=await ResumeDraft.findOne({user:req.user._id}).lean();res.json({success:true,draft});}catch(e){res.status(500).json({success:false,message:'Unable to load resume draft.'});}});
router.put('/', async (req,res)=>{try{const data=req.body?.data;if(!data||typeof data!=='object'||Array.isArray(data))return res.status(400).json({success:false,message:'Resume data is required.'});const draft=await ResumeDraft.findOneAndUpdate({user:req.user._id},{user:req.user._id,data},{new:true,upsert:true,runValidators:true});res.json({success:true,draft});}catch(e){res.status(400).json({success:false,message:'Unable to save resume draft.'});}});
module.exports=router;
