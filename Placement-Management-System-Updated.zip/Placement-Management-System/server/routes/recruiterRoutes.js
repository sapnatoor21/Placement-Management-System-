const express = require("express");

const protect = require("../middleware/authMiddleware");
const allowRoles = require("../middleware/roleMiddleware");

const {
  getRecruiterDashboard,
  getRecruiterDrives,
  createRecruiterDrive,
  updateRecruiterDrive,
  deleteRecruiterDrive,
  getRecruiterApplications,
  updateRecruiterApplicationStatus,
  getRecruiterCandidates,
  getRecruiterProfile,
  updateRecruiterProfile,
} = require("../controllers/recruiterController");

const router = express.Router();

const recruiterOnly = [
  protect,
  allowRoles("recruiter"),
];

// =====================================================
// DASHBOARD
// =====================================================

router.get(
  "/dashboard",
  ...recruiterOnly,
  getRecruiterDashboard
);

// =====================================================
// DRIVES
// =====================================================

router.get(
  "/drives",
  ...recruiterOnly,
  getRecruiterDrives
);

router.post(
  "/drives",
  ...recruiterOnly,
  createRecruiterDrive
);

router.put(
  "/drives/:driveId",
  ...recruiterOnly,
  updateRecruiterDrive
);

router.delete(
  "/drives/:driveId",
  ...recruiterOnly,
  deleteRecruiterDrive
);

// =====================================================
// APPLICATIONS
// =====================================================

router.get(
  "/applications",
  ...recruiterOnly,
  getRecruiterApplications
);

router.patch(
  "/applications/:applicationId/status",
  ...recruiterOnly,
  updateRecruiterApplicationStatus
);

// =====================================================
// CANDIDATES
// =====================================================

router.get(
  "/candidates",
  ...recruiterOnly,
  getRecruiterCandidates
);

// =====================================================
// PROFILE
// =====================================================

router.get(
  "/profile",
  ...recruiterOnly,
  getRecruiterProfile
);

router.put(
  "/profile",
  ...recruiterOnly,
  updateRecruiterProfile
);

module.exports = router;