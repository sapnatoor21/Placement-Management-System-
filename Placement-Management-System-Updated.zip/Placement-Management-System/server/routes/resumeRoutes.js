const express = require("express");

const {
  uploadResume,
  getResume,
  getDefaultResume,
  setDefaultResume,
  toggleVisibility,
  updateResume,
  deleteResume,
  previewResume,
  getAllResumes,
  updateApproval,
  searchResumes,
  bulkDownload,
} = require("../controllers/resumeController");

const authMiddleware = require("../middleware/authMiddleware");
const upload = require("../middleware/upload");

const router = express.Router();

// =====================================================
// STUDENT RESUME ROUTES
// =====================================================

// Upload resume
// POST /api/resume
router.post(
  "/",
  authMiddleware,
  upload.single("resume"),
  uploadResume
);

// Get all logged-in student's resumes
// GET /api/resume
router.get(
  "/",
  authMiddleware,
  getResume
);

// Get default resume
// GET /api/resume/default
router.get(
  "/default",
  authMiddleware,
  getDefaultResume
);

// Set default resume
// PATCH /api/resume/:id/default
router.patch(
  "/:id/default",
  authMiddleware,
  setDefaultResume
);

// Show / Hide resume
// PATCH /api/resume/:id/visibility
router.patch(
  "/:id/visibility",
  authMiddleware,
  toggleVisibility
);

// Update resume title
// PUT /api/resume/:id
router.put(
  "/:id",
  authMiddleware,
  updateResume
);

// Delete resume
// DELETE /api/resume/:id
router.delete(
  "/:id",
  authMiddleware,
  deleteResume
);

// Preview PDF
// GET /api/resume/:id/preview
router.get(
  "/:id/preview",
  authMiddleware,
  previewResume
);

// =====================================================
// ADMIN ROUTES
// =====================================================

// Get all resumes
// GET /api/resume/admin/all
router.get(
  "/admin/all",
  authMiddleware,
  getAllResumes
);

// Approve / Reject resume
// PATCH /api/resume/admin/:id/approval
router.patch(
  "/admin/:id/approval",
  authMiddleware,
  updateApproval
);

// =====================================================
// RECRUITER ROUTES
// =====================================================

// Search resumes
// GET /api/resume/recruiter/search
router.get(
  "/recruiter/search",
  authMiddleware,
  searchResumes
);

// Bulk download resumes
// GET /api/resume/recruiter/bulk-download
router.get(
  "/recruiter/bulk-download",
  authMiddleware,
  bulkDownload
);

module.exports = router;