const express = require('express');
const mongoose = require('mongoose');
const Notification = require('../models/Notification');
const protect = require('../middleware/authMiddleware');
const router = express.Router();
router.use(protect);
router.get('/', async (req, res) => {
  try {
    const notifications = await Notification.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(100).lean();
    res.json({ success: true, notifications, unreadCount: notifications.filter(n => !n.isRead).length });
  } catch { res.status(500).json({ success: false, message: 'Unable to load notifications.' }); }
});
router.patch('/read-all', async (req, res) => {
  try { await Notification.updateMany({ userId: req.user._id, isRead: false }, { $set: { isRead: true } }); res.json({ success: true }); }
  catch { res.status(500).json({ success: false, message: 'Unable to update notifications.' }); }
});
router.patch('/:id/read', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid notification ID.' });
  const notification = await Notification.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, { $set: { isRead: true } }, { new: true });
  if (!notification) return res.status(404).json({ success: false, message: 'Notification not found.' });
  res.json({ success: true, notification });
});
router.delete('/:id', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid notification ID.' });
  const notification = await Notification.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
  if (!notification) return res.status(404).json({ success: false, message: 'Notification not found.' });
  res.json({ success: true });
});
module.exports = router;
