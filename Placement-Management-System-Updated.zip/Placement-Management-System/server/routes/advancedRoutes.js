
const express = require("express");

const router = express.Router();

const authMiddleware = require("../middleware/authMiddleware");
const MockInterviewEvaluation = require("../models/MockInterviewEvaluation");
const CodingSubmission = require("../models/CodingSubmission");

// =====================================================
// CONFIGURATION
// =====================================================

const AI_API_KEY = process.env.AI_API_KEY;
const AI_MODEL = process.env.AI_MODEL || "gemini-3.8-flash";

const JUDGE0_API_URL =
  process.env.JUDGE0_API_URL || "https://judge0-ce.p.rapidapi.com";

const JUDGE0_API_KEY = process.env.JUDGE0_API_KEY;
const JUDGE0_API_HOST = process.env.JUDGE0_API_HOST;

// =====================================================
// HELPER: GEMINI API URL
// =====================================================

function getGeminiUrl() {
  // Prefer the configured endpoint so model and API version stay under operator control.
  return process.env.AI_API_URL || `https://generativelanguage.googleapis.com/v1beta/models/${AI_MODEL}:generateContent`;
}

// =====================================================
// HELPER: CALL GEMINI
// =====================================================

async function callGemini(systemPrompt, userPrompt) {
  if (!AI_API_KEY) {
    throw new Error("AI_API_KEY is missing in server .env file.");
  }

  const response = await fetch(getGeminiUrl(), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": AI_API_KEY,
    },
    body: JSON.stringify({
      systemInstruction: {
        parts: [{ text: systemPrompt }],
      },
      contents: [
        {
          role: "user",
          parts: [{ text: userPrompt }],
        },
      ],
      generationConfig: {
        responseMimeType: "application/json",
        maxOutputTokens: 4096,
      },
    }),
  });

  const responseData = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message =
      responseData?.error?.message ||
      `Gemini API request failed with status ${response.status}`;

    console.error("Gemini API error:", {
      status: response.status,
      message,
    });

    throw new Error(message);
  }

  const generatedText =
    responseData?.candidates?.[0]?.content?.parts
      ?.map((part) => part.text || "")
      .join("")
      .trim();

  if (!generatedText) {
    throw new Error("Gemini returned an empty response.");
  }

  return generatedText;
}

// =====================================================
// HELPER: PARSE GEMINI JSON RESPONSE
// =====================================================

function parseAIJson(text) {
  if (!text) {
    return {};
  }

  let cleaned = text.trim();

  cleaned = cleaned
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  try {
    return JSON.parse(cleaned);
  } catch (error) {
    const firstBrace = cleaned.indexOf("{");
    const lastBrace = cleaned.lastIndexOf("}");

    if (firstBrace !== -1 && lastBrace > firstBrace) {
      try {
        return JSON.parse(cleaned.substring(firstBrace, lastBrace + 1));
      } catch (parseError) {
        console.error("AI JSON parsing failed:", parseError.message);
      }
    }

    return {
      answer: cleaned,
      feedback: cleaned,
    };
  }
}

// =====================================================
// HELPER: GET USER ID
// =====================================================

function getUserId(req) {
  return (
    req.user?._id ||
    req.user?.id ||
    req.user?.userId ||
    null
  );
}

// =====================================================
// 1. AI CAREER HELPER
// POST /api/advanced/ask-ai
// =====================================================

router.post("/ask-ai", async (req, res) => {
  try {
    const question =
      req.body?.question ||
      req.body?.prompt ||
      req.body?.message ||
      "";

    if (!question.trim()) {
      return res.status(400).json({
        success: false,
        message: "Please enter a question.",
      });
    }

    const systemPrompt = `
You are the AI Career Helper for Placement Management System,
Kanya Maha Vidyalaya, Jalandhar.

Your role is to help college students with:

1. Placement preparation
2. Resume improvement
3. Interview preparation
4. Aptitude preparation
5. Technical interview preparation
6. Career planning
7. Internship preparation
8. Communication skills
9. Coding and programming concepts
10. Professional development

Instructions:
- Give practical and student-friendly answers.
- Use simple English.
- Keep answers clear and structured.
- Give step-by-step guidance wherever useful.
- Do not invent company vacancies, placement statistics,
  college announcements, or placement results.
- Tell students to verify official placement information.
- Do not claim that a student is selected for a job.
- If the question is unrelated to careers or education,
  politely guide the student back to placement-related topics.

Return valid JSON in this format:
{
  "answer": "Your complete helpful answer",
  "suggestions": [
    "First related suggestion",
    "Second related suggestion",
    "Third related suggestion"
  ]
}
`;

    const generatedText = await callGemini(
      systemPrompt,
      question.trim()
    );

    const result = parseAIJson(generatedText);

    return res.status(200).json({
      success: true,
      answer:
        result.answer ||
        result.response ||
        result.feedback ||
        generatedText,
      suggestions: Array.isArray(result.suggestions)
        ? result.suggestions
        : [],
      data: result,
    });
  } catch (error) {
    console.error("Home AI helper failed:", error.message);

    return res.status(502).json({
      success: false,
      message: "AI Career Helper is temporarily unavailable.",
      error:
        process.env.NODE_ENV === "development"
          ? error.message
          : undefined,
    });
  }
});

// =====================================================
// 2. MOCK INTERVIEW EVALUATION
// POST /api/advanced/mock-interview/evaluate
// =====================================================

router.post(
  "/mock-interview/evaluate",
  authMiddleware,
  async (req, res) => {
    try {
      const userId = getUserId(req);

      if (!userId) {
        return res.status(401).json({
          success: false,
          message: "User authentication required.",
        });
      }

      const {
        question,
        answer,
        role,
        interviewType,
        category,
      } = req.body;

      if (!question || !answer) {
        return res.status(400).json({
          success: false,
          message: "Question and answer are required.",
        });
      }

      const systemPrompt = `
You are an experienced professional interviewer
and placement preparation evaluator.

Evaluate the student's mock interview answer.

Consider:
1. Relevance to the question
2. Technical correctness
3. Clarity of explanation
4. Communication quality
5. Confidence and structure
6. Areas that need improvement

Be constructive and encouraging.
Do not give an unrealistically high score.

For behavioral answers, separately assess STAR: Situation, Task, Action and Result. Give each a score from 0 to 20. For non-behavioral answers, still assess relevance, correctness, clarity and completeness and set starBreakdown values to null.
Return valid JSON:
{
  "score": 0,
  "rating": "Needs Improvement",
  "strengths": [],
  "improvements": [],
  "missingPoints": [],
  "feedback": "",
  "idealAnswer": "",
  "communicationTips": [],
  "starBreakdown": {"situation": null, "task": null, "action": null, "result": null}
}
Score must be evidence-based and between 0 and 100. Do not fabricate evidence from a short or empty answer.
`;

      const userPrompt = `
Interview role: ${role || "General"}
Interview type: ${interviewType || category || "General"}

Question:
${question}

Student answer:
${answer}
`;

      const generatedText = await callGemini(
        systemPrompt,
        userPrompt
      );

      const evaluation = parseAIJson(generatedText);

      const result = {
        score: Number(evaluation.score) || 0,
        rating: evaluation.rating || "Evaluated",
        strengths: Array.isArray(evaluation.strengths)
          ? evaluation.strengths
          : [],
        improvements: Array.isArray(evaluation.improvements)
          ? evaluation.improvements
          : [],
        feedback:
          evaluation.feedback ||
          evaluation.answer ||
          generatedText,
        idealAnswer: evaluation.idealAnswer || "",
        communicationTips: Array.isArray(evaluation.communicationTips) ? evaluation.communicationTips : [],
        missingPoints: Array.isArray(evaluation.missingPoints) ? evaluation.missingPoints : [],
        starBreakdown: evaluation.starBreakdown || null,
      };

      try {
        await MockInterviewEvaluation.create({
          studentId: userId,
          question,
          answer,
          category: (interviewType || category || 'technical').toLowerCase().includes('hr') || (interviewType || category || '').toLowerCase().includes('behavior') ? 'hr' : 'technical',
          company: req.body.company || '',
          role: role || "General",
          evaluation: result,
        });
      } catch (saveError) {
        console.error(
          "Mock interview history save failed:",
          saveError.message
        );
      }

      return res.status(200).json({
        success: true,
        message: "Interview answer evaluated successfully.",
        evaluation: result,
        data: result,
      });
    } catch (error) {
      console.error(
        "Mock interview evaluation failed:",
        error.message
      );

      return res.status(502).json({
        success: false,
        message: "Mock interview evaluation failed.",
        error:
          process.env.NODE_ENV === "development"
            ? error.message
            : undefined,
      });
    }
  }
);

// =====================================================
// 3. MOCK INTERVIEW HISTORY
// GET /api/advanced/mock-interview/history
// =====================================================

router.get(
  "/mock-interview/history",
  authMiddleware,
  async (req, res) => {
    try {
      const userId = getUserId(req);

      if (!userId) {
        return res.status(401).json({
          success: false,
          message: "User authentication required.",
        });
      }

      const history = await MockInterviewEvaluation.find({ studentId: userId })
        .sort({ createdAt: -1 })
        .limit(50)
        .lean();

      return res.status(200).json({
        success: true,
        count: history.length,
        history,
        data: history,
      });
    } catch (error) {
      console.error(
        "Mock interview history error:",
        error.message
      );

      return res.status(500).json({
        success: false,
        message: "Unable to load mock interview history.",
      });
    }
  }
);

// =====================================================
// 4. AI CAREER GUIDANCE
// POST /api/advanced/career-guidance
// =====================================================

router.post(
  "/career-guidance",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        education,
        course,
        semester,
        skills,
        interests,
        careerGoal,
        experience,
      } = req.body;

      const systemPrompt = `
You are a professional student career counsellor
working with Placement Management System.

Provide realistic career guidance based on the
student's education, skills, interests and goals.

Include:
1. Suitable career paths
2. Skills to learn
3. Recommended learning roadmap
4. Project ideas
5. Internship preparation
6. Interview preparation
7. Practical next steps

Do not guarantee jobs, salaries or placements.
Do not invent job vacancies.

Return valid JSON:
{
  "careerPaths": [],
  "recommendedSkills": [],
  "learningRoadmap": [],
  "projectIdeas": [],
  "internshipAdvice": [],
  "interviewPreparation": [],
  "actionPlan": [],
  "summary": ""
}
`;

      const userPrompt = `
Education: ${education || "Not provided"}
Course: ${course || "Not provided"}
Semester: ${semester || "Not provided"}
Skills: ${skills || "Not provided"}
Interests: ${interests || "Not provided"}
Career goal: ${careerGoal || "Not provided"}
Experience: ${experience || "Not provided"}
`;

      const generatedText = await callGemini(
        systemPrompt,
        userPrompt
      );

      const guidance = parseAIJson(generatedText);

      return res.status(200).json({
        success: true,
        message: "Career guidance generated successfully.",
        guidance,
        data: guidance,
      });
    } catch (error) {
      console.error(
        "Career guidance failed:",
        error.message
      );

      return res.status(502).json({
        success: false,
        message: "Career guidance is temporarily unavailable.",
        error:
          process.env.NODE_ENV === "development"
            ? error.message
            : undefined,
      });
    }
  }
);

// =====================================================
// 5. RUN CODE USING JUDGE0
// POST /api/advanced/coding/run
// =====================================================

router.post(
  "/coding/run",
  authMiddleware,
  async (req, res) => {
    try {
      const userId = getUserId(req);

      const {
        sourceCode,
        languageId,
        stdin,
        language,
      } = req.body;

      if (!sourceCode || !languageId) {
        return res.status(400).json({
          success: false,
          message: "Source code and language ID are required.",
        });
      }

      if (!JUDGE0_API_KEY) {
        return res.status(503).json({
          success: false,
          message: "Judge0 API key is not configured.",
        });
      }

      const headers = {
        "Content-Type": "application/json",
        "X-RapidAPI-Key": JUDGE0_API_KEY,
      };

      if (JUDGE0_API_HOST) {
        headers["X-RapidAPI-Host"] = JUDGE0_API_HOST;
      }

      const judgeResponse = await fetch(
        `${JUDGE0_API_URL}/submissions?base64_encoded=false&wait=true`,
        {
          method: "POST",
          headers,
          body: JSON.stringify({
            source_code: sourceCode,
            language_id: Number(languageId),
            stdin: stdin || "",
          }),
        }
      );

      const judgeData = await judgeResponse.json().catch(
        () => ({})
      );

      if (!judgeResponse.ok) {
        console.error("Judge0 error:", judgeData);

        return res.status(502).json({
          success: false,
          message:
            judgeData?.message ||
            "Code execution service failed.",
        });
      }

      // Save coding submission.
      try {
        await CodingSubmission.create({
          studentId: userId,
          problemId: String(req.body.problemId || 'custom'),
          sourceCode,
          languageId: Number(languageId),
          status: judgeData.status?.description || "Submitted",
          verdict: judgeData.status?.description || "Pending",
          stdout: judgeData.stdout || "",
          stderr: judgeData.stderr || "",
          compileOutput: judgeData.compile_output || "",
          time: judgeData.time || "",
          memory: judgeData.memory || null,
        });
      } catch (saveError) {
        console.error(
          "Coding submission save failed:",
          saveError.message
        );
      }

      return res.status(200).json({
        success: true,
        message: "Code execution completed.",
        result: judgeData,
        data: judgeData,
      });
    } catch (error) {
      console.error("Code execution failed:", error.message);

      return res.status(500).json({
        success: false,
        message: "Unable to execute code.",
        error:
          process.env.NODE_ENV === "development"
            ? error.message
            : undefined,
      });
    }
  }
);

// =====================================================
// 6. CODING SUBMISSION HISTORY
// GET /api/advanced/coding/history
// =====================================================

router.get(
  "/coding/history",
  authMiddleware,
  async (req, res) => {
    try {
      const userId = getUserId(req);

      if (!userId) {
        return res.status(401).json({
          success: false,
          message: "User authentication required.",
        });
      }

      const history = await CodingSubmission.find({ studentId: userId })
        .sort({ createdAt: -1 })
        .limit(50)
        .lean();

      return res.status(200).json({
        success: true,
        count: history.length,
        history,
        data: history,
      });
    } catch (error) {
      console.error(
        "Coding history error:",
        error.message
      );

      return res.status(500).json({
        success: false,
        message: "Unable to load coding history.",
      });
    }
  }
);

// =====================================================
// EXPORT ROUTER
// =====================================================

module.exports = router;
