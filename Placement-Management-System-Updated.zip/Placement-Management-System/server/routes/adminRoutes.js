const express = require("express");
const protect = require("../middleware/authMiddleware");
const allowRoles = require("../middleware/roleMiddleware");
const {
  getAdminDashboard,
  getStudents,
  getRecruiters,
  createRecruiter,
  updateUserStatus,
  getDrives,
  createDrive,
  updateDrive,
  deleteDrive,
  getApplications,
  updateApplicationStatus,
  getStats,
} = require("../controllers/adminController");

const Enquiry = require("../models/Enquiry");
const mongoose = require("mongoose");
const { sendEmail } = require("../utils/emailService");

const router = express.Router();
const adminOnly = [protect, allowRoles("admin")];

router.get("/site-settings", ...adminOnly, async (_req, res) => {
  try {
    const SiteSettings = require("../models/SiteSettings");
    const settings = await SiteSettings.findOneAndUpdate({ key: "public" }, { $setOnInsert: { key: "public" } }, { new: true, upsert: true, setDefaultsOnInsert: true });
    return res.json({ success: true, settings });
  } catch (error) { return res.status(500).json({ success: false, message: "Unable to load website settings." }); }
});
router.patch("/site-settings", ...adminOnly, async (req, res) => {
  try {
    const SiteSettings = require("../models/SiteSettings");
    const allowed = ["institutionName", "address", "phonePrimary", "phoneSecondary", "email", "latitude", "longitude", "officialWebsite", "placementGallery"];
    const update = Object.fromEntries(Object.entries(req.body || {}).filter(([key]) => allowed.includes(key)));
    if (update.email && !/^\S+@\S+\.\S+$/.test(String(update.email))) return res.status(400).json({ success: false, message: "Enter a valid placement contact email." });
    if (update.officialWebsite && !/^https:\/\//i.test(String(update.officialWebsite))) return res.status(400).json({ success: false, message: "Official website must use HTTPS." });
    if (update.placementGallery && !/^https:\/\//i.test(String(update.placementGallery))) return res.status(400).json({ success: false, message: "Gallery URL must use HTTPS." });
    const settings = await SiteSettings.findOneAndUpdate({ key: "public" }, { $set: { ...update, updatedBy: req.user._id } }, { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true });
    return res.json({ success: true, settings, message: "Public website contact details updated." });
  } catch (error) { return res.status(400).json({ success: false, message: error.message || "Unable to update website settings." }); }
});

router.get("/dashboard", ...adminOnly, getAdminDashboard);
router.get("/students", ...adminOnly, getStudents);
router.get("/recruiters", ...adminOnly, getRecruiters);
router.post("/recruiters", ...adminOnly, createRecruiter);
router.patch("/users/:userId/status", ...adminOnly, updateUserStatus);
router.get("/drives", ...adminOnly, getDrives);
router.post("/drives", ...adminOnly, createDrive);
router.put("/drives/:driveId", ...adminOnly, updateDrive);
router.delete("/drives/:driveId", ...adminOnly, deleteDrive);
router.get("/applications", ...adminOnly, getApplications);
router.patch("/applications/:applicationId/status", ...adminOnly, updateApplicationStatus);
router.get("/stats", ...adminOnly, getStats);

// Enquiries are visible to administrators only.
router.get("/enquiries", ...adminOnly, async (_req, res) => {
  try {
    const enquiries = await Enquiry.find({}).sort({ createdAt: -1 }).lean();
    return res.json({ success: true, enquiries });
  } catch (error) {
    console.error("ADMIN ENQUIRIES ERROR:", error.message);
    return res.status(500).json({ success: false, message: "Unable to load enquiries." });
  }
});

router.patch("/enquiries/:enquiryId", ...adminOnly, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.enquiryId)) return res.status(400).json({ success: false, message: "Invalid enquiry ID." });
    const allowedStatuses = ["New", "In Progress", "Replied", "Resolved"];
    const update = { handledBy: req.user._id };
    if (req.body.status !== undefined) {
      if (!allowedStatuses.includes(req.body.status)) return res.status(400).json({ success: false, message: "Invalid enquiry status." });
      update.status = req.body.status;
      if (req.body.status === "Replied") update.repliedAt = new Date();
    }
    if (req.body.adminNotes !== undefined) update.adminNotes = String(req.body.adminNotes).slice(0, 3000);
    const enquiry = await Enquiry.findByIdAndUpdate(req.params.enquiryId, { $set: update }, { new: true, runValidators: true });
    if (!enquiry) return res.status(404).json({ success: false, message: "Enquiry not found." });
    return res.json({ success: true, enquiry });
  } catch (error) {
    console.error("UPDATE ENQUIRY ERROR:", error.message);
    return res.status(500).json({ success: false, message: "Unable to update enquiry." });
  }
});

router.post("/enquiries/:enquiryId/reply", ...adminOnly, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.enquiryId)) return res.status(400).json({ success: false, message: "Invalid enquiry ID." });
    const subject = String(req.body.subject || "").trim();
    const body = String(req.body.body || "").trim();
    if (!subject || subject.length > 180 || body.length < 2 || body.length > 8000) return res.status(400).json({ success: false, message: "Enter a subject and a reply between 2 and 8,000 characters." });
    const enquiry = await Enquiry.findById(req.params.enquiryId);
    if (!enquiry) return res.status(404).json({ success: false, message: "Enquiry not found." });
    try {
      const delivery = await sendEmail({ to: enquiry.email, subject, text: `${body}\n\nRegards,\n${req.user.name || 'Placement Cell'}\nPlacement Management System`, replyTo: req.user.email || undefined });
      enquiry.emailHistory.push({ senderId: req.user._id, senderName: req.user.name || '', senderRole: req.user.role, to: enquiry.email, subject, body, status: 'sent', provider: delivery.provider, messageId: delivery.messageId || '', sentAt: new Date() });
      enquiry.status = 'Replied'; enquiry.repliedAt = new Date(); enquiry.handledBy = req.user._id;
      await enquiry.save();
      return res.json({ success: true, message: 'Reply accepted by the configured email provider.', enquiry });
    } catch (mailError) {
      enquiry.emailHistory.push({ senderId: req.user._id, senderName: req.user.name || '', senderRole: req.user.role, to: enquiry.email, subject, body, status: 'failed', errorMessage: String(mailError.message || 'Email failed').slice(0, 500), sentAt: new Date() });
      await enquiry.save();
      return res.status(502).json({ success: false, message: `Reply was not sent: ${mailError.message}`, enquiry });
    }
  } catch (error) { console.error('ENQUIRY REPLY ERROR:', error.message); return res.status(500).json({ success: false, message: 'Unable to send enquiry reply.' }); }
});

router.delete("/enquiries/:enquiryId", ...adminOnly, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.enquiryId)) return res.status(400).json({ success: false, message: "Invalid enquiry ID." });
    const enquiry = await Enquiry.findByIdAndDelete(req.params.enquiryId);
    if (!enquiry) return res.status(404).json({ success: false, message: "Enquiry not found." });
    return res.json({ success: true, message: "Enquiry deleted." });
  } catch (error) {
    console.error("DELETE ENQUIRY ERROR:", error.message);
    return res.status(500).json({ success: false, message: "Unable to delete enquiry." });
  }
});


module.exports = router;
