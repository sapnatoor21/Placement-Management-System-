const express = require("express");
const router = express.Router();

const PlacementDrive = require("../models/PlacementDrive");
const protect = require("../middleware/authMiddleware");
const allowRoles = require("../middleware/roleMiddleware");
const adminOnly = [protect, allowRoles("admin")];

// =====================================================
// GET ALL ACTIVE PLACEMENT DRIVES
// GET /api/placement-drives
// =====================================================

router.get("/", async (req, res) => {
  try {
    const drives = await PlacementDrive.find({
      isActive: true,
    }).sort({
      createdAt: -1,
    });

    res.status(200).json({
      success: true,
      count: drives.length,
      drives,
    });
  } catch (error) {
    console.error(
      "Get Placement Drives Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to fetch placement drives",
    });
  }
});


// =====================================================
// GET SINGLE PLACEMENT DRIVE
// GET /api/placement-drives/:id
// =====================================================

router.get("/:id", async (req, res) => {
  try {
    const drive = await PlacementDrive.findById(
      req.params.id
    );

    if (!drive) {
      return res.status(404).json({
        success: false,
        message: "Placement drive not found",
      });
    }

    res.status(200).json({
      success: true,
      drive,
    });
  } catch (error) {
    console.error(
      "Get Placement Drive Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to fetch placement drive",
    });
  }
});


// =====================================================
// CREATE PLACEMENT DRIVE
// POST /api/placement-drives
// =====================================================

router.post("/", ...adminOnly, async (req, res) => {
  try {
    const {
      companyName,
      jobRole,
      description,
      location,
      jobType,
      package: salaryPackage,
      eligibility,
      skills,
      applicationDeadline,
      driveDate,
      status,
    } = req.body;

    // Required fields
    if (!companyName || !jobRole) {
      return res.status(400).json({
        success: false,
        message:
          "Company name and job role are required",
      });
    }

    const drive = await PlacementDrive.create({
      companyName,
      jobRole,
      description,
      location,
      jobType,
      package: salaryPackage,
      eligibility,
      skills,
      applicationDeadline,
      driveDate,
      status,
    });

    res.status(201).json({
      success: true,
      message:
        "Placement drive created successfully",
      drive,
    });
  } catch (error) {
    console.error(
      "Create Placement Drive Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to create placement drive",
      error: error.message,
    });
  }
});


// =====================================================
// UPDATE PLACEMENT DRIVE
// PUT /api/placement-drives/:id
// =====================================================

router.put("/:id", ...adminOnly, async (req, res) => {
  try {
    const drive =
      await PlacementDrive.findByIdAndUpdate(
        req.params.id,
        req.body,
        {
          new: true,
          runValidators: true,
        }
      );

    if (!drive) {
      return res.status(404).json({
        success: false,
        message: "Placement drive not found",
      });
    }

    res.status(200).json({
      success: true,
      message:
        "Placement drive updated successfully",
      drive,
    });
  } catch (error) {
    console.error(
      "Update Placement Drive Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to update placement drive",
    });
  }
});


// =====================================================
// DELETE / DEACTIVATE PLACEMENT DRIVE
// DELETE /api/placement-drives/:id
// =====================================================

router.delete("/:id", ...adminOnly, async (req, res) => {
  try {
    const drive =
      await PlacementDrive.findByIdAndUpdate(
        req.params.id,
        {
          isActive: false,
          status: "Closed",
        },
        {
          new: true,
        }
      );

    if (!drive) {
      return res.status(404).json({
        success: false,
        message: "Placement drive not found",
      });
    }

    res.status(200).json({
      success: true,
      message:
        "Placement drive closed successfully",
      drive,
    });
  } catch (error) {
    console.error(
      "Delete Placement Drive Error:",
      error
    );

    res.status(500).json({
      success: false,
      message:
        "Failed to close placement drive",
    });
  }
});


module.exports = router;