const express = require("express");
const Application = require("../models/Application");
const StudentProfile = require("../models/StudentProfile");
const AptitudeAttempt = require("../models/AptitudeAttempt");

const protect = require("../middleware/authMiddleware");
const allowRoles = require("../middleware/roleMiddleware");
const studentOnly = [protect, allowRoles("student")];

const {
  getStudentProfile,
  createStudentProfile,
  updateStudentProfile,
  deleteStudentProfile,
} = require("../controllers/studentController");

const router = express.Router();

// Dashboard statistics backed by MongoDB. API errors are returned as errors,
// never converted into fabricated zero values by the client.
router.get("/stats", ...studentOnly, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ success: false, message: "Student access required." });
    }
    const [applications, profile] = await Promise.all([
      Application.find({ studentId: req.user._id }).select("status nextRound").lean(),
      StudentProfile.findOne({ user: req.user._id }).lean(),
    ]);
    const stats = {
      totalApplied: applications.length,
      shortlistedCount: applications.filter((a) => ["Shortlisted", "Written Test", "Technical Interview", "HR Interview", "Selected"].includes(a.status)).length,
      interviewsScheduled: applications.filter((a) => a.nextRound?.date && new Date(a.nextRound.date) >= new Date()).length,
      offersReceived: applications.filter((a) => a.status === "Selected").length,
      profileCompletion: Number(profile?.profileCompletion || 0),
    };
    return res.json({ success: true, stats });
  } catch (error) {
    console.error("Student stats error:", error);
    return res.status(500).json({ success: false, message: "Unable to load student statistics." });
  }
});

router.get("/applications", ...studentOnly, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ success: false, message: "Student access required." });
    }
    const applications = await Application.find({ studentId: req.user._id })
      .populate("driveId", "companyName jobRole package ctc location applicationDeadline status")
      .sort({ appliedAt: -1 }).lean();
    return res.json({ success: true, applications: applications.map((item) => ({
      ...item,
      id: String(item._id),
      drive: item.driveId,
    })) });
  } catch (error) {
    console.error("Student applications error:", error);
    return res.status(500).json({ success: false, message: "Unable to load applications." });
  }
});


// Aptitude attempts are stored against the authenticated student; clients cannot submit another student's ID.
router.get("/assessments", ...studentOnly, async (req, res) => {
  try {
    const assessments = await AptitudeAttempt.find({ studentId: req.user._id }).sort({ completedAt: -1 }).limit(100).lean();
    return res.json({ success: true, assessments });
  } catch (error) {
    console.error("Assessment history error:", error);
    return res.status(500).json({ success: false, message: "Unable to load assessment history." });
  }
});

router.post("/assessments", ...studentOnly, async (_req, res) => {
  return res.status(410).json({ success: false, message: "Client-calculated scores are disabled. Submit question IDs and answers to POST /api/aptitude/submit so the server can grade the assessment." });
});

// =====================================================
// STUDENT PROFILE
// =====================================================

// GET profile
router.get(
  "/profile",
  ...studentOnly,
  getStudentProfile
);

// CREATE profile
router.post(
  "/profile",
  ...studentOnly,
  createStudentProfile
);

// UPDATE profile
router.put(
  "/profile",
  ...studentOnly,
  updateStudentProfile
);

// DELETE profile
router.delete(
  "/profile",
  ...studentOnly,
  deleteStudentProfile
);

module.exports = router;