const express = require('express');
const mongoose = require('mongoose');
const Notice = require('../models/Notice');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const router = express.Router();
const adminOnly = [protect, allowRoles('admin')];

router.get('/', async (_req, res) => {
  try {
    const now = new Date();
    const announcements = await Notice.find({ isPublished: true, targetAudience: { $in: ['all', 'students'] }, startsAt: { $lte: now }, $or: [{ expiresAt: null }, { expiresAt: { $gte: now } }] }).sort({ createdAt: -1 }).lean();
    res.json({ success: true, announcements });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Unable to load campus notices.' });
  }
});
router.get('/manage', ...adminOnly, async (_req, res) => {
  const announcements = await Notice.find({}).sort({ createdAt: -1 }).lean();
  res.json({ success: true, announcements });
});
router.post('/', ...adminOnly, async (req, res) => {
  try {
    const { title, message, content, category = 'general', targetAudience = 'all', isPinned = false, authorName = 'Placement Management System', startsAt, expiresAt, isPublished = true } = req.body;
    const noticeMessage = message || content;
    if (!title?.trim() || !noticeMessage?.trim()) return res.status(400).json({ success: false, message: 'Title and message are required.' });
    const notice = await Notice.create({ title, message: noticeMessage, category, targetAudience, isPinned: Boolean(isPinned), authorName, startsAt: startsAt || new Date(), expiresAt: expiresAt || null, isPublished: Boolean(isPublished), createdBy: req.user._id });
    res.status(201).json({ success: true, notice });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});
router.patch('/:id', ...adminOnly, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid notice ID.' });
  const allowed = ['title', 'message', 'category', 'targetAudience', 'isPinned', 'authorName', 'startsAt', 'expiresAt', 'isPublished'];
  const update = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
  if (req.body.content && !req.body.message) update.message = req.body.content;
  const notice = await Notice.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
  if (!notice) return res.status(404).json({ success: false, message: 'Notice not found.' });
  res.json({ success: true, notice });
});
router.delete('/:id', ...adminOnly, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid notice ID.' });
  const notice = await Notice.findByIdAndDelete(req.params.id);
  if (!notice) return res.status(404).json({ success: false, message: 'Notice not found.' });
  res.json({ success: true, message: 'Notice deleted.' });
});
module.exports = router;
