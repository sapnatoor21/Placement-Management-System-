const express = require("express");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

/*
===========================================================
PROFILE ROUTES
===========================================================
*/

/*
GET PROFILE

GET
/api/profile
*/

router.get("/", authMiddleware, async (req, res) => {
  try {
    /*
    authMiddleware normally puts logged-in user
    information inside req.user
    */

    const user = req.user;

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "User authentication information not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Profile fetched successfully",
      user,
    });
  } catch (error) {
    console.error("Get Profile Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch profile",
      error: error.message,
    });
  }
});


/*
===========================================================
TEST PROFILE ROUTE
===========================================================
*/

router.get("/test", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Profile routes are working",
  });
});


/*
===========================================================
EXPORT
===========================================================
*/

module.exports = router;