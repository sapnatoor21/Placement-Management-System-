const express = require('express');
const mongoose = require('mongoose');
const auth = require('../middleware/authMiddleware');
const StudentProfile = require('../models/StudentProfile');
const CareerTask = require('../models/CareerTask');
const CareerGuidanceReport = require('../models/CareerGuidanceReport');
const AptitudeAttempt = require('../models/AptitudeAttempt');
const Application = require('../models/Application');
const MockInterviewEvaluation = require('../models/MockInterviewEvaluation');
const ResumeDraft = require('../models/ResumeDraft');
const router = express.Router();
router.use(auth);
const uid = req => req.user._id;
const safeProfile = p => p ? ({ course:p.course, semester:p.semester, currentCGPA:p.currentCGPA, percentage:p.percentage, technicalSkills:p.technicalSkills || p.skills || [], softSkills:p.softSkills || [], projects:p.projects || [], internships:p.internships || [], certifications:p.certifications || [], careerInterests:p.careerInterests || p.interests || [], linkedinUrl:p.linkedinUrl, githubUrl:p.githubUrl, portfolioUrl:p.portfolioUrl }) : {};
async function ai(prompt, system) {
  if (!process.env.AI_API_KEY) throw new Error('AI_API_KEY is not configured in server/.env.');
  const url = process.env.AI_API_URL || `https://generativelanguage.googleapis.com/v1beta/models/${process.env.AI_MODEL || 'gemini-3.8-flash'}:generateContent`;
  const response = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json','x-goog-api-key':process.env.AI_API_KEY}, body:JSON.stringify({systemInstruction:{parts:[{text:system}]},contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',maxOutputTokens:5000}}) });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data?.error?.message || `AI provider error (${response.status})`);
  const raw = data?.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('').trim();
  if (!raw) throw new Error('AI provider returned an empty response.');
  return JSON.parse(raw.replace(/^```json\s*/i,'').replace(/^```/,'').replace(/```$/,'').trim());
}
router.get('/recommendations', async(req,res)=>{try{const profile=await StudentProfile.findOne({user:uid(req)}).lean();if(!profile)return res.json({success:true,recommendations:[],message:'Complete your profile to receive recommendations.'});const drives=await require('../models/PlacementDrive').find({isActive:true,status:'Open',...(profile.course?{$or:[{eligibleCourses:{$size:0}},{eligibleCourses:profile.course}]}:{})}).sort({createdAt:-1}).limit(100).lean();const studentSkills=(profile.technicalSkills||profile.skills||[]).map(x=>String(x).toLowerCase());const recommendations=drives.filter(d=>(!d.applicationDeadline||new Date(d.applicationDeadline)>=new Date())&&Number(profile.currentCGPA||0)>=Number(d.minCGPA||0)&&Number(profile.backlogs||0)<=Number(d.maxBacklogs||0)).map(d=>{const required=(d.skills||[]).map(x=>String(x).toLowerCase());const matched=required.filter(x=>studentSkills.some(s=>s===x||s.includes(x)||x.includes(s)));return {...d,matchScore:required.length?Math.round(matched.length/required.length*100):null,matchedSkills:matched,matchReasons:[...(d.eligibleCourses?.length?['Course eligibility matches']:[]),...(required.length?[`${matched.length} of ${required.length} listed skills match`]:[]),`CGPA requirement: ${d.minCGPA||0}`]};}).sort((a,b)=>(b.matchScore??0)-(a.matchScore??0));res.json({success:true,recommendations});}catch(e){res.status(500).json({success:false,message:'Unable to build recommendations.'});}});
router.get('/dashboard', async (req,res)=>{
 try {
  const studentId=uid(req);
  const [profile,tasks,aptitude,interviews,applications,draft,reports] = await Promise.all([
   StudentProfile.findOne({user:studentId}).lean(), CareerTask.find({studentId}).sort({dueDate:1,createdAt:-1}).limit(100).lean(), AptitudeAttempt.find({studentId}).sort({completedAt:-1}).limit(10).lean(), MockInterviewEvaluation.find({studentId}).sort({createdAt:-1}).limit(10).lean(), Application.countDocuments({studentId}), ResumeDraft.findOne({user:studentId}).lean(), CareerGuidanceReport.find({studentId}).sort({createdAt:-1}).limit(3).lean()
  ]);
  const done=tasks.filter(t=>t.status==='Completed').length;
  const completedDays=new Set(tasks.filter(t=>t.status==='Completed').map(t=>new Date(t.updatedAt).toISOString().slice(0,10)));
  let currentStreak=0;const dayCursor=new Date();dayCursor.setHours(0,0,0,0);
  if(!completedDays.has(dayCursor.toISOString().slice(0,10)))dayCursor.setDate(dayCursor.getDate()-1);
  while(completedDays.has(dayCursor.toISOString().slice(0,10))&&currentStreak<365){currentStreak++;dayCursor.setDate(dayCursor.getDate()-1);}
  const upcomingDeadlines=tasks.filter(t=>t.status!=='Completed'&&t.dueDate&&new Date(t.dueDate)>=new Date()).sort((a,b)=>new Date(a.dueDate)-new Date(b.dueDate)).slice(0,6);
  const profileScore=Number(profile?.profileCompletion)||0;
  const aptitudeScore=aptitude.length?Math.round(aptitude.reduce((s,a)=>s+(Number(a.percentage)||0),0)/aptitude.length):0;
  const interviewScore=interviews.length?Math.round(interviews.reduce((s,a)=>s+(Number(a.evaluation?.score)||0),0)/interviews.length):0;
  const resumeReady=Boolean(draft?.data && Object.values(draft.data).some(v=>String(v||'').trim()));
  const readiness=Math.round(profileScore*.25 + Math.min(100,done*10)*.2 + aptitudeScore*.2 + interviewScore*.2 + (resumeReady?100:0)*.15);
  res.json({success:true,dashboard:{readinessScore:readiness,profileCompletion:profileScore,taskCount:tasks.length,completedTasks:done,pendingTasks:tasks.filter(t=>t.status!=='Completed').length,taskProgress:tasks.length?Math.round(done/tasks.length*100):0,currentStreak,upcomingDeadlines,aptitudeAverage:aptitudeScore,interviewAverage:interviewScore,applicationCount:applications,hasResumeDraft:resumeReady,skills:safeProfile(profile).technicalSkills,improveSkills:[],tasks,recentAssessments:aptitude.slice(0,5),recentInterviews:interviews.slice(0,5),recentReports:reports}});
 } catch(e){res.status(500).json({success:false,message:'Unable to load career dashboard.',error:process.env.NODE_ENV==='development'?e.message:undefined});}
});
router.get('/tasks', async(req,res)=>{const tasks=await CareerTask.find({studentId:uid(req)}).sort({dueDate:1,createdAt:-1}).lean();res.json({success:true,tasks});});
router.post('/tasks', async(req,res)=>{try{const {title,description,phase,priority,dueDate,notes}=req.body;if(!String(title||'').trim())return res.status(400).json({success:false,message:'Task title is required.'});const task=await CareerTask.create({studentId:uid(req),title,description,phase,priority,dueDate:dueDate||null,notes});res.status(201).json({success:true,task});}catch(e){res.status(400).json({success:false,message:e.message});}});
router.patch('/tasks/:id', async(req,res)=>{if(!mongoose.isValidObjectId(req.params.id))return res.status(400).json({success:false,message:'Invalid task ID.'});const allowed=['title','description','phase','priority','status','dueDate','notes'];const patch={};for(const k of allowed)if(req.body[k]!==undefined)patch[k]=req.body[k];const task=await CareerTask.findOneAndUpdate({_id:req.params.id,studentId:uid(req)},{$set:patch},{new:true,runValidators:true});if(!task)return res.status(404).json({success:false,message:'Task not found.'});res.json({success:true,task});});
router.delete('/tasks/:id', async(req,res)=>{const r=await CareerTask.deleteOne({_id:req.params.id,studentId:uid(req)});res.json({success:r.deletedCount===1});});
router.post('/guidance', async(req,res)=>{try{const profile=await StudentProfile.findOne({user:uid(req)}).lean();const role=String(req.body.targetRole||'').trim()||'Suitable entry-level roles';const context={profile:safeProfile(profile),targetRole:role};const report=await ai(JSON.stringify(context),'You are a realistic campus placement career counsellor. Use only supplied facts. Never invent qualifications, skills, projects, internships, certificates, vacancies or achievements. If information is missing, state it. Return JSON with summary, profileAnalysis, careerPaths (array of {role,reason}), strengths (array), existingSkills (array), skillsToImprove (array), missingSkills (array), technicalRoadmap (array), softSkillAdvice (array), projectIdeas (array), internshipAdvice (array), resumeSuggestions (array), interviewPlan (array), resources (array of {title,url,topic,reason}; only include URLs you are confident are official and valid, otherwise leave url empty), plan30Days (array), plan60Days (array), plan90Days (array), nextActions (array). No guaranteed jobs or salary claims.');const saved=await CareerGuidanceReport.create({studentId:uid(req),targetRole:role,report});res.status(201).json({success:true,guidance:report,reportId:saved._id});}catch(e){res.status(502).json({success:false,message:'Career guidance could not be generated.',error:process.env.NODE_ENV==='development'?e.message:undefined});}});
router.get('/reports',async(req,res)=>{const reports=await CareerGuidanceReport.find({studentId:uid(req)}).sort({createdAt:-1}).limit(30).lean();res.json({success:true,reports});});
router.get('/reports/:id',async(req,res)=>{const report=await CareerGuidanceReport.findOne({_id:req.params.id,studentId:uid(req)}).lean();if(!report)return res.status(404).json({success:false,message:'Report not found.'});res.json({success:true,report});});
router.post('/skill-gap',async(req,res)=>{try{const profile=await StudentProfile.findOne({user:uid(req)}).lean();const role=String(req.body.targetRole||'').trim();if(!role)return res.status(400).json({success:false,message:'Target role is required.'});const result=await ai(JSON.stringify({targetRole:role,student:safeProfile(profile)}),'Compare the student profile to a typical entry-level version of the target role. Do not assume unlisted skills. Return JSON with presentSkills, improveSkills, missingSkills; each item has name, currentLevel, requiredLevel, priority, resourceTitle, resourceUrl, practiceActivity. Label current level as unknown if not explicitly given.');res.json({success:true,skillGap:result});}catch(e){res.status(502).json({success:false,message:'Skill gap analysis unavailable.',error:process.env.NODE_ENV==='development'?e.message:undefined});}});
module.exports=router;
