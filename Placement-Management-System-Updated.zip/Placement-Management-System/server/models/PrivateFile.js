const mongoose=require('mongoose');
const versionSchema=new mongoose.Schema({version:Number,url:String,publicId:String,bytes:Number,mimeType:String,originalName:String,createdAt:{type:Date,default:Date.now}},{_id:true});
const schema=new mongoose.Schema({owner:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,index:true},name:{type:String,required:true,maxlength:180},folder:{type:String,default:'My Files',maxlength:100},mimeType:String,bytes:Number,url:String,publicId:String,versions:{type:[versionSchema],default:[]},share:{enabled:{type:Boolean,default:false},token:{type:String,default:''},expiresAt:Date,permissions:{type:String,enum:['view','download'],default:'view'}}},{timestamps:true});
schema.index({owner:1,updatedAt:-1});
module.exports=mongoose.models.PrivateFile||mongoose.model('PrivateFile',schema);
