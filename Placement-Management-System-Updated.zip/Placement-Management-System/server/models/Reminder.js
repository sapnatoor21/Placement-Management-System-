const mongoose=require('mongoose');
const schema=new mongoose.Schema({user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,index:true},title:{type:String,required:true,trim:true,maxlength:180},description:{type:String,default:''},dueAt:{type:Date,required:true,index:true},status:{type:String,enum:['pending','sent','completed'],default:'pending'},emailSentAt:Date},{timestamps:true});
schema.index({status:1,dueAt:1});
module.exports=mongoose.models.Reminder||mongoose.model('Reminder',schema);
