const mongoose = require("mongoose");

const studentProfileSchema = new mongoose.Schema(
  {
    // =====================================================
    // USER
    // =====================================================

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true,
    },

    // =====================================================
    // PERSONAL INFORMATION
    // =====================================================

    fullName: {
      type: String,
      default: "",
      trim: true,
    },

    gender: {
      type: String,
      default: "",
      trim: true,
    },

    phone: {
      type: String,
      default: "",
      trim: true,
    },

    address: {
      type: String,
      default: "",
      trim: true,
    },

    city: {
      type: String,
      default: "",
      trim: true,
    },

    state: {
      type: String,
      default: "",
      trim: true,
    },

    // =====================================================
    // ACADEMIC INFORMATION
    // =====================================================

    enrollmentNumber: {
      type: String,
      default: "",
      trim: true,
    },

    collegeName: {
      type: String,
      default: "",
      trim: true,
    },

    course: {
      type: String,
      default: "",
      trim: true,
    },

    semester: {
      type: String,
      default: "",
      trim: true,
    },

    specialization: {
      type: String,
      default: "",
      trim: true,
    },

    graduationYear: {
      type: Number,
      default: null,
    },

    tenthPercentage: {
      type: Number,
      default: null,
    },

    twelfthPercentage: {
      type: Number,
      default: null,
    },

    graduationPercentage: {
      type: Number,
      default: null,
    },

    currentCGPA: {
      type: Number,
      default: null,
      min: 1,
      max: 10,
    },

    // =====================================================
    // SKILLS
    // =====================================================

    technicalSkills: {
      type: [String],
      default: [],
    },
    professionalSummary: { type: String, default: "", maxlength: 2000 },
    backlogs: { type: Number, default: 0, min: 0 },

    softSkills: {
      type: [String],
      default: [],
    },

    programmingLanguages: {
      type: [String],
      default: [],
    },

    // =====================================================
    // PROJECTS
    // =====================================================

    projects: {
      type: [
        {
          title: {
            type: String,
            default: "",
          },

          description: {
            type: String,
            default: "",
          },

          technologies: {
            type: [String],
            default: [],
          },
        },
      ],
      default: [],
    },

    // =====================================================
    // CERTIFICATIONS
    // =====================================================

    certifications: {
      type: [
        {
          name: {
            type: String,
            default: "",
          },

          issuer: {
            type: String,
            default: "",
          },

          year: {
            type: Number,
            default: null,
          },
        },
      ],
      default: [],
    },

    // =====================================================
    // SOCIAL / PORTFOLIO LINKS
    // =====================================================

    linkedinUrl: {
      type: String,
      default: "",
      trim: true,
    },

    githubUrl: {
      type: String,
      default: "",
      trim: true,
    },

    portfolioUrl: {
      type: String,
      default: "",
      trim: true,
    },

    // =====================================================
    // RESUME
    // =====================================================

    resumeUrl: {
      type: String,
      default: "",
      trim: true,
    },

    // =====================================================
    // PLACEMENT
    // =====================================================

    placementStatus: {
      type: String,
      default:
        "Looking for Opportunities",
      trim: true,
    },

    // =====================================================
    // PROFILE COMPLETION
    // =====================================================

    profileCompletion: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },

    isProfileComplete: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// =====================================================
// MODEL
// =====================================================

const StudentProfile =
  mongoose.model(
    "StudentProfile",
    studentProfileSchema
  );

module.exports =
  StudentProfile;