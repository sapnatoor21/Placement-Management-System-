const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  targetRole: { type: String, default: 'General career direction', maxlength: 160 },
  report: { type: mongoose.Schema.Types.Mixed, required: true },
}, { timestamps: true });
schema.index({ studentId: 1, createdAt: -1 });
module.exports = mongoose.models.CareerGuidanceReport || mongoose.model('CareerGuidanceReport', schema);
