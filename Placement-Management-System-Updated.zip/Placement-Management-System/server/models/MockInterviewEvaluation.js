const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  question: { type: String, required: true, trim: true },
  category: { type: String, enum: ['technical', 'hr'], default: 'technical' },
  company: { type: String, default: '' },
  role: { type: String, default: '' },
  answer: { type: String, required: true },
  evaluation: { type: mongoose.Schema.Types.Mixed, required: true },
  provider: { type: String, default: 'configured-llm' },
}, { timestamps: true });
schema.index({ studentId:  1, createdAt: -1 });
module.exports = mongoose.models.MockInterviewEvaluation || mongoose.model('MockInterviewEvaluation', schema);
