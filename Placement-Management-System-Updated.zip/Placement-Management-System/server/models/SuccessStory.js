const mongoose = require('mongoose');
const successStorySchema = new mongoose.Schema({
  studentName: { type: String, required: true, trim: true },
  course: { type: String, required: true, trim: true },
  batch: { type: String, default: '' },
  company: { type: String, required: true, trim: true },
  role: { type: String, required: true, trim: true },
  package: { type: String, default: '' },
  testimonial: { type: String, default: '', maxlength: 1500 },
  isVerified: { type: Boolean, default: false },
  isPublished: { type: Boolean, default: false },
  verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });
module.exports = mongoose.models.SuccessStory || mongoose.model('SuccessStory', successStorySchema);
