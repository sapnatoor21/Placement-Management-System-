const mongoose = require('mongoose');
const emailLogSchema = new mongoose.Schema({
  senderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  senderRole: { type: String, enum: ['admin', 'recruiter'], required: true },
  senderName: { type: String, default: '' },
  recipientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  recipientName: { type: String, default: '' },
  recipientEmail: { type: String, required: true, lowercase: true, trim: true },
  subject: { type: String, required: true, maxlength: 180 },
  body: { type: String, required: true, maxlength: 10000 },
  status: { type: String, enum: ['sent', 'failed'], default: 'sent', index: true },
  provider: { type: String, default: '' },
  providerMessageId: { type: String, default: '' },
  errorMessage: { type: String, default: '' },
}, { timestamps: true });
emailLogSchema.index({ createdAt: -1 });
module.exports = mongoose.models.EmailLog || mongoose.model('EmailLog', emailLogSchema);
