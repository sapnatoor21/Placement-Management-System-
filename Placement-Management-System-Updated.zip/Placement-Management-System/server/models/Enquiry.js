const mongoose = require('mongoose');

const enquirySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 180 },
  phone: { type: String, trim: true, default: '', maxlength: 30 },
  subject: { type: String, required: true, trim: true, maxlength: 180 },
  message: { type: String, required: true, trim: true, maxlength: 5000 },
  status: { type: String, enum: ['New', 'In Progress', 'Replied', 'Resolved'], default: 'New', index: true },
  adminNotes: { type: String, default: '', maxlength: 3000 },
  repliedAt: { type: Date, default: null },
  emailHistory: [{ senderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, senderName: String, senderRole: String, to: String, subject: String, body: String, status: { type: String, enum: ['sent', 'failed'] }, provider: String, messageId: String, errorMessage: String, sentAt: { type: Date, default: Date.now } }],
  handledBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });

enquirySchema.index({ createdAt: -1 });
module.exports = mongoose.models.Enquiry || mongoose.model('Enquiry', enquirySchema);
