const mongoose = require('mongoose');
const noticeSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 180 },
  message: { type: String, required: true, trim: true, maxlength: 4000 },
  category: { type: String, default: 'general' },
  targetAudience: { type: String, enum: ['all', 'students', 'recruiters'], default: 'all' },
  isPinned: { type: Boolean, default: false },
  authorName: { type: String, default: 'Placement Management System' },
  isPublished: { type: Boolean, default: false, index: true },
  startsAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, default: null },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });
module.exports = mongoose.models.Notice || mongoose.model('Notice', noticeSchema);
