const mongoose = require('mongoose');
const siteSettingsSchema = new mongoose.Schema({
  key: { type: String, unique: true, default: 'public' },
  institutionName: { type: String, default: 'Kanya Maha Vidyalaya (Autonomous)' },
  address: { type: String, default: 'Vidyalaya Marg, Jalandhar - 144004, Punjab, India', maxlength: 300 },
  phonePrimary: { type: String, default: '+91 181 2296605', maxlength: 40 },
  phoneSecondary: { type: String, default: '+91 181 2296606', maxlength: 40 },
  email: { type: String, default: 'placement@kmv.ac.in', maxlength: 180 },
  latitude: { type: Number, default: 31.325986, min: -90, max: 90 },
  longitude: { type: Number, default: 75.576262, min: -180, max: 180 },
  officialWebsite: { type: String, default: 'https://www.kmvjalandhar.ac.in/', maxlength: 500 },
  placementGallery: { type: String, default: 'https://www.kmvjalandhar.ac.in/photo_galleries/placement-cell/', maxlength: 500 },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });
module.exports = mongoose.models.SiteSettings || mongoose.model('SiteSettings', siteSettingsSchema);
