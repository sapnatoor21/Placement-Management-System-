const mongoose = require('mongoose');
const messageSchema = new mongoose.Schema({ role: { type: String, enum: ['user','assistant'], required: true }, content: { type: String, required: true, maxlength: 12000 }, createdAt: { type: Date, default: Date.now } }, { _id: true });
const schema = new mongoose.Schema({ userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null, index: true }, sessionId: { type: String, default: '', index: true }, title: { type: String, default: 'New conversation', maxlength: 120 }, messages: { type: [messageSchema], default: [] } }, { timestamps: true });
schema.index({ userId: 1, updatedAt: -1 });
module.exports = mongoose.models.AIConversation || mongoose.model('AIConversation', schema);
