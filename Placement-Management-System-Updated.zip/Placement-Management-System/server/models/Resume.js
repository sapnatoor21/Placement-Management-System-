const mongoose = require("mongoose");

const resumeSchema = new mongoose.Schema(
  {
    // =====================================================
    // USER
    // =====================================================

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    // =====================================================
    // RESUME BASIC INFORMATION
    // =====================================================

    title: {
      type: String,
      default: "My Resume",
      trim: true,
    },

    originalName: {
      type: String,
      required: true,
      trim: true,
    },

    fileUrl: {
      type: String,
      required: true,
    },

    publicId: {
      type: String,
      default: "",
    },

    fileType: {
      type: String,
      enum: ["pdf", "doc", "docx"],
      required: true,
    },

    // =====================================================
    // VERSION
    // =====================================================

    version: {
      type: Number,
      default: 1,
      min: 1,
    },

    // =====================================================
    // DEFAULT RESUME
    // =====================================================

    isDefault: {
      type: Boolean,
      default: false,
    },

    // =====================================================
    // RECRUITER VISIBILITY
    // =====================================================

    isVisible: {
      type: Boolean,
      default: true,
    },

    // =====================================================
    // ADMIN APPROVAL
    // =====================================================

    approvalStatus: {
      type: String,
      enum: [
        "Pending",
        "Approved",
        "Rejected",
      ],
      default: "Pending",
    },

    adminComment: {
      type: String,
      default: "",
      trim: true,
    },

    // =====================================================
    // ATS ANALYSIS
    // =====================================================

    atsScore: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },

    aiFeedback: {
      type: String,
      default: "",
    },
    analysisType: {
      type: String,
      enum: ["rule-based", "ai", "not-analysed"],
      default: "rule-based",
    },

    grammarIssues: {
      type: [String],
      default: [],
    },

    extractedSkills: {
      type: [String],
      default: [],
    },

    // =====================================================
    // PARSED DATA
    // =====================================================

    parsedData: {
      text: {
        type: String,
        default: "",
      },

      name: {
        type: String,
        default: "",
      },

      email: {
        type: String,
        default: "",
      },

      phone: {
        type: String,
        default: "",
      },

      education: {
        type: String,
        default: "",
      },

      experience: {
        type: String,
        default: "",
      },
    },
  },
  {
    timestamps: true,
  }
);

// =====================================================
// INDEXES
// =====================================================

resumeSchema.index({
  user: 1,
  createdAt: -1,
});

resumeSchema.index({
  user: 1,
  isDefault: 1,
});

resumeSchema.index({
  isVisible: 1,
  approvalStatus: 1,
});

const Resume = mongoose.model(
  "Resume",
  resumeSchema
);

module.exports = Resume;