const mongoose = require('mongoose');
const resourceSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 180 },
  description: { type: String, default: '', maxlength: 2000 },
  category: { type: String, enum: ['programming','dsa','aptitude','communication','dbms','web_development','artificial_intelligence','data_science','interview_preparation','resume_preparation','technical','resume_templates','hr_interview'], required: true },
  fileType: { type: String, required: true },
  fileSize: { type: String, default: '' },
  fileUrl: { type: String, required: true },
  downloadCount: { type: Number, default: 0, min: 0 },
  isPublished: { type: Boolean, default: false, index: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });
module.exports = mongoose.models.Resource || mongoose.model('Resource', resourceSchema);
