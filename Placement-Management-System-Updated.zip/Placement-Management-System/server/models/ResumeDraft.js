const mongoose = require('mongoose');
const schema = new mongoose.Schema({ user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true, index: true }, data: { type: mongoose.Schema.Types.Mixed, required: true } }, { timestamps: true });
module.exports = mongoose.models.ResumeDraft || mongoose.model('ResumeDraft', schema);
