const mongoose = require('mongoose');
const notificationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 180 },
  message: { type: String, required: true, trim: true, maxlength: 1000 },
  type: { type: String, default: 'general' },
  link: { type: String, default: '' },
  isRead: { type: Boolean, default: false, index: true },
}, { timestamps: true });
notificationSchema.index({ userId: 1, createdAt: -1 });
module.exports = mongoose.models.Notification || mongoose.model('Notification', notificationSchema);
