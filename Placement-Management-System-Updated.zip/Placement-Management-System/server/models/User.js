
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },

    password: {
      type: String,
      required: true,
      select: false,
    },

    role: {
      type: String,
      enum: ["student", "recruiter", "admin"],
      default: "student",
      required: true,
    },

    isEmailVerified: {
      type: Boolean,
      default: false,
    },
    isActive: { type: Boolean, default: true },
    loginOTP: { type: String, select: false, default: null },
    loginOTPExpires: { type: Date, select: false, default: null },
    resetPasswordOTP: { type: String, select: false, default: null },
    resetPasswordOTPExpires: { type: Date, select: false, default: null },

    profilePhoto: {
      type: String,
      default: "",
    },

    phone: {
      type: String,
      default: "",
    },

    course: {
      type: String,
      default: "",
    },

    semester: {
      type: String,
      default: "",
    },

    college: {
      type: String,
      default: "Kanya Mahavidyalaya, Jalandhar",
    },

    resumeUrl: {
      type: String,
      default: "",
    },
    companyName: { type: String, default: "", trim: true },
    industry: { type: String, default: "", trim: true },
    website: { type: String, default: "", trim: true },
    location: { type: String, default: "", trim: true },
    contactPerson: { type: String, default: "", trim: true },
    designation: { type: String, default: "", trim: true },
    aboutCompany: { type: String, default: "", trim: true },
  },
  {
    timestamps: true,
  }
);

module.exports =
  mongoose.models.User || mongoose.model("User", userSchema);
