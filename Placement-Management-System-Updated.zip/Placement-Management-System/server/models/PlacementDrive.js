
const mongoose = require("mongoose");

const placementDriveSchema = new mongoose.Schema(
  {
    companyName: {
      type: String,
      required: true,
      trim: true,
    },

    jobRole: {
      type: String,
      required: true,
      trim: true,
    },

    description: {
      type: String,
      default: "",
    },

    package: {
      type: String,
      default: "",
    },

    ctc: {
      type: Number,
      default: null,
      min: 0,
    },

    location: {
      type: String,
      default: "",
    },

    jobType: {
      type: String,
      enum: ["Full-time", "Internship", "Part-time", "Contract", ""],
      default: "Full-time",
    },
    opportunityType: {
      type: String,
      enum: ["All", "Internship", "Full-time", "Part-time", ""],
      default: "",
    },

    eligibility: {
      type: String,
      default: "",
    },

    eligibleCourses: {
      type: [String],
      default: [],
    },
    skills: { type: [String], default: [] },
    driveDate: { type: Date, default: null },

    minCGPA: {
      type: Number,
      default: 0,
      min: 0,
      max: 10,
    },
    maxBacklogs: { type: Number, default: 0, min: 0 },

    applicationDeadline: {
      type: Date,
      default: null,
    },

    status: {
      type: String,
      enum: ["Draft", "Open", "Closed"],
      default: "Open",
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    recruiter: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
      index: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

module.exports =
  mongoose.models.PlacementDrive ||
  mongoose.model("PlacementDrive", placementDriveSchema);
