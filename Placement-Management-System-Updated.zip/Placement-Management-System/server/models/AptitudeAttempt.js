const mongoose = require('mongoose');
const aptitudeAttemptSchema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  testType: { type: String, default: 'aptitude' },
  title: { type: String, required: true, trim: true },
  score: { type: Number, required: true, min: 0 },
  totalMarks: { type: Number, required: true, min: 1 },
  percentage: { type: Number, required: true, min: 0, max: 100 },
  details: { type: mongoose.Schema.Types.Mixed, default: {} },
  completedAt: { type: Date, default: Date.now },
}, { timestamps: true });
aptitudeAttemptSchema.index({ studentId: 1, completedAt: -1 });
module.exports = mongoose.models.AptitudeAttempt || mongoose.model('AptitudeAttempt', aptitudeAttemptSchema);
