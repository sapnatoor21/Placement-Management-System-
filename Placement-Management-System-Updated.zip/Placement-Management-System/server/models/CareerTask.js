const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 180 },
  description: { type: String, default: '', maxlength: 2000 },
  phase: { type: String, enum: ['Foundations','Aptitude','Portfolio','Interview','Personal'], default: 'Personal' },
  priority: { type: String, enum: ['Low','Medium','High'], default: 'Medium' },
  status: { type: String, enum: ['Pending','In Progress','Completed'], default: 'Pending' },
  dueDate: { type: Date, default: null },
  notes: { type: String, default: '', maxlength: 3000 },
}, { timestamps: true });
schema.index({ studentId: 1, createdAt: -1 });
module.exports = mongoose.models.CareerTask || mongoose.model('CareerTask', schema);
