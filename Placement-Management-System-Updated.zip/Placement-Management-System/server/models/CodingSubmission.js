const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  problemId: { type: String, required: true, trim: true },
  languageId: { type: Number, required: true },
  sourceCode: { type: String, required: true, maxlength: 50000 },
  status: { type: String, default: 'Submitted' },
  verdict: { type: String, default: 'Pending' },
  stdout: { type: String, default: '' },
  stderr: { type: String, default: '' },
  compileOutput: { type: String, default: '' },
  time: { type: String, default: '' },
  memory: { type: Number, default: null },
}, { timestamps: true });
schema.index({ studentId: 1, createdAt: -1 });
module.exports = mongoose.models.CodingSubmission || mongoose.model('CodingSubmission', schema);
