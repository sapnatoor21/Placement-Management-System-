const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  category: { type: String, enum: ['Quantitative Aptitude','Logical Reasoning','English','Computer Fundamentals','DBMS','OOP','DSA'], required: true, index: true },
  difficulty: { type: String, enum: ['Easy','Medium','Hard'], default: 'Medium' },
  question: { type: String, required: true, trim: true, maxlength: 1500 },
  options: { type: [String], validate: v => Array.isArray(v) && v.length >= 2 && v.length <= 6 },
  correctAnswer: { type: Number, required: true, min: 0 },
  explanation: { type: String, default: '', maxlength: 2000 },
  isPublished: { type: Boolean, default: true, index: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });
schema.pre('validate', function(next) { if (this.options && this.correctAnswer >= this.options.length) this.invalidate('correctAnswer', 'Correct answer index must match one of the available options.'); next(); });
schema.index({ category: 1, isPublished: 1, difficulty: 1 });
module.exports = mongoose.models.AptitudeQuestion || mongoose.model('AptitudeQuestion', schema);
