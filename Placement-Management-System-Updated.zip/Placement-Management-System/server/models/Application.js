
const mongoose = require("mongoose");

const APPLICATION_STATUSES = [
  "Applied",
  "Under Review",
  "Shortlisted",
  "Written Test",
  "Technical Interview",
  "HR Interview",
  "Selected",
  "Rejected",
  "Withdrawn",
];

const timelineSchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: APPLICATION_STATUSES,
      required: true,
    },
    date: {
      type: Date,
      default: Date.now,
    },
    note: {
      type: String,
      default: "",
      maxlength: 1000,
    },
  },
  { _id: false }
);

const scheduleSchema = new mongoose.Schema(
  {
    title: { type: String, default: "" },
    round: { type: String, default: "" },
    date: { type: Date, default: null },
    time: { type: String, default: "", maxlength: 80 },
    venue: { type: String, default: "" },
    meetLink: { type: String, default: "" },
  },
  { _id: false }
);

const applicationSchema = new mongoose.Schema(
  {
    studentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    driveId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "PlacementDrive",
      required: true,
      index: true,
    },

    status: {
      type: String,
      enum: APPLICATION_STATUSES,
      default: "Applied",
      required: true,
    },

    appliedAt: {
      type: Date,
      default: Date.now,
    },

    roundsCleared: {
      type: [String],
      default: [],
    },

    resumeUrl: {
      type: String,
      default: "",
    },
    recruiterFeedback: { type: String, default: "", maxlength: 2000 },
    statusUpdatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },

    admitCardUrl: {
      type: String,
      default: "",
    },

    offerLetterUrl: {
      type: String,
      default: "",
    },

    timeline: {
      type: [timelineSchema],
      default: [],
    },

    nextRound: {
      type: scheduleSchema,
      default: null,
    },

    notes: {
      type: String,
      default: "",
      maxlength: 2000,
    },

    withdrawnAt: {
      type: Date,
      default: null,
    },

    statusUpdatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

applicationSchema.index(
  { studentId: 1, driveId: 1 },
  { unique: true }
);

applicationSchema.index({ studentId: 1, status: 1 });

module.exports =
  mongoose.models.Application ||
  mongoose.model("Application", applicationSchema);

module.exports.APPLICATION_STATUSES = APPLICATION_STATUSES;
