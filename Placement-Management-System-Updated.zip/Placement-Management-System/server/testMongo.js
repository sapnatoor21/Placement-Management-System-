const { MongoClient, ServerApiVersion } = require("mongodb");

const username = "sapnaonline21";
const password = "YOUR_NEW_MONGODB_PASSWORD";

const uri =
  `mongodb://${username}:${password}` +
  `@ac-kulzabx-shard-00-00.3zh9ggk.mongodb.net:27017,` +
  `ac-kulzabx-shard-00-01.3zh9ggk.mongodb.net:27017,` +
  `ac-kulzabx-shard-00-02.3zh9ggk.mongodb.net:27017/` +
  `kmv_placement_cell` +
  `?tls=true` +
  `&replicaSet=atlas-xxxxx-shard-0` +
  `&authSource=admin` +
  `&retryWrites=true` +
  `&w=majority`;

const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },

  serverSelectionTimeoutMS: 15000,

  connectTimeoutMS: 15000,
});

async function run() {
  try {
    console.log("🔄 Connecting directly to MongoDB shards...");

    await client.connect();

    await client.db("admin").command({
      ping: 1,
    });

    console.log("============================================");
    console.log("✅ MongoDB CONNECTION SUCCESSFUL!");
    console.log("============================================");
  } catch (error) {
    console.log("============================================");
    console.log("❌ MongoDB CONNECTION FAILED");
    console.log("============================================");
    console.log(error.message);
  } finally {
    await client.close();
  }
}

run();