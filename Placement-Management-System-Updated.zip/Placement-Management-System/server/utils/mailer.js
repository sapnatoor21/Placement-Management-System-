const { sendEmail } = require('./emailService');

async function sendApplicationUpdate(to, companyName, status, jobRole, note = '') {
  const subject = `Placement update: ${status} - ${companyName || 'Campus Recruitment'}`;
  const text = `Your application for ${jobRole || 'the role'} at ${companyName || 'the company'} has been marked as ${status}.${note ? `\n\nNote: ${note}` : ''}\n\nPlease sign in to your Placement Management System dashboard for details.`;
  return sendEmail({ to, subject, text, html: `<div style="font-family:Arial,sans-serif;color:#16345c"><h2>Placement application update</h2><p>Your application for <strong>${escapeHtml(jobRole || 'the role')}</strong> at <strong>${escapeHtml(companyName || 'the company')}</strong> has been marked as <strong>${escapeHtml(status)}</strong>.</p>${note ? `<p>${escapeHtml(note)}</p>` : ''}<p>Please sign in to your Placement Management System dashboard for details.</p></div>` });
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
module.exports = { sendEmail, sendApplicationUpdate };
