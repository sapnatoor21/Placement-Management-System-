const nodemailer = require('nodemailer');

function getSmtpConfig() {
  const host = process.env.SMTP_HOST || process.env.MAIL_HOST;
  const port = Number(process.env.SMTP_PORT || process.env.MAIL_PORT || 587);
  const user = process.env.SMTP_USER || process.env.MAIL_USER;
  const pass = process.env.SMTP_PASS || process.env.MAIL_PASS;
  if (!host || !user || !pass) return null;
  return { host, port, secure: String(process.env.SMTP_SECURE || (port === 465)).toLowerCase() === 'true', auth: { user, pass }, connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 20000 };
}

async function sendEmail({ to, subject, text, html, replyTo }) {
  const recipients = (Array.isArray(to) ? to : [to]).map((value) => String(value || '').trim()).filter(Boolean);
  if (!recipients.length || recipients.some((email) => !/^\S+@\S+\.\S+$/.test(email))) throw new Error('A valid recipient email address is required.');
  if (!subject || String(subject).trim().length > 180) throw new Error('Email subject is required and must be under 180 characters.');
  if (!text && !html) throw new Error('Email body cannot be empty.');

  const provider = String(process.env.EMAIL_PROVIDER || 'smtp').toLowerCase();
  const from = process.env.MAIL_FROM;
  if (!from || from.includes('.local') || from.includes('your-verified-domain')) throw new Error('Set MAIL_FROM to a real sender address that your selected email provider permits.');


  if (provider !== 'smtp') throw new Error(`Unsupported EMAIL_PROVIDER: ${provider}. Use smtp.`);
  const config = getSmtpConfig();
  if (!config) throw new Error('SMTP is not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS and MAIL_FROM in server/.env.');
  const transporter = nodemailer.createTransport(config);
  const info = await transporter.sendMail({ from, to: recipients.join(', '), subject: String(subject).trim(), text, html, replyTo: replyTo || process.env.MAIL_REPLY_TO || undefined });
  return { success: true, provider: 'smtp', messageId: info.messageId || '' };
}

async function verifyEmailConnection() {
  const provider = String(process.env.EMAIL_PROVIDER || 'smtp').toLowerCase();
  if (provider !== 'smtp') return { configured: false, provider, verified: false, message: 'Only SMTP email delivery is enabled. Set EMAIL_PROVIDER=smtp.' };
  const config = getSmtpConfig();
  if (!config || !process.env.MAIL_FROM) return { configured: false, provider: 'smtp', verified: false, message: 'SMTP credentials or MAIL_FROM are missing.' };
  const transporter = nodemailer.createTransport(config);
  try { await transporter.verify(); return { configured: true, provider: 'smtp', verified: true, message: 'SMTP connection verified.' }; }
  catch (error) { return { configured: true, provider: 'smtp', verified: false, message: error.message }; }
}

async function sendLoginOTP(email, otp) {
  return sendEmail({ to: email, subject: 'Placement Management System - Login OTP', text: `Your login OTP is ${otp}. It is valid for 10 minutes. Do not share this code.`, html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;color:#16345c"><h2 style="color:#102b50">Placement Management System</h2><h3>Login verification</h3><p>Your login code is:</p><div style="font-size:32px;font-weight:700;letter-spacing:8px;color:#0d6efd;padding:16px;background:#f3f7fc;text-align:center;border-radius:10px">${otp}</div><p>This code expires in 10 minutes. Do not share it.</p></div>` });
}
async function sendPasswordResetOTP(email, otp) {
  return sendEmail({ to: email, subject: 'Placement Management System - Password Reset OTP', text: `Your password reset OTP is ${otp}. It is valid for 10 minutes.`, html: `<p>Your password reset OTP is <strong>${otp}</strong>. It is valid for 10 minutes.</p>` });
}

module.exports = { sendEmail, sendLoginOTP, sendPasswordResetOTP, verifyEmailConnection };
