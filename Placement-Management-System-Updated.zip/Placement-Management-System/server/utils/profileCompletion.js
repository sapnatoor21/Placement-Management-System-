const calculateProfileCompletion = (profile) => {
  let completedSections = 0;
  const totalSections = 9;

  // 1. Personal Information
  if (
    profile.fullName &&
    profile.gender &&
    profile.phone &&
    profile.address &&
    profile.city &&
    profile.state
  ) {
    completedSections++;
  }

  // 2. College Information
  if (
    profile.collegeName &&
    profile.course &&
    profile.specialization &&
    profile.graduationYear
  ) {
    completedSections++;
  }

  // 3. Academic Information
  if (
    profile.tenthPercentage !== null &&
    profile.tenthPercentage !== undefined &&
    profile.twelfthPercentage !== null &&
    profile.twelfthPercentage !== undefined &&
    profile.graduationPercentage !== null &&
    profile.graduationPercentage !== undefined &&
    profile.currentCGPA !== null &&
    profile.currentCGPA !== undefined
  ) {
    completedSections++;
  }

  // 4. Technical Skills + Programming Languages
  if (
    Array.isArray(profile.technicalSkills) &&
    profile.technicalSkills.length > 0 &&
    Array.isArray(profile.programmingLanguages) &&
    profile.programmingLanguages.length > 0
  ) {
    completedSections++;
  }

  // 5. Soft Skills
  if (
    Array.isArray(profile.softSkills) &&
    profile.softSkills.length > 0
  ) {
    completedSections++;
  }

  // 6. Projects
  if (
    Array.isArray(profile.projects) &&
    profile.projects.length > 0
  ) {
    completedSections++;
  }

  // 7. Certifications
  if (
    Array.isArray(profile.certifications) &&
    profile.certifications.length > 0
  ) {
    completedSections++;
  }

  // 8. Professional Links
  if (
    profile.linkedinUrl &&
    profile.githubUrl
  ) {
    completedSections++;
  }

  // 9. Resume
  if (profile.resumeUrl) {
    completedSections++;
  }

  const completion = Math.round(
    (completedSections / totalSections) * 100
  );

  return completion;
};

module.exports = calculateProfileCompletion;