const StudentProfile = require("../models/StudentProfile");
const User = require("../models/User");

// =====================================================
// HELPER: PROFILE COMPLETION
// =====================================================

const calculateProfileCompletion = (
  profile
) => {
  const fields = [
    "fullName",
    "phone",
    "collegeName",
    "course",
    "semester",
    "currentCGPA",
    "technicalSkills",
    "projects",
    "certifications",
    "resumeUrl",
  ];

  let completed = 0;

  fields.forEach((field) => {
    const value = profile[field];

    if (
      value !== undefined &&
      value !== null &&
      String(value).trim() !== ""
    ) {
      completed++;
    }
  });

  const percentage = Math.round(
    (completed / fields.length) * 100
  );

  return {
    percentage,
    isComplete: percentage === 100,
  };
};

// =====================================================
// GET STUDENT PROFILE
// =====================================================

const getStudentProfile = async (
  req,
  res
) => {
  try {
    const userId =
      req.user.userId || req.user.id;

    const profile =
      await StudentProfile.findOne({
        user: userId,
      }).populate(
        "user",
        "-password"
      );

    if (!profile) {
      return res.status(404).json({
        success: false,
        message:
          "Student profile not found.",
      });
    }

    return res.status(200).json({
      success: true,
      message:
        "Student profile fetched successfully.",
      profile,
    });
  } catch (error) {
    console.error(
      "Get Student Profile Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Server error while fetching profile.",
    });
  }
};

// =====================================================
// CREATE STUDENT PROFILE
// =====================================================

const createStudentProfile = async (
  req,
  res
) => {
  try {
    const userId =
      req.user.userId || req.user.id;

    const existingProfile =
      await StudentProfile.findOne({
        user: userId,
      });

    if (existingProfile) {
      return res.status(400).json({
        success: false,
        message:
          "Student profile already exists.",
      });
    }

    const user =
      await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    const profile =
      await StudentProfile.create({
        user: userId,

        fullName:
          req.body.fullName ||
          user.name ||
          "",

        phone:
          req.body.phone ||
          user.phone ||
          "",

        address:
          req.body.address || "",

        city:
          req.body.city || "",

        state:
          req.body.state || "",

        collegeName:
          req.body.collegeName || "",

        course:
          req.body.course || "",

        semester:
          req.body.semester || "",

        gender:
          req.body.gender || "",

        specialization:
          req.body.specialization || "",

        graduationYear:
          req.body.graduationYear ||
          null,

        tenthPercentage:
          req.body.tenthPercentage ||
          null,

        twelfthPercentage:
          req.body.twelfthPercentage ||
          null,

        graduationPercentage:
          req.body.graduationPercentage ||
          null,

        currentCGPA:
          req.body.currentCGPA ||
          null,

        technicalSkills:
          req.body.technicalSkills ||
          [],

        softSkills:
          req.body.softSkills ||
          [],

        programmingLanguages:
          req.body.programmingLanguages ||
          [],

        projects:
          req.body.projects ||
          [],

        certifications:
          req.body.certifications ||
          [],

        linkedinUrl:
          req.body.linkedinUrl ||
          "",

        githubUrl:
          req.body.githubUrl ||
          "",

        portfolioUrl:
          req.body.portfolioUrl ||
          "",

        resumeUrl:
          req.body.resumeUrl ||
          "",

        placementStatus:
          req.body.placementStatus ||
          "Looking for Opportunities",
      });

    const completion =
      calculateProfileCompletion(
        profile
      );

    profile.profileCompletion =
      completion.percentage;

    profile.isProfileComplete =
      completion.isComplete;

    await profile.save();

    const populatedProfile =
      await StudentProfile.findById(
        profile._id
      ).populate(
        "user",
        "-password"
      );

    return res.status(201).json({
      success: true,
      message:
        "Student profile created successfully.",
      profile: populatedProfile,
    });
  } catch (error) {
    console.error(
      "Create Student Profile Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Server error while creating profile.",
    });
  }
};

// =====================================================
// UPDATE STUDENT PROFILE
// =====================================================

const updateStudentProfile = async (req, res) => {
  try {
    const userId = req.user._id || req.user.id || req.user.userId;
    const profile = await StudentProfile.findOne({ user: userId });
    if (!profile) return res.status(404).json({ success: false, message: "Student profile not found." });

    const body = req.body || {};
    const stringFields = ["address", "city", "state", "collegeName", "course", "semester", "specialization", "professionalSummary", "linkedinUrl", "githubUrl", "portfolioUrl", "resumeUrl", "enrollmentNumber", "gender"];
    for (const field of stringFields) {
      if (body[field] !== undefined) profile[field] = String(body[field] ?? "").trim();
    }

    const fullName = body.fullName ?? body.name;
    if (fullName !== undefined) {
      const cleanName = String(fullName).trim();
      if (cleanName.length < 2 || cleanName.length > 100) return res.status(400).json({ success: false, message: "Enter a valid full name." });
      profile.fullName = cleanName;
    }
    if (body.phone !== undefined) {
      const phone = String(body.phone).trim().replace(/^\+91\s?/, "");
      // Preserve an unchanged legacy/demo number so it does not block saves
      // in other profile sections. Validate a newly edited phone number.
      if (phone !== String(profile.phone || "") && !/^[6-9]\d{9}$/.test(phone)) {
        return res.status(400).json({ success: false, message: "Enter a valid 10-digit Indian mobile number." });
      }
      profile.phone = phone;
    }

    const numericFields = { currentCGPA: body.currentCGPA ?? body.cgpa, tenthPercentage: body.tenthPercentage, twelfthPercentage: body.twelfthPercentage, graduationPercentage: body.graduationPercentage, backlogs: body.backlogs, graduationYear: body.graduationYear };
    for (const [field, value] of Object.entries(numericFields)) {
      if (value === undefined) continue;
      if (value === null || value === "") {
        profile[field] = null;
        continue;
      }
      const number = Number(value);
      if (!Number.isFinite(number) || number < 0) return res.status(400).json({ success: false, message: `Invalid value for ${field}.` });
      if (field === "currentCGPA" && (number < 1 || number > 10)) return res.status(400).json({ success: false, message: "CGPA must be between 1 and 10, or left blank." });
      if (["tenthPercentage", "twelfthPercentage", "graduationPercentage"].includes(field) && number > 100) return res.status(400).json({ success: false, message: `${field} cannot exceed 100.` });
      profile[field] = number;
    }

    const skills = body.technicalSkills ?? body.skills;
    if (skills !== undefined) profile.technicalSkills = Array.isArray(skills) ? skills.map(String).map(x => x.trim()).filter(Boolean) : String(skills).split(",").map(x => x.trim()).filter(Boolean);
    if (body.softSkills !== undefined) profile.softSkills = Array.isArray(body.softSkills) ? body.softSkills.map(String).map(x => x.trim()).filter(Boolean) : String(body.softSkills).split(",").map(x => x.trim()).filter(Boolean);
    if (body.programmingLanguages !== undefined) profile.programmingLanguages = Array.isArray(body.programmingLanguages) ? body.programmingLanguages.map(String).map(x => x.trim()).filter(Boolean) : String(body.programmingLanguages).split(",").map(x => x.trim()).filter(Boolean);
    if (body.programmingLanguages !== undefined) profile.programmingLanguages = Array.isArray(body.programmingLanguages) ? body.programmingLanguages : [];
    if (body.projects !== undefined) profile.projects = Array.isArray(body.projects) ? body.projects.map((item) => ({ title: String(item.title || "").trim(), description: String(item.description || "").trim(), technologies: Array.isArray(item.technologies) ? item.technologies : (Array.isArray(item.techStack) ? item.techStack : []) })) : [];
    if (body.certifications !== undefined) profile.certifications = Array.isArray(body.certifications) ? body.certifications.map((item) => ({ name: String(item.name || item.title || "").trim(), issuer: String(item.issuer || "").trim(), year: item.year ? Number(item.year) : (item.issueDate ? Number(String(item.issueDate).slice(0, 4)) : null) })) : [];

    const completion = calculateProfileCompletion(profile);
    profile.profileCompletion = completion.percentage;
    profile.isProfileComplete = completion.isComplete;
    await profile.save();

    const user = await User.findById(userId);
    if (user) {
      if (fullName !== undefined) user.name = profile.fullName;
      if (body.phone !== undefined) user.phone = profile.phone;
      if (body.course !== undefined) user.course = profile.course;
      if (body.semester !== undefined) user.semester = profile.semester;
      if (body.collegeName !== undefined) user.college = profile.collegeName;
      if (body.resumeUrl !== undefined) user.resumeUrl = profile.resumeUrl;
      await user.save();
    }

    const updatedProfile = await StudentProfile.findById(profile._id).populate("user", "name email phone");
    return res.status(200).json({ success: true, message: "Student profile updated successfully.", profile: updatedProfile });
  } catch (error) {
    console.error("Update Student Profile Error:", error);
    return res.status(500).json({ success: false, message: "Server error while updating profile." });
  }
};

// =====================================================
// DELETE STUDENT PROFILE
// =====================================================

const deleteStudentProfile = async (
  req,
  res
) => {
  try {
    const userId =
      req.user.userId || req.user.id;

    const profile =
      await StudentProfile.findOneAndDelete({
        user: userId,
      });

    if (!profile) {
      return res.status(404).json({
        success: false,
        message:
          "Student profile not found.",
      });
    }

    return res.status(200).json({
      success: true,
      message:
        "Student profile deleted successfully.",
    });
  } catch (error) {
    console.error(
      "Delete Student Profile Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Server error while deleting profile.",
    });
  }
};

// =====================================================
// EXPORT
// =====================================================

module.exports = {
  getStudentProfile,
  createStudentProfile,
  updateStudentProfile,
  deleteStudentProfile,
};