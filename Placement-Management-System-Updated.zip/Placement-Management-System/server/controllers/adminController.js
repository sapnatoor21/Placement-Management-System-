const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("../models/User");
const StudentProfile = require("../models/StudentProfile");
const PlacementDrive = require("../models/PlacementDrive");
const Application = require("../models/Application");
const Notification = require("../models/Notification");
const { sendEmail } = require("../utils/emailService");

const getAdminDashboard = async (req, res) => {
  try {
    const [students, recruiters, drives, applications, shortlisted, selected, openDrives] = await Promise.all([
      User.countDocuments({ role: "student" }),
      User.countDocuments({ role: "recruiter" }),
      PlacementDrive.countDocuments({}),
      Application.countDocuments({}),
      Application.countDocuments({ status: "Shortlisted" }),
      Application.countDocuments({ status: "Selected" }),
      PlacementDrive.countDocuments({ status: "Open", isActive: true }),
    ]);

    const recentApplications = await Application.find({})
      .sort({ createdAt: -1 })
      .limit(8)
      .populate("studentId", "name email")
      .populate("driveId", "companyName jobRole");

    const recentStudents = await User.find({ role: "student" })
      .select("name email phone isActive isEmailVerified createdAt")
      .sort({ createdAt: -1 })
      .limit(5);

    return res.json({
      success: true,
      statistics: {
        students,
        recruiters,
        drives,
        applications,
        shortlisted,
        selected,
        openDrives,
      },
      recentApplications,
      recentStudents,
    });
  } catch (error) {
    console.error("ADMIN DASHBOARD ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to load admin dashboard." });
  }
};

const getStudents = async (req, res) => {
  try {
    const search = String(req.query.search || "").trim();
    const filter = { role: "student" };
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
      ];
    }

    const students = await User.find(filter)
      .select("name email phone role isActive isEmailVerified createdAt companyName industry website location contactPerson designation aboutCompany")
      .sort({ createdAt: -1 });

    const ids = students.map((student) => student._id);
    const profiles = await StudentProfile.find({ user: { $in: ids } })
      .select("user enrollmentNumber collegeName course semester currentCGPA graduationYear technicalSkills placementStatus profileCompletion")
      .lean();

    const profileMap = new Map(profiles.map((profile) => [String(profile.user), profile]));

    return res.json({
      success: true,
      students: students.map((student) => ({
        ...student.toObject(),
        profile: profileMap.get(String(student._id)) || null,
      })),
    });
  } catch (error) {
    console.error("ADMIN STUDENTS ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to load students." });
  }
};

const getRecruiters = async (req, res) => {
  try {
    const recruiters = await User.find({ role: "recruiter" })
      .select("name email phone role isActive isEmailVerified createdAt companyName industry website location contactPerson designation aboutCompany")
      .sort({ createdAt: -1 });

    return res.json({ success: true, recruiters });
  } catch (error) {
    console.error("ADMIN RECRUITERS ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to load recruiters." });
  }
};

const createRecruiter = async (req, res) => {
  try {
    const { name, email, phone = "", password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: "Name, email and password are required." });
    }
    if (password.length < 6) {
      return res.status(400).json({ success: false, message: "Password must be at least 6 characters." });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const exists = await User.findOne({ email: normalizedEmail });
    if (exists) {
      return res.status(409).json({ success: false, message: "An account with this email already exists." });
    }

    const recruiter = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      phone: String(phone).trim(),
      password: await bcrypt.hash(password, 10),
      role: "recruiter",
      isActive: true,
      isEmailVerified: true,
    });

    return res.status(201).json({
      success: true,
      message: "Recruiter created successfully.",
      recruiter: {
        id: recruiter._id,
        name: recruiter.name,
        email: recruiter.email,
        phone: recruiter.phone,
        role: recruiter.role,
        isActive: recruiter.isActive,
      },
    });
  } catch (error) {
    console.error("CREATE RECRUITER ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to create recruiter." });
  }
};

const updateUserStatus = async (req, res) => {
  try {
    const { userId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ success: false, message: "Invalid user ID." });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: "User not found." });
    if (String(user._id) === String(req.user._id)) {
      return res.status(400).json({ success: false, message: "You cannot deactivate your own admin account." });
    }

    user.isActive = !user.isActive;
    await user.save();

    return res.json({
      success: true,
      message: `User ${user.isActive ? "activated" : "deactivated"} successfully.`,
      user: { id: user._id, isActive: user.isActive },
    });
  } catch (error) {
    console.error("UPDATE USER STATUS ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to update user status." });
  }
};

const getDrives = async (req, res) => {
  try {
    const drives = await PlacementDrive.find({})
      .sort({ createdAt: -1 }).lean();
    const normalizedDrives = drives.map((drive) => {
      const inferredType = /\bintern(ship)?\b/i.test(drive.jobRole || "") ? "Internship" : "";
      const type = drive.opportunityType === "All" ? "" : (drive.opportunityType || inferredType || drive.jobType || "Full-time");
      return { ...drive, jobType: type, opportunityType: drive.opportunityType || type };
    });
    return res.json({ success: true, drives: normalizedDrives });
  } catch (error) {
    console.error("ADMIN DRIVES ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to load placement drives." });
  }
};

const createDrive = async (req, res) => {
  try {
    const drive = await PlacementDrive.create({
      companyName: req.body.companyName,
      jobRole: req.body.jobRole,
      description: req.body.description || "",
      location: req.body.location || "Jalandhar",
      jobType: req.body.jobType === "All" ? "" : (req.body.jobType || "Full-time"),
      opportunityType: req.body.jobType === "All" ? "All" : (req.body.jobType || "Full-time"),
      package: req.body.package || "",
      eligibleCourses: Array.isArray(req.body.eligibleCourses) ? req.body.eligibleCourses : [],
      minCGPA: Number(req.body.minCGPA || 0),
      maxBacklogs: Number(req.body.maxBacklogs ?? 0),
      eligibility: req.body.eligibility || "",
      skills: Array.isArray(req.body.skills)
        ? req.body.skills
        : String(req.body.skills || "").split(",").map((item) => item.trim()).filter(Boolean),
      applicationDeadline: req.body.applicationDeadline || null,
      driveDate: req.body.driveDate || null,
      status: req.body.status || "Open",
      isActive: true,
    });
    return res.status(201).json({ success: true, message: "Placement drive created successfully.", drive });
  } catch (error) {
    console.error("CREATE DRIVE ERROR:", error);
    return res.status(500).json({ success: false, message: error.message || "Unable to create drive." });
  }
};

const updateDrive = async (req, res) => {
  try {
    const drive = await PlacementDrive.findByIdAndUpdate(req.params.driveId, req.body, {
      new: true,
      runValidators: true,
    });
    if (!drive) return res.status(404).json({ success: false, message: "Placement drive not found." });
    return res.json({ success: true, message: "Placement drive updated.", drive });
  } catch (error) {
    console.error("UPDATE DRIVE ERROR:", error);
    return res.status(500).json({ success: false, message: error.message || "Unable to update drive." });
  }
};

const deleteDrive = async (req, res) => {
  try {
    const drive = await PlacementDrive.findByIdAndDelete(req.params.driveId);
    if (!drive) return res.status(404).json({ success: false, message: "Placement drive not found." });
    await Application.deleteMany({ driveId: drive._id });
    return res.json({ success: true, message: "Placement drive deleted successfully." });
  } catch (error) {
    console.error("DELETE DRIVE ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to delete drive." });
  }
};

const getApplications = async (req, res) => {
  try {
    const applications = await Application.find({})
      .sort({ createdAt: -1 })
      .populate("studentId", "name email phone")
      .populate("driveId", "companyName jobRole location package")
      .lean();
    const ids = applications.map((item) => item.studentId?._id).filter(Boolean);
    const profiles = await StudentProfile.find({ user: { $in: ids } }).lean();
    const profileMap = new Map(profiles.map((profile) => [String(profile.user), profile]));
    return res.json({ success: true, applications: applications.map((item) => ({ ...item, id: String(item._id), student: item.studentId, drive: item.driveId, studentProfile: (() => { const profile = profileMap.get(String(item.studentId?._id)); return profile ? { ...profile, cgpa: profile.currentCGPA, skills: profile.technicalSkills || [] } : null; })() })) });
  } catch (error) {
    console.error("ADMIN APPLICATIONS ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to load applications." });
  }
};

const updateApplicationStatus = async (req, res) => {
  try {
    const allowed = Application.APPLICATION_STATUSES;
    const { status } = req.body;
    if (!allowed.includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid application status." });
    }

    const previousApplication = await Application.findById(req.params.applicationId).select("status");
    if (!previousApplication) return res.status(404).json({ success: false, message: "Application not found." });
    const previousStatus = previousApplication.status;

    const application = await Application.findByIdAndUpdate(
      req.params.applicationId,
      { $set: { status, statusUpdatedBy: req.user._id, recruiterFeedback: String(req.body.note || "").slice(0, 2000) }, $push: { timeline: { status, date: new Date(), note: String(req.body.note || "").slice(0, 1000) } } },
      { new: true, runValidators: true }
    )
      .populate("studentId", "name email")
      .populate("driveId", "companyName jobRole");

    if (!application) return res.status(404).json({ success: false, message: "Application not found." });
    const studentId = application.studentId?._id || application.studentId;
    const statusNotification = await Notification.create({ userId: studentId, title: "Application status updated", message: `Your application status is now ${status}.`, type: "application", link: "/student/applications" });
    req.app.get("io")?.to(`user:${studentId}`).emit("notification:new", statusNotification);

    let emailNotification = "not_required";
    if (["Shortlisted", "Selected"].includes(status) && previousStatus !== status && application.studentId?.email) {
      try {
        await sendEmail({
          to: application.studentId.email,
          subject: `Placement update: ${status} - ${application.driveId?.companyName || "Campus Recruitment"}`,
          text: `Hello ${application.studentId.name || "Student"},\n\nYour application for ${application.driveId?.jobRole || "the role"} at ${application.driveId?.companyName || "the company"} has been marked as ${status}.\n\n${req.body.note ? `Additional note: ${String(req.body.note).slice(0, 1000)}\n\n` : ""}Please check your Placement Management System dashboard for further updates.\n\nPlacement Management System`,
        });
        emailNotification = "sent";
      } catch (emailError) {
        emailNotification = "failed_to_send";
        console.error("ADMIN APPLICATION STATUS EMAIL ERROR:", emailError.message);
      }
    }
    return res.json({ success: true, message: "Application status updated.", emailNotification, application });
  } catch (error) {
    console.error("ADMIN APPLICATION STATUS ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to update application status." });
  }
};

const getStats = async (req, res) => {
  try {
    const byStatus = await Application.aggregate([
      { $group: { _id: "$status", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);

    const companyWise = await Application.aggregate([
      { $lookup: { from: "placementdrives", localField: "driveId", foreignField: "_id", as: "drive" } },
      { $unwind: "$drive" },
      { $group: { _id: "$drive.companyName", applications: { $sum: 1 }, selected: { $sum: { $cond: [{ $eq: ["$status", "Selected"] }, 1, 0] } } } },
      { $sort: { applications: -1 } },
      { $limit: 10 },
    ]);

    const [totalStudents, totalRecruiters, totalDrives, openDrives, totalApplications, selectedCount] = await Promise.all([
      User.countDocuments({ role: "student" }),
      User.countDocuments({ role: "recruiter" }),
      PlacementDrive.countDocuments({}),
      PlacementDrive.countDocuments({ status: "Open", isActive: true }),
      Application.countDocuments({}),
      Application.countDocuments({ status: "Selected" }),
    ]);
    const topCompanies = companyWise.map((item) => ({ name: item._id || "Unspecified", count: item.applications }));
    const placementRate = totalStudents ? Math.round((selectedCount / totalStudents) * 100) : 0;
    return res.json({ success: true, totalStudents, totalRecruiters, totalDrives, openDrives, totalApplications, selectedCount, placementRate, byStatus, companyWise, topCompanies });
  } catch (error) {
    console.error("ADMIN STATS ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to load statistics." });
  }
};

module.exports = {
  getAdminDashboard,
  getStudents,
  getRecruiters,
  createRecruiter,
  updateUserStatus,
  getDrives,
  createDrive,
  updateDrive,
  deleteDrive,
  getApplications,
  updateApplicationStatus,
  getStats,
};
