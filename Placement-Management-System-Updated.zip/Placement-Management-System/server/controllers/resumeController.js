const Resume = require("../models/Resume");
const StudentProfile = require("../models/StudentProfile");
const cloudinary = require("../config/cloudinary");
const { PDFParse } = require("pdf-parse");
const mammoth = require("mammoth");
const archiver = require("archiver");
const streamifier = require("streamifier");

// =====================================================
// FILE TYPE
// =====================================================

const getFileType = (file) => {
  if (!file) {
    return "";
  }

  if (file.mimetype === "application/pdf") {
    return "pdf";
  }

  if (file.mimetype === "application/msword") {
    return "doc";
  }

  if (
    file.mimetype ===
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    return "docx";
  }

  return "";
};

// =====================================================
// CLEAN EXTRACTED TEXT
// =====================================================

const cleanExtractedText = (text) => {
  if (!text) {
    return "";
  }

  return String(text)
    .replace(/\r/g, "\n")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n+/g, "\n")
    .trim();
};

// =====================================================
// TEXT EXTRACTION
// =====================================================

const extractTextFromFile = async (file) => {
  if (!file) {
    return "";
  }

  try {
    // -------------------------------------------------
    // PDF
    // pdf-parse v2.4.5
    // -------------------------------------------------

    if (file.mimetype === "application/pdf") {
      let parser = null;

      try {
        parser = new PDFParse({
          data: file.buffer,
        });

        const result = await parser.getText();

        const text = cleanExtractedText(
          result?.text || ""
        );

        console.log(
          `PDF TEXT EXTRACTION: ${file.originalname} -> ${text.length} characters`
        );

        return text;
      } finally {
        if (parser) {
          try {
            await parser.destroy();
          } catch (destroyError) {
            console.error(
              "PDF PARSER DESTROY ERROR:",
              destroyError.message
            );
          }
        }
      }
    }

    // -------------------------------------------------
    // DOCX
    // -------------------------------------------------

    if (
      file.mimetype ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      const result =
        await mammoth.extractRawText({
          buffer: file.buffer,
        });

      const text = cleanExtractedText(
        result?.value || ""
      );

      console.log(
        `DOCX TEXT EXTRACTION: ${file.originalname} -> ${text.length} characters`
      );

      return text;
    }

    // -------------------------------------------------
    // DOC
    // -------------------------------------------------

    // Mammoth does not support old binary .doc files.
    // We accept .doc files but cannot reliably extract
    // their text with Mammoth.

    if (
      file.mimetype ===
      "application/msword"
    ) {
      console.log(
        `DOC TEXT EXTRACTION: ${file.originalname} -> unsupported old DOC format`
      );

      return "";
    }

    return "";
  } catch (error) {
    console.error(
      "TEXT EXTRACTION ERROR:",
      error
    );

    return "";
  }
};

// =====================================================
// DETECT SKILLS
// =====================================================

const detectSkills = (text) => {
  if (!text) {
    return [];
  }

  const skills = [
    "JavaScript",
    "React",
    "Node.js",
    "Express",
    "MongoDB",
    "MySQL",
    "Python",
    "Java",
    "C++",
    "HTML",
    "CSS",
    "Tailwind CSS",
    "Git",
    "GitHub",
    "SQL",
    "Machine Learning",
    "Deep Learning",
    "Artificial Intelligence",
    "Data Science",
    "Data Analytics",
    "Power BI",
    "Tableau",
    "PHP",
    "REST API",
    "JWT",
    "Cloudinary",
    "Docker",
    "Redis",
    "AWS",
  ];

  const lowerText = text.toLowerCase();

  return skills.filter((skill) =>
    lowerText.includes(
      skill.toLowerCase()
    )
  );
};

// =====================================================
// ATS SCORE
// =====================================================

const calculateATSScore = (
  text,
  skills
) => {
  if (!text || text.trim().length === 0) {
    return 0;
  }

  const lowerText = text.toLowerCase();

  let score = 0;

  // -------------------------------------------------
  // IMPORTANT SECTIONS
  // -------------------------------------------------

  const sections = [
    "education",
    "experience",
    "skills",
    "projects",
    "certifications",
  ];

  sections.forEach((section) => {
    if (lowerText.includes(section)) {
      score += 10;
    }
  });

  // -------------------------------------------------
  // SKILLS
  // -------------------------------------------------

  score += Math.min(
    skills.length * 5,
    25
  );

  // -------------------------------------------------
  // CONTENT LENGTH
  // -------------------------------------------------

  if (text.length > 500) {
    score += 10;
  }

  if (text.length > 1000) {
    score += 10;
  }

  return Math.min(score, 100);
};

// =====================================================
// GRAMMAR CHECK
// =====================================================

const getGrammarIssues = (text) => {
  if (!text) {
    return [];
  }

  const commonMistakes = {
    teh: "the",
    recieve: "receive",
    seperate: "separate",
    occured: "occurred",
    definately: "definitely",
  };

  const issues = [];

  Object.entries(
    commonMistakes
  ).forEach(([wrong, correct]) => {
    const regex = new RegExp(
      `\\b${wrong}\\b`,
      "i"
    );

    if (regex.test(text)) {
      issues.push(
        `Possible typo: "${wrong}" → "${correct}"`
      );
    }
  });

  return issues;
};

// =====================================================
// CLOUDINARY UPLOAD
// =====================================================

const uploadToCloudinary = (
  file,
  userId
) => {
  return new Promise(
    (resolve, reject) => {
      const publicId = `resume_${userId}_${Date.now()}`;

      const uploadStream =
        cloudinary.uploader.upload_stream(
          {
            folder:
              "kmv-placement-cell/resumes",

            public_id: publicId,

            resource_type: "raw",
          },

          (error, result) => {
            if (error) {
              return reject(error);
            }

            resolve(result);
          }
        );

      streamifier
        .createReadStream(file.buffer)
        .pipe(uploadStream);
    }
  );
};

// =====================================================
// UPLOAD RESUME
// =====================================================

const uploadResume = async (
  req,
  res
) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message:
          "Please select a resume file.",
      });
    }

    const userId = req.user._id;

    const fileType =
      getFileType(req.file);

    if (!fileType) {
      return res.status(400).json({
        success: false,
        message:
          "Only PDF, DOC and DOCX files are allowed.",
      });
    }

    // -------------------------------------------------
    // EXTRACT TEXT
    // -------------------------------------------------

    const extractedText =
      await extractTextFromFile(
        req.file
      );

    console.log(
      "----------------------------------------"
    );

    console.log(
      "RESUME ANALYSIS"
    );

    console.log(
      "File:",
      req.file.originalname
    );

    console.log(
      "Type:",
      fileType
    );

    console.log(
      "Extracted text length:",
      extractedText.length
    );

    // -------------------------------------------------
    // DETECT SKILLS
    // -------------------------------------------------

    const extractedSkills =
      detectSkills(
        extractedText
      );

    console.log(
      "Detected skills:",
      extractedSkills
    );

    // -------------------------------------------------
    // ATS
    // -------------------------------------------------

    let atsScore = calculateATSScore(extractedText, extractedSkills);
    let analysisType = "rule-based";

    console.log(
      "ATS Score:",
      atsScore
    );

    // -------------------------------------------------
    // GRAMMAR
    // -------------------------------------------------

    const grammarIssues =
      getGrammarIssues(
        extractedText
      );

    // -------------------------------------------------
    // EXISTING RESUMES
    // -------------------------------------------------

    const existingResumes =
      await Resume.find({
        user: userId,
      }).sort({
        version: -1,
      });

    const version =
      existingResumes.length > 0
        ? existingResumes[0].version + 1
        : 1;

    // -------------------------------------------------
    // DEFAULT
    // -------------------------------------------------

    const isFirstResume =
      existingResumes.length === 0;

    // -------------------------------------------------
    // CLOUDINARY
    // -------------------------------------------------

    const cloudinaryResult =
      await uploadToCloudinary(
        req.file,
        userId
      );

    // -------------------------------------------------
    // AI FEEDBACK
    // -------------------------------------------------

    let aiFeedback = extractedText.trim()
      ? "Basic rule-based checks completed (section presence and keyword extraction). No AI evaluation was performed because no AI provider is configured."
      : "No readable text was extracted. Scanned/image-based PDFs require OCR before meaningful analysis.";

    if (extractedText.trim() && process.env.AI_API_URL && process.env.AI_API_KEY && process.env.AI_MODEL) {
      try {
        const aiResponse = await fetch(process.env.AI_API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.AI_API_KEY}` },
          body: JSON.stringify({
            model: process.env.AI_MODEL,
            temperature: 0.1,
            messages: [
              { role: "system", content: "Review a student's resume for entry-level campus placements. Return only JSON: {score: number 0-100, feedback: string, grammarIssues: string[], missingSections: string[], keywordSuggestions: string[]}. Do not invent experience, skills or achievements." },
              { role: "user", content: extractedText.slice(0, 14000) },
            ],
          }),
          signal: AbortSignal.timeout(45000),
        });
        if (!aiResponse.ok) throw new Error(`AI provider returned ${aiResponse.status}`);
        const aiPayload = await aiResponse.json();
        const rawContent = aiPayload.choices?.[0]?.message?.content || "";
        const parsed = JSON.parse(rawContent.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, ""));
        if (Number.isFinite(Number(parsed.score))) atsScore = Math.max(0, Math.min(100, Number(parsed.score)));
        aiFeedback = JSON.stringify({ feedback: parsed.feedback || "", missingSections: parsed.missingSections || [], keywordSuggestions: parsed.keywordSuggestions || [] });
        if (Array.isArray(parsed.grammarIssues)) grammarIssues.splice(0, grammarIssues.length, ...parsed.grammarIssues.map(String));
        analysisType = "ai";
      } catch (aiError) {
        console.error("AI resume review unavailable; retaining rule-based analysis:", aiError.message);
        aiFeedback += " AI provider could not be reached; this is not an AI score.";
      }
    }

    // -------------------------------------------------
    // CREATE RESUME
    // -------------------------------------------------

    const resume =
      await Resume.create({
        user: userId,

        title:
          req.body.title ||
          req.file.originalname.replace(
            /\.[^/.]+$/,
            ""
          ),

        originalName:
          req.file.originalname,

        fileUrl:
          cloudinaryResult.secure_url ||
          cloudinaryResult.url,

        publicId:
          cloudinaryResult.public_id,

        fileType,

        version,

        isDefault:
          isFirstResume,

        isVisible: true,

        approvalStatus:
          "Pending",

        adminComment: "",

        atsScore,

        aiFeedback,
        analysisType,

        grammarIssues,

        extractedSkills,

        parsedData: {
          text:
            extractedText.substring(
              0,
              10000
            ),
        },
      });

    // -------------------------------------------------
    // ENSURE ONLY ONE DEFAULT
    // -------------------------------------------------

    if (isFirstResume) {
      await Resume.updateMany(
        {
          user: userId,

          _id: {
            $ne: resume._id,
          },
        },

        {
          $set: {
            isDefault: false,
          },
        }
      );
    }

    console.log(
      "Resume saved successfully:",
      resume._id
    );

    console.log(
      "----------------------------------------"
    );

    return res.status(201).json({
      success: true,

      message:
        "Resume uploaded and analyzed successfully.",

      resume,
    });
  } catch (error) {
    console.error(
      "UPLOAD RESUME ERROR:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        error.message ||
        "Unable to upload resume.",
    });
  }
};

// =====================================================
// GET ALL STUDENT RESUMES
// =====================================================

const getResume = async (
  req,
  res
) => {
  try {
    const resumes =
      await Resume.find({
        user: req.user._id,
      }).sort({
        isDefault: -1,
        createdAt: -1,
      });

    return res.json({
      success: true,
      resumes,
    });
  } catch (error) {
    console.error(
      "GET RESUMES ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load resumes.",
    });
  }
};

// =====================================================
// GET DEFAULT RESUME
// =====================================================

const getDefaultResume =
  async (req, res) => {
    try {
      const resume =
        await Resume.findOne({
          user: req.user._id,
          isDefault: true,
        });

      if (!resume) {
        return res.status(404).json({
          success: false,
          message:
            "Default resume not found.",
        });
      }

      return res.json({
        success: true,
        resume,
      });
    } catch (error) {
      console.error(
        "GET DEFAULT RESUME ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to load default resume.",
      });
    }
  };

// =====================================================
// SET DEFAULT RESUME
// =====================================================

const setDefaultResume =
  async (req, res) => {
    try {
      const resume =
        await Resume.findOne({
          _id: req.params.id,
          user: req.user._id,
        });

      if (!resume) {
        return res.status(404).json({
          success: false,
          message:
            "Resume not found.",
        });
      }

      // Remove default from all resumes
      await Resume.updateMany(
        {
          user: req.user._id,
        },

        {
          $set: {
            isDefault: false,
          },
        }
      );

      // Make selected resume default
      resume.isDefault = true;

      await resume.save();

      return res.json({
        success: true,

        message:
          "Default resume updated.",

        resume,
      });
    } catch (error) {
      console.error(
        "SET DEFAULT RESUME ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to update default resume.",
      });
    }
  };

// =====================================================
// TOGGLE VISIBILITY
// =====================================================

const toggleVisibility =
  async (req, res) => {
    try {
      const resume =
        await Resume.findOne({
          _id: req.params.id,
          user: req.user._id,
        });

      if (!resume) {
        return res.status(404).json({
          success: false,
          message:
            "Resume not found.",
        });
      }

      resume.isVisible =
        !resume.isVisible;

      await resume.save();

      return res.json({
        success: true,

        message:
          resume.isVisible
            ? "Resume is now visible to recruiters."
            : "Resume is now hidden from recruiters.",

        resume,
      });
    } catch (error) {
      console.error(
        "TOGGLE VISIBILITY ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to change resume visibility.",
      });
    }
  };

// =====================================================
// UPDATE RESUME
// =====================================================

const updateResume =
  async (req, res) => {
    try {
      const resume =
        await Resume.findOne({
          _id: req.params.id,
          user: req.user._id,
        });

      if (!resume) {
        return res.status(404).json({
          success: false,
          message:
            "Resume not found.",
        });
      }

      if (
        req.body.title !==
        undefined
      ) {
        resume.title =
          req.body.title.trim();
      }

      await resume.save();

      return res.json({
        success: true,

        message:
          "Resume updated successfully.",

        resume,
      });
    } catch (error) {
      console.error(
        "UPDATE RESUME ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to update resume.",
      });
    }
  };

// =====================================================
// DELETE RESUME
// =====================================================

const deleteResume =
  async (req, res) => {
    try {
      const resume =
        await Resume.findOne({
          _id: req.params.id,
          user: req.user._id,
        });

      if (!resume) {
        return res.status(404).json({
          success: false,
          message:
            "Resume not found.",
        });
      }

      const wasDefault =
        resume.isDefault;

      // -------------------------------------------------
      // DELETE FROM CLOUDINARY
      // -------------------------------------------------

      if (resume.publicId) {
        try {
          await cloudinary.uploader.destroy(
            resume.publicId,
            {
              resource_type: "raw",
            }
          );
        } catch (cloudinaryError) {
          console.error(
            "CLOUDINARY DELETE ERROR:",
            cloudinaryError.message
          );
        }
      }

      await resume.deleteOne();

      // -------------------------------------------------
      // PROMOTE ANOTHER RESUME
      // -------------------------------------------------

      if (wasDefault) {
        const nextResume =
          await Resume.findOne({
            user: req.user._id,
          }).sort({
            createdAt: -1,
          });

        if (nextResume) {
          nextResume.isDefault = true;

          await nextResume.save();
        }
      }

      return res.json({
        success: true,

        message:
          "Resume deleted successfully.",
      });
    } catch (error) {
      console.error(
        "DELETE RESUME ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to delete resume.",
      });
    }
  };

// =====================================================
// PREVIEW PDF
// =====================================================

const previewResume =
  async (req, res) => {
    try {
      const resume =
        await Resume.findOne({
          _id: req.params.id,
          user: req.user._id,
        });

      if (!resume) {
        return res.status(404).json({
          success: false,
          message:
            "Resume not found.",
        });
      }

      if (
        resume.fileType !== "pdf"
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Preview is available only for PDF files.",
        });
      }

      const response =
        await fetch(
          resume.fileUrl
        );

      if (!response.ok) {
        return res.status(500).json({
          success: false,
          message:
            "Unable to fetch resume file.",
        });
      }

      const buffer =
        Buffer.from(
          await response.arrayBuffer()
        );

      res.setHeader(
        "Content-Type",
        "application/pdf"
      );

      res.setHeader(
        "Content-Disposition",
        "inline"
      );

      return res.send(buffer);
    } catch (error) {
      console.error(
        "PREVIEW RESUME ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to preview resume.",
      });
    }
  };

// =====================================================
// ADMIN - GET ALL RESUMES
// =====================================================

const getAllResumes =
  async (req, res) => {
    try {
      const resumes =
        await Resume.find({})
          .populate(
            "user",
            "name email phone"
          )
          .sort({
            createdAt: -1,
          });

      return res.json({
        success: true,
        resumes,
      });
    } catch (error) {
      console.error(
        "GET ALL RESUMES ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to load resumes.",
      });
    }
  };

// =====================================================
// ADMIN - APPROVAL
// =====================================================

const updateApproval =
  async (req, res) => {
    try {
      const {
        approvalStatus,
        adminComment,
      } = req.body;

      const allowedStatuses = [
        "Pending",
        "Approved",
        "Rejected",
      ];

      if (
        !allowedStatuses.includes(
          approvalStatus
        )
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Invalid approval status.",
        });
      }

      const resume =
        await Resume.findByIdAndUpdate(
          req.params.id,

          {
            approvalStatus,

            adminComment:
              adminComment || "",
          },

          {
            new: true,
            runValidators: true,
          }
        );

      if (!resume) {
        return res.status(404).json({
          success: false,
          message:
            "Resume not found.",
        });
      }

      return res.json({
        success: true,

        message:
          "Resume approval updated.",

        resume,
      });
    } catch (error) {
      console.error(
        "UPDATE APPROVAL ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to update approval.",
      });
    }
  };

// =====================================================
// RECRUITER - SEARCH
// =====================================================

const searchResumes =
  async (req, res) => {
    try {
      const {
        skill,
        cgpa,
        branch,
      } = req.query;

      const query = {
        isVisible: true,

        approvalStatus:
          "Approved",
      };

      if (skill) {
        query.extractedSkills = {
          $regex: skill,
          $options: "i",
        };
      }

      let resumes =
        await Resume.find(query)
          .populate(
            "user",
            "name email phone"
          )
          .sort({
            atsScore: -1,
          });

      // -------------------------------------------------
      // PROFILE FILTERS
      // -------------------------------------------------

      const userIds =
        resumes
          .map(
            (resume) =>
              resume.user?._id
          )
          .filter(Boolean);

      if (
        cgpa ||
        branch
      ) {
        const profileQuery = {
          user: {
            $in: userIds,
          },
        };

        if (cgpa) {
          profileQuery.currentCGPA = {
            $gte: Number(cgpa),
          };
        }

        if (branch) {
          profileQuery.course = {
            $regex: branch,
            $options: "i",
          };
        }

        const profiles =
          await StudentProfile.find(
            profileQuery
          ).select("user");

        const allowedUsers =
          new Set(
            profiles.map((profile) =>
              profile.user.toString()
            )
          );

        resumes =
          resumes.filter(
            (resume) =>
              resume.user &&
              allowedUsers.has(
                resume.user._id.toString()
              )
          );
      }

      return res.json({
        success: true,
        resumes,
      });
    } catch (error) {
      console.error(
        "SEARCH RESUMES ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to search resumes.",
      });
    }
  };

// =====================================================
// BULK DOWNLOAD
// =====================================================

const bulkDownload =
  async (req, res) => {
    try {
      const {
        skill,
        cgpa,
        branch,
      } = req.query;

      const query = {
        isVisible: true,

        approvalStatus:
          "Approved",
      };

      if (skill) {
        query.extractedSkills = {
          $regex: skill,
          $options: "i",
        };
      }

      let resumes =
        await Resume.find(query)
          .populate(
            "user",
            "name email"
          );

      if (
        cgpa ||
        branch
      ) {
        const userIds =
          resumes
            .map(
              (resume) =>
                resume.user?._id
            )
            .filter(Boolean);

        const profileQuery = {
          user: {
            $in: userIds,
          },
        };

        if (cgpa) {
          profileQuery.currentCGPA = {
            $gte: Number(cgpa),
          };
        }

        if (branch) {
          profileQuery.course = {
            $regex: branch,
            $options: "i",
          };
        }

        const profiles =
          await StudentProfile.find(
            profileQuery
          ).select("user");

        const allowedUsers =
          new Set(
            profiles.map((profile) =>
              profile.user.toString()
            )
          );

        resumes =
          resumes.filter(
            (resume) =>
              resume.user &&
              allowedUsers.has(
                resume.user._id.toString()
              )
          );
      }

      res.setHeader(
        "Content-Type",
        "application/zip"
      );

      res.setHeader(
        "Content-Disposition",
        'attachment; filename="resumes.zip"'
      );

      const archive =
        archiver("zip", {
          zlib: {
            level: 9,
          },
        });

      archive.on(
        "error",
        (error) => {
          console.error(
            "ARCHIVE ERROR:",
            error
          );

          if (!res.headersSent) {
            res.status(500).end();
          }
        }
      );

      archive.pipe(res);

      for (
        const resume of resumes
      ) {
        try {
          const response =
            await fetch(
              resume.fileUrl
            );

          if (!response.ok) {
            continue;
          }

          const buffer =
            Buffer.from(
              await response.arrayBuffer()
            );

          const name =
            resume.user?.name ||
            "student";

          const safeName =
            name.replace(
              /[^a-z0-9]/gi,
              "_"
            );

          archive.append(
            buffer,
            {
              name: `${safeName}_${resume.version}.${resume.fileType}`,
            }
          );
        } catch (error) {
          console.error(
            "BULK FILE ERROR:",
            error.message
          );
        }
      }

      await archive.finalize();
    } catch (error) {
      console.error(
        "BULK DOWNLOAD ERROR:",
        error
      );

      if (!res.headersSent) {
        return res.status(500).json({
          success: false,
          message:
            "Unable to create resume ZIP.",
        });
      }
    }
  };

// =====================================================
// EXPORT
// =====================================================

module.exports = {
  uploadResume,
  getResume,
  getDefaultResume,
  setDefaultResume,
  toggleVisibility,
  updateResume,
  deleteResume,
  previewResume,
  getAllResumes,
  updateApproval,
  searchResumes,
  bulkDownload,
};