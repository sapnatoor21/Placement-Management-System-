const mongoose = require("mongoose");

const User = require("../models/User");
const PlacementDrive = require("../models/PlacementDrive");
const Application = require("../models/Application");
const StudentProfile = require("../models/StudentProfile");
const Notification = require("../models/Notification");
const { sendEmail } = require("../utils/emailService");

// =====================================================
// HELPER
// =====================================================

const getRecruiterId = (req) => {
  return req.user?._id;
};

// =====================================================
// RECRUITER DASHBOARD
// GET /api/recruiter/dashboard
// =====================================================

const getRecruiterDashboard = async (req, res) => {
  try {
    const recruiterId = getRecruiterId(req);

    const drives = await PlacementDrive.find({
      recruiter: recruiterId,
    })
      .sort({ createdAt: -1 })
      .lean();

    const driveIds = drives.map((drive) => drive._id);

    const [
      totalDrives,
      openDrives,
      totalApplications,
      shortlisted,
      selected,
      recentApplications,
    ] = await Promise.all([
      PlacementDrive.countDocuments({
        recruiter: recruiterId,
      }),

      PlacementDrive.countDocuments({
        recruiter: recruiterId,
        status: "Open",
        isActive: true,
      }),

      Application.countDocuments({
        driveId: { $in: driveIds },
      }),

      Application.countDocuments({
        driveId: { $in: driveIds },
        status: "Shortlisted",
      }),

      Application.countDocuments({
        driveId: { $in: driveIds },
        status: "Selected",
      }),

      Application.find({
        driveId: { $in: driveIds },
      })
        .sort({ createdAt: -1 })
        .limit(8)
        .populate(
          "studentId",
          "name email phone"
        )
        .populate(
          "driveId",
          "companyName jobRole"
        )
        .lean(),
    ]);

    return res.json({
      success: true,

      recruiter: {
        id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        phone: req.user.phone || "",
        role: req.user.role,
      },

      statistics: {
        totalDrives,
        openDrives,
        totalApplications,
        shortlisted,
        selected,
        interviewsScheduled: 0,
      },

      drives: drives.slice(0, 5),

      recentApplications: recentApplications.map((item) => ({
        ...item,
        student: item.studentId,
        drive: item.driveId,
      })),
    });
  } catch (error) {
    console.error(
      "RECRUITER DASHBOARD ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load recruiter dashboard.",
    });
  }
};

// =====================================================
// GET RECRUITER DRIVES
// GET /api/recruiter/drives
// =====================================================

const getRecruiterDrives = async (req, res) => {
  try {
    const drives = await PlacementDrive.find({
      recruiter: req.user._id,
    })
      .sort({ createdAt: -1 })
      .lean();

    const driveIds = drives.map(
      (drive) => drive._id
    );

    const applicantCounts =
      await Application.aggregate([
        {
          $match: {
            driveId: {
              $in: driveIds,
            },
          },
        },
        {
          $group: {
            _id: "$driveId",
            count: { $sum: 1 },
          },
        },
      ]);

    const countMap = new Map(
      applicantCounts.map((item) => [
        String(item._id),
        item.count,
      ])
    );

    const result = drives.map((drive) => ({
      ...drive,
      applicants:
        countMap.get(String(drive._id)) || 0,
    }));

    return res.json({
      success: true,
      drives: result,
    });
  } catch (error) {
    console.error(
      "RECRUITER DRIVES ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load recruiter drives.",
    });
  }
};

// =====================================================
// CREATE DRIVE
// POST /api/recruiter/drives
// =====================================================

const createRecruiterDrive = async (
  req,
  res
) => {
  try {
    const {
      companyName,
      jobRole,
      description,
      location,
      jobType,
      package: salaryPackage,
      eligibility,
      skills,
      applicationDeadline,
      driveDate,
      status,
    } = req.body;

    if (!companyName || !jobRole) {
      return res.status(400).json({
        success: false,
        message:
          "Company name and job role are required.",
      });
    }

    let skillsArray = [];

    if (Array.isArray(skills)) {
      skillsArray = skills;
    } else if (skills) {
      skillsArray = String(skills)
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
    }

    const drive =
      await PlacementDrive.create({
        companyName,
        jobRole,
        description: description || "",
        location: location || "Jalandhar",
        jobType: jobType || "Full-time",
        package: salaryPackage || "",
        eligibility: eligibility || "",
        skills: skillsArray,
        applicationDeadline:
          applicationDeadline || null,
        driveDate: driveDate || null,
        status: status || "Open",
        isActive: true,

        // VERY IMPORTANT
        recruiter: req.user._id,
        createdBy: req.user._id,
      });

    return res.status(201).json({
      success: true,
      message:
        "Placement drive created successfully.",
      drive,
    });
  } catch (error) {
    console.error(
      "CREATE RECRUITER DRIVE ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        error.message ||
        "Unable to create placement drive.",
    });
  }
};

// =====================================================
// UPDATE DRIVE
// PUT /api/recruiter/drives/:driveId
// =====================================================

const updateRecruiterDrive = async (
  req,
  res
) => {
  try {
    const drive =
      await PlacementDrive.findOne({
        _id: req.params.driveId,
        recruiter: req.user._id,
        createdBy: req.user._id,
      });

    if (!drive) {
      return res.status(404).json({
        success: false,
        message:
          "Placement drive not found.",
      });
    }

    const allowedFields = [
      "companyName",
      "jobRole",
      "description",
      "location",
      "jobType",
      "package",
      "eligibleCourses",
      "minCGPA",
      "maxBacklogs",
      "eligibility",
      "skills",
      "applicationDeadline",
      "driveDate",
      "status",
      "isActive",
    ];

    allowedFields.forEach((field) => {
      if (
        req.body[field] !== undefined
      ) {
        drive[field] = req.body[field];
      }
    });

    if (
      typeof drive.skills === "string"
    ) {
      drive.skills = drive.skills
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
    }

    await drive.save();

    return res.json({
      success: true,
      message:
        "Placement drive updated successfully.",
      drive,
    });
  } catch (error) {
    console.error(
      "UPDATE RECRUITER DRIVE ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to update placement drive.",
    });
  }
};

// =====================================================
// DELETE DRIVE
// DELETE /api/recruiter/drives/:driveId
// =====================================================

const deleteRecruiterDrive = async (
  req,
  res
) => {
  try {
    const drive =
      await PlacementDrive.findOneAndDelete({
        _id: req.params.driveId,
        recruiter: req.user._id,
        createdBy: req.user._id,
      });

    if (!drive) {
      return res.status(404).json({
        success: false,
        message:
          "Placement drive not found.",
      });
    }

    await Application.deleteMany({
      driveId: drive._id,
    });

    return res.json({
      success: true,
      message:
        "Placement drive deleted successfully.",
    });
  } catch (error) {
    console.error(
      "DELETE RECRUITER DRIVE ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to delete placement drive.",
    });
  }
};

// =====================================================
// GET APPLICATIONS
// GET /api/recruiter/applications
// =====================================================

const getRecruiterApplications = async (
  req,
  res
) => {
  try {
    const drives =
      await PlacementDrive.find({
        recruiter: req.user._id,
      }).select("_id");

    const driveIds = drives.map(
      (drive) => drive._id
    );

    const applications =
      await Application.find({
        driveId: {
          $in: driveIds,
        },
      })
        .sort({ createdAt: -1 })
        .populate(
          "studentId",
          "name email phone"
        )
        .populate(
          "driveId",
          "companyName jobRole location package"
        )
        .lean();

    const studentIds = applications.map((item) => item.studentId?._id).filter(Boolean);
    const profiles = await StudentProfile.find({ user: { $in: studentIds } }).lean();
    const profileMap = new Map(profiles.map((profile) => [String(profile.user), profile]));
    return res.json({
      success: true,
      applications: applications.map((item) => ({
        ...item,
        id: String(item._id),
        student: item.studentId,
        drive: item.driveId,
        studentProfile: (() => {
          const profile = profileMap.get(String(item.studentId?._id));
          return profile ? { ...profile, cgpa: profile.currentCGPA, skills: profile.technicalSkills || [] } : null;
        })(),
      })),
    });
  } catch (error) {
    console.error(
      "RECRUITER APPLICATIONS ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load applications.",
    });
  }
};

// =====================================================
// UPDATE APPLICATION STATUS
// PATCH /api/recruiter/applications/:applicationId/status
// =====================================================

const updateRecruiterApplicationStatus =
  async (req, res) => {
    try {
      const allowedStatuses = Application.APPLICATION_STATUSES;

      const statusAliases = { under_review: "Under Review", shortlisted: "Shortlisted", assessment_round: "Written Test", interview_scheduled: "Technical Interview", selected: "Selected", rejected: "Rejected" };
      const status = statusAliases[req.body.status] || req.body.status;

      if (!allowedStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message:
            "Invalid application status.",
        });
      }

      const application =
        await Application.findById(
          req.params.applicationId
        );

      if (!application) {
        return res.status(404).json({
          success: false,
          message:
            "Application not found.",
        });
      }

      const drive =
        await PlacementDrive.findOne({
          _id: application.driveId,
          recruiter: req.user._id,
        });

      if (!drive) {
        return res.status(403).json({
          success: false,
          message:
            "You do not have access to this application.",
        });
      }

      const previousStatus = application.status;
      application.status = status;
      application.statusUpdatedBy = req.user._id;
      application.recruiterFeedback = String(req.body.note || "").slice(0, 2000);
      application.timeline.push({ status, date: new Date(), note: String(req.body.note || "").slice(0, 1000) });

      await application.save();
      const statusNotification = await Notification.create({ userId: application.studentId, title: "Application status updated", message: `Your application status is now ${status}.`, type: "application", link: "/student/applications" });
      req.app.get("io")?.to(`user:${application.studentId}`).emit("notification:new", statusNotification);

      let emailNotification = "not_required";
      if (["Shortlisted", "Selected"].includes(status) && previousStatus !== status) {
        try {
          const student = await User.findById(application.studentId).select("name email");
          if (student?.email) {
            await sendEmail({
              to: student.email,
              subject: `Placement update: ${status} - ${drive.companyName}`,
              text: `Hello ${student.name || "Student"},\n\nYour application for ${drive.jobRole} at ${drive.companyName} has been marked as ${status}.\n\n${req.body.note ? `Additional note: ${String(req.body.note).slice(0, 1000)}\n\n` : ""}Please check your Placement Management System dashboard for further updates.\n\nPlacement Management System`,
            });
            emailNotification = "sent";
          }
        } catch (emailError) {
          emailNotification = "failed_to_send";
          console.error("RECRUITER APPLICATION STATUS EMAIL ERROR:", emailError.message);
        }
      }

      const updatedApplication =
        await Application.findById(
          application._id
        )
          .populate(
            "studentId",
            "name email phone"
          )
          .populate(
            "driveId",
            "companyName jobRole"
          );

      return res.json({
        success: true,
        message:
          "Application status updated successfully.",
        emailNotification,
        application:
          updatedApplication,
      });
    } catch (error) {
      console.error(
        "RECRUITER STATUS ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to update application status.",
      });
    }
  };

// =====================================================
// GET CANDIDATES
// GET /api/recruiter/candidates
// =====================================================

const getRecruiterCandidates = async (
  req,
  res
) => {
  try {
    const drives =
      await PlacementDrive.find({
        recruiter: req.user._id,
      }).select("_id");

    const driveIds = drives.map(
      (drive) => drive._id
    );

    const applications =
      await Application.find({
        driveId: {
          $in: driveIds,
        },
      })
        .sort({ createdAt: -1 })
        .populate(
          "studentId",
          "name email phone"
        )
        .populate(
          "driveId",
          "companyName jobRole"
        )
        .lean();

    const candidateMap = new Map();

    applications.forEach((application) => {
      if (!application.studentId) {
        return;
      }

      const studentId = String(
        application.studentId._id
      );

      if (!candidateMap.has(studentId)) {
        candidateMap.set(studentId, {
          student: application.studentId,
          applications: [],
        });
      }

      candidateMap
        .get(studentId)
        .applications.push(
          application
        );
    });

    const candidates = Array.from(
      candidateMap.values()
    );

    return res.json({
      success: true,
      candidates,
    });
  } catch (error) {
    console.error(
      "RECRUITER CANDIDATES ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load candidates.",
    });
  }
};

// =====================================================
// GET PROFILE
// GET /api/recruiter/profile
// =====================================================

const getRecruiterProfile = async (
  req,
  res
) => {
  try {
    const user =
      await User.findById(
        req.user._id
      ).select(
        "-password"
      );

    if (!user) {
      return res.status(404).json({
        success: false,
        message:
          "Recruiter not found.",
      });
    }

    return res.json({
      success: true,
      recruiter: user,
    });
  } catch (error) {
    console.error(
      "RECRUITER PROFILE ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load recruiter profile.",
    });
  }
};

// =====================================================
// UPDATE PROFILE
// PUT /api/recruiter/profile
// =====================================================

const updateRecruiterProfile = async (
  req,
  res
) => {
  try {
    const user =
      await User.findById(
        req.user._id
      );

    if (!user) {
      return res.status(404).json({
        success: false,
        message:
          "Recruiter not found.",
      });
    }

    if (req.body.name !== undefined) {
      user.name =
        String(req.body.name).trim();
    }

    if (req.body.phone !== undefined) user.phone = String(req.body.phone).trim();
    for (const field of ["companyName", "industry", "website", "location", "contactPerson", "designation", "aboutCompany"]) {
      if (req.body[field] !== undefined) user[field] = String(req.body[field]).trim();
    }

    // Email intentionally not changed here.

    await user.save();

    return res.json({
      success: true,
      message:
        "Profile updated successfully.",
      recruiter: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
      },
    });
  } catch (error) {
    console.error(
      "UPDATE RECRUITER PROFILE ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to update recruiter profile.",
    });
  }
};

module.exports = {
  getRecruiterDashboard,
  getRecruiterDrives,
  createRecruiterDrive,
  updateRecruiterDrive,
  deleteRecruiterDrive,
  getRecruiterApplications,
  updateRecruiterApplicationStatus,
  getRecruiterCandidates,
  getRecruiterProfile,
  updateRecruiterProfile,
};