const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/User");
const StudentProfile = require("../models/StudentProfile");

const {
  sendLoginOTP,
  sendPasswordResetOTP,
} = require("../utils/emailService");

// =====================================================
// GENERATE OTP
// =====================================================

const generateOTP = () => {
  return Math.floor(
    100000 + Math.random() * 900000
  ).toString();
};


const normalizePhoneNumber = (value) => {
  let digits = String(value || '').replace(/\D/g, '');
  if (digits.length === 10) digits = `91${digits}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  if (digits.length >= 8 && digits.length <= 15) return `+${digits}`;
  return '';
};

// =====================================================
// CREATE JWT
// =====================================================

const createToken = (user) => {
  if (!process.env.JWT_SECRET) {
    throw new Error(
      "JWT_SECRET is missing in .env"
    );
  }

  return jwt.sign(
    {
      userId: user._id.toString(),
      role: user.role,
      email: user.email,
    },
    process.env.JWT_SECRET,
    {
      expiresIn: "7d",
    }
  );
};

const getMe = async (req, res) => {
  try {
    const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.userId || decoded.id || decoded._id;
    const user = await User.findById(userId).select("-password");
    if (!user) return res.status(404).json({ success: false, message: "Account not found." });
    return res.json({ success: true, user: { ...user.toObject(), id: user._id.toString() } });
  } catch (error) {
    return res.status(401).json({ success: false, message: "Session is invalid or expired." });
  }
};

// =====================================================
// REGISTER
// =====================================================

const registerUser = async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      password,
      role = "student",
      course = "",
      semester = "",
      collegeName = "Kanya Maha Vidyalaya, Jalandhar",
      enrollmentNumber = "",
    } = req.body || {};

    if (role !== "student") {
      return res.status(403).json({
        success: false,
        message: "Public registration is available for student accounts only. Recruiter and admin accounts must be provisioned by the placement office.",
      });
    }

    if (!name?.trim() || !email?.trim() || !phone?.trim() || !password) {
      return res.status(400).json({
        success: false,
        message: "Name, email, phone and password are required.",
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: "Password must be at least 6 characters.",
      });
    }

    const normalizedEmail = String(email).toLowerCase().trim();
    const normalizedPhone = normalizePhoneNumber(phone);
    if (!normalizedPhone) {
      return res.status(400).json({
        success: false,
        message: "Enter a valid mobile number. Use +91 followed by 10 digits for Indian numbers.",
      });
    }

    let user = await User.findOne({ email: normalizedEmail });
    if (user?.isEmailVerified) {
      return res.status(409).json({
        success: false,
        message: "An account with this email already exists. Please sign in instead.",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    if (user) {
      // Upgrade an older pending/unverified registration without sending OTP.
      user.name = name.trim();
      user.phone = normalizedPhone;
      user.password = hashedPassword;
      user.role = "student";
      user.isActive = true;
      user.isEmailVerified = true;
      user.course = String(course || "").trim();
      user.semester = String(semester || "").trim();
      user.college = String(collegeName || "Kanya Maha Vidyalaya, Jalandhar").trim();
      await user.save();
    } else {
      user = await User.create({
        name: name.trim(),
        email: normalizedEmail,
        phone: normalizedPhone,
        password: hashedPassword,
        role: "student",
        isActive: true,
        isEmailVerified: true,
        course: String(course || "").trim(),
        semester: String(semester || "").trim(),
        college: String(collegeName || "Kanya Maha Vidyalaya, Jalandhar").trim(),
      });
    }

    try {
      await StudentProfile.findOneAndUpdate(
        { user: user._id },
        {
          $set: {
            user: user._id,
            fullName: name.trim(),
            phone: normalizedPhone,
            enrollmentNumber: String(enrollmentNumber || "").trim(),
            collegeName: String(collegeName || "Kanya Maha Vidyalaya, Jalandhar").trim(),
            course: String(course || "").trim(),
            semester: String(semester || "").trim(),
          },
        },
        { upsert: true, new: true, setDefaultsOnInsert: true, runValidators: true }
      );
    } catch (profileError) {
      if (!user.isNew) {
        console.error("STUDENT PROFILE CREATE ERROR:", profileError.message);
      } else {
        await User.deleteOne({ _id: user._id });
      }
      throw profileError;
    }

    const token = createToken(user);
    return res.status(201).json({
      success: true,
      message: "Student account created successfully. You are now signed in.",
      token,
      user: {
        id: user._id.toString(),
        _id: user._id.toString(),
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        course: user.course,
        semester: user.semester,
        college: user.college,
        isEmailVerified: true,
      },
    });
  } catch (error) {
    console.error("REGISTER ERROR:", error);
    return res.status(500).json({
      success: false,
      message: error.code === 11000
        ? "An account with this email already exists."
        : "Registration failed. Please check the details and try again.",
      error: error.message,
    });
  }
};

// =====================================================
// LOGIN
// Email + OTP
// =====================================================

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ success: false, message: "Email and password are required." });
    }
    const normalizedEmail = String(email).toLowerCase().trim();
    const user = await User.findOne({ email: normalizedEmail }).select("+password");
    if (!user) return res.status(401).json({ success: false, message: "Invalid email or password." });
    if (user.isActive === false) return res.status(403).json({ success: false, message: "Your account is inactive." });
    if (!user.isEmailVerified) return res.status(403).json({ success: false, requiresVerification: true, message: "Please verify your email address before signing in. Use Resend OTP from the registration flow." });
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(401).json({ success: false, message: "Invalid email or password." });
    return res.json({
      success: true,
      message: "Login successful.",
      token: createToken(user),
      user: { id: user._id.toString(), _id: user._id.toString(), name: user.name, email: user.email, phone: user.phone, role: user.role, course: user.course, semester: user.semester, college: user.college, isEmailVerified: user.isEmailVerified },
    });
  } catch (error) {
    console.error("LOGIN ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to sign in." });
  }
};

// =====================================================
// VERIFY LOGIN OTP
// =====================================================

const verifyLoginOTP = async (
  req,
  res
) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        message:
          "Email and OTP are required.",
      });
    }

    const normalizedEmail =
      email.toLowerCase().trim();

    const user = await User.findOne({
      email: normalizedEmail,
    }).select("+loginOTP +loginOTPExpires");

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    if (!user.isActive) {
      return res.status(403).json({
        success: false,
        message:
          "Your account is inactive.",
      });
    }

    if (!user.isEmailVerified) {
      return res.status(403).json({
        success: false,
        message:
          "Please verify your email first.",
      });
    }

    if (
      !user.loginOTP ||
      !user.loginOTPExpires
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Login OTP not found. Please login again.",
      });
    }

    if (
      user.loginOTPExpires <
      new Date()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Login OTP has expired. Please login again.",
      });
    }

    if (
      user.loginOTP !==
      otp.toString().trim()
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid login OTP.",
      });
    }

    // Clear OTP
    user.loginOTP = null;
    user.loginOTPExpires = null;

    await user.save();

    const token = createToken(user);

    return res.json({
      success: true,
      message: "Login successful.",
      token,

      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isEmailVerified:
          user.isEmailVerified,
      },
    });
  } catch (error) {
    console.error(
      "VERIFY LOGIN OTP ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Login OTP verification failed.",
    });
  }
};

// =====================================================
// DIRECT LOGIN OTP
// =====================================================

const sendDirectLoginOTP = async (
  req,
  res
) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required.",
      });
    }

    const normalizedEmail =
      email.toLowerCase().trim();

    const user = await User.findOne({
      email: normalizedEmail,
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message:
          "No account found with this email.",
      });
    }

    if (!user.isActive) {
      return res.status(403).json({
        success: false,
        message:
          "Your account is inactive.",
      });
    }

    if (!user.isEmailVerified) {
      return res.status(403).json({
        success: false,
        requiresVerification: true,
        email: normalizedEmail,
        message:
          "Please verify your email first.",
      });
    }

    const otp = generateOTP();

    user.loginOTP = otp;

    user.loginOTPExpires =
      new Date(
        Date.now() + 10 * 60 * 1000
      );

    await user.save();

    try {
      await sendLoginOTP(normalizedEmail, otp);
    } catch (mailError) {
      user.loginOTP = null;
      user.loginOTPExpires = null;
      await user.save();
      throw mailError;
    }

    return res.json({
      success: true,
      requiresOTP: true,
      email: normalizedEmail,
      message:
        "Login OTP sent successfully.",
    });
  } catch (error) {
    console.error(
      "SEND LOGIN OTP ERROR:",
      error
    );

    return res.status(502).json({
      success: false,
      message: error.message || "Unable to send login OTP. Check the configured email provider.",
    });
  }
};


// =====================================================
// FORGOT PASSWORD
// =====================================================

const forgotPassword = async (
  req,
  res
) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required.",
      });
    }

    const normalizedEmail =
      email.toLowerCase().trim();

    const user = await User.findOne({
      email: normalizedEmail,
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message:
          "No account found with this email.",
      });
    }

    const otp = generateOTP();

    user.resetPasswordOTP = otp;

    user.resetPasswordOTPExpires =
      new Date(
        Date.now() + 10 * 60 * 1000
      );

    await user.save();

    await sendPasswordResetOTP(
      normalizedEmail,
      otp
    );

    return res.json({
      success: true,
      email: normalizedEmail,
      message:
        "Password reset OTP sent successfully.",
    });
  } catch (error) {
    console.error(
      "FORGOT PASSWORD ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to send password reset OTP.",
    });
  }
};

// =====================================================
// VERIFY RESET PASSWORD OTP
// =====================================================

const verifyForgotPasswordOTP =
  async (req, res) => {
    try {
      const { email, otp } = req.body;

      if (!email || !otp) {
        return res.status(400).json({
          success: false,
          message:
            "Email and OTP are required.",
        });
      }

      const normalizedEmail =
        email.toLowerCase().trim();

      const user = await User.findOne({
        email: normalizedEmail,
      }).select("+resetPasswordOTP +resetPasswordOTPExpires");

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found.",
        });
      }

      if (
        !user.resetPasswordOTP ||
        !user.resetPasswordOTPExpires
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Reset OTP not found. Please request a new OTP.",
        });
      }

      if (
        user.resetPasswordOTPExpires <
        new Date()
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Reset OTP has expired.",
        });
      }

      if (
        user.resetPasswordOTP !==
        otp.toString().trim()
      ) {
        return res.status(400).json({
          success: false,
          message: "Invalid reset OTP.",
        });
      }

      return res.json({
        success: true,
        message:
          "Reset OTP verified successfully.",
      });
    } catch (error) {
      console.error(
        "VERIFY RESET OTP ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Reset OTP verification failed.",
      });
    }
  };

// =====================================================
// RESET PASSWORD
// =====================================================

const resetPassword = async (
  req,
  res
) => {
  try {
    const {
      email,
      otp,
      newPassword,
      confirmPassword,
    } = req.body;

    if (
      !email ||
      !otp ||
      !newPassword ||
      !confirmPassword
    ) {
      return res.status(400).json({
        success: false,
        message:
          "All fields are required.",
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message:
          "Password must be at least 6 characters.",
      });
    }

    if (
      newPassword !== confirmPassword
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Passwords do not match.",
      });
    }

    const normalizedEmail =
      email.toLowerCase().trim();

    const user = await User.findOne({
      email: normalizedEmail,
    }).select("+resetPasswordOTP +resetPasswordOTPExpires");

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    if (
      !user.resetPasswordOTP ||
      !user.resetPasswordOTPExpires
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Password reset OTP not found.",
      });
    }

    if (
      user.resetPasswordOTPExpires <
      new Date()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Password reset OTP has expired.",
      });
    }

    if (
      user.resetPasswordOTP !==
      otp.toString().trim()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Invalid password reset OTP.",
      });
    }

    user.password =
      await bcrypt.hash(
        newPassword,
        10
      );

    user.resetPasswordOTP = null;
    user.resetPasswordOTPExpires = null;

    await user.save();

    return res.json({
      success: true,
      message:
        "Password reset successfully. You can now login.",
    });
  } catch (error) {
    console.error(
      "RESET PASSWORD ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to reset password.",
    });
  }
};

// =====================================================
// GOOGLE LOGIN
// =====================================================

const googleLogin = async (
  req,
  res
) => {
  return res.status(501).json({
    success: false,
    message:
      "Google Login is temporarily unavailable. Please use Email OTP Login.",
  });
};

// =====================================================
// EXPORT
// =====================================================


const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body || {};
    if (!currentPassword || !newPassword || String(newPassword).length < 8) {
      return res.status(400).json({ success: false, message: "Current password and a new password of at least 8 characters are required." });
    }
    const user = await User.findById(req.user._id).select("+password");
    if (!user) return res.status(404).json({ success: false, message: "Account not found." });
    const valid = await bcrypt.compare(currentPassword, user.password);
    if (!valid) return res.status(400).json({ success: false, message: "Current password is incorrect." });
    user.password = await bcrypt.hash(newPassword, 12);
    await user.save();
    return res.json({ success: true, message: "Password changed successfully. Please sign in again on other devices." });
  } catch (error) {
    console.error("CHANGE PASSWORD ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to change password." });
  }
};

module.exports = {
  getMe,
  registerUser,
  loginUser,
  verifyLoginOTP,
  sendDirectLoginOTP,

  forgotPassword,
  verifyForgotPasswordOTP,
  resetPassword,

  googleLogin,
  changePassword,
};