# Setup and troubleshooting

## Start the application

From the project root:

```bash
npm install
npm --prefix client install
npm --prefix server install
```

Copy `server/.env.example` to `server/.env`, set MongoDB and JWT values, then run `npm run dev` from the root (or start `server` and `client` in separate terminals).

## Admin login

Set `ADMIN_EMAIL=admin@gmail.com`, `ADMIN_PASSWORD=admin123` and `ADMIN_NAME=KMV Placement Cell Admin` in `server/.env`, then run `npm run seed:admin` from the `server/` folder. This creates or resets the local demo admin. Change the password before deployment.

## Gemini AI

This project uses the Gemini `generateContent` REST endpoint. Recommended starting configuration:

```env
AI_API_URL=https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent
AI_MODEL=gemini-3.8-flash
AI_API_KEY=your_private_key
```

Do not use the OpenAI-compatible `/chat/completions` URL with this Gemini REST implementation. If Google changes model availability or your API project does not have access, select a model enabled for your account and update both `AI_MODEL` and `AI_API_URL` consistently.

## Email OTP

Email OTP uses Mailjet SMTP. Set `EMAIL_PROVIDER=smtp`, `SMTP_HOST=in-v3.mailjet.com`, `SMTP_PORT=587`, `SMTP_USER` (Mailjet API Key), `SMTP_PASS` (Mailjet Secret Key) and a verified `MAIL_FROM` sender in `server/.env`. Student registration no longer requires OTP; login OTP and password reset still use email.

Mobile/SMS OTP has been removed from sign-in. Student mobile number remains a contact detail only.

## Cloudinary and Judge0

Resume/resource uploads require Cloudinary credentials. CodeForge requires a reachable Judge0 instance and a valid API key. Provider plan limits, language availability and file permissions are controlled by those services.

## Multi-drive application index

If a student gets a duplicate-key error while applying to a different drive, back up the database and run `npm run fix:application-index` from `server/`. This removes a legacy unique index on `studentId` alone if one exists and creates the correct unique pair `(studentId, driveId)`.

## Validation

Run `npm run check:server` from the project root. For a production frontend build, run `npm run build` after installing client dependencies on your operating system.
