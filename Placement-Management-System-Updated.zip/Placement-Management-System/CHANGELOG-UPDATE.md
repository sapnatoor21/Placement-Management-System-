# Changelog history

**Current sign-in and email configuration:** As of 19 Nov 2026, sign-in supports Email + Password and Email OTP only. Mobile/SMS OTP, Resend and Mailtrap configuration have been removed from the current project setup. Mailjet SMTP is the configured email path. Older entries below describe earlier archive versions and are retained only as historical notes.

# Update Notes — Placement Management System

**Placement Management System**  
*An Integrated Platform for Campus Recruitment and Career Development*

## Implemented in this update

- Preserved the requested project branding and existing visual theme.
- Added database-backed Career Guidance tasks (create, edit, complete, delete), progress dashboard, readiness indicators, task deadlines, streak calculation, AI guidance reports, report history and role-based skill-gap analysis.
- Added profile-based placement-drive recommendations using saved course, CGPA, backlog and skill data.
- Added Twilio SMS OTP login endpoints and UI, while retaining email OTP and password login. SMS sends only when valid Twilio credentials and sender are configured.
- Corrected mock interview persistence to match the actual MongoDB schema, added STAR component feedback fields, microphone dictation where supported, multiple interview categories and previous-attempt history display.
- Corrected CodeForge Judge0 language IDs and coding submission persistence/history to match the existing database schema.
- Added multiple saved Resume Studio documents, template selection, version snapshots, restore, duplicate and delete. Existing uploaded resumes and the original single draft workflow remain available.
- Expanded learning resource categories and added per-student bookmarks/completion tracking.
- Corrected notification read-state handling and added Socket.IO updates to the dashboard notification menu.
- Added a safe `.env.example`, database index repair script and updated setup/troubleshooting instructions.

## Multi-drive application index repair

The application schema uses the correct unique pair `(studentId, driveId)`. Some existing databases may still contain a legacy unique index on `studentId` alone from an older schema. After backing up MongoDB, run `npm run fix:application-index` inside `server/` to remove that specific legacy index and ensure the correct compound index.

## Checks performed

- Backend syntax check passed for 60 JavaScript files.
- Newly added route modules loaded successfully with the archived dependencies.
- All frontend JavaScript/JSX files passed TypeScript transpile syntax diagnostics.
- Full Vite production build could not be completed because the uploaded `node_modules` is missing the platform-specific Rolldown native binding. Reinstall client dependencies on the target machine and run `npm run build`.
- MongoDB, email, Twilio, Cloudinary, Gemini and Judge0 were not live-tested because the owner's private credentials and accounts are not available in this environment.

## Still not fully implemented / needs live verification

- Profile editor still uses the existing single skills list rather than three separately managed Technical / Programming Languages / Soft Skills editors. Enter-key behavior has not been standardized across every form.

- Resume Studio has multiple private, owner-scoped saved documents and version snapshots, but does not yet have drag-and-drop section ordering, full visual typography controls, robust generated PDF export, approval-based AI rewriting, granular share permissions/revocation, or a general-purpose private file vault. Existing uploaded resume file privacy still depends on the configured Cloudinary access policy.
- Career task reminders and weekly digest scheduling are not implemented. Learning streak is calculated from completed-task update dates and should be treated as an indicative metric.
- Full category-specific assessment banks for Programming, DBMS, OOP and DSA still depend on the administrator publishing verified questions. The existing aptitude test engine/question bank remains the assessment foundation.
- Mock interview STAR scores are AI-generated feedback and are not objective or guaranteed assessments. Voice transcription relies on browser SpeechRecognition support.
- No live integration can be certified until the application is run with the user's MongoDB and provider credentials.

No demo scores, placements, employer vacancies or student achievements were fabricated to fill missing data.

## Follow-up fix: Private Cloud frontend compilation
- Rewrote `client/src/pages/student/PrivateCloudPage.jsx` with normal formatted JSX and explicit async event handlers.
- Moved the asynchronous version-history request completely outside the React state updater callback. This resolves the Vite parser error: `await is only allowed within async functions and at the top levels of modules`.
- Added `START-HERE.txt` with Windows PowerShell setup/run instructions and corrected the assessment seed command so it can be run from the project root.
- Added `npm run check:client` and `npm run check:all` syntax-check scripts.

## Enquiry storage, administration and application email notifications

- Added a MongoDB `Enquiry` model. Public Contact form submissions are validated and saved in the `enquiries` collection.
- Added `POST /api/public/enquiries` for public submissions.
- Added admin-only `GET /api/admin/enquiries`, `PATCH /api/admin/enquiries/:enquiryId` and `DELETE /api/admin/enquiries/:enquiryId` endpoints.
- Added an Admin Dashboard navigation item and Official Enquiries management page with search, status filters, internal notes, contact links and delete controls.
- The Contact page now displays the success confirmation only after the backend confirms that the enquiry was saved.
- Admin and recruiter status changes to `Shortlisted` or `Selected` now attempt to email the student's registered email address through the configured shared email service. In-app notifications continue to be created. The API reports whether the email was sent or could not be sent.
- The public home page now omits Opportunities and placement-drive preview content.

### Email configuration reminder

Shortlist/selection emails require a working provider configuration in `server/.env`: either `RESEND_API_KEY` plus a verified `MAIL_FROM`, or working `MAILTRAP_USER` and `MAILTRAP_PASS` SMTP credentials (Mailtrap sandbox is for testing and does not deliver to ordinary real inboxes). Never share or commit provider secrets.

### Verification for this update

- Backend syntax check passed for 71 JavaScript files.
- Frontend TypeScript transpile parsing passed for 51 JavaScript/JSX files using the globally available TypeScript compiler.
- A full Vite production build and live MongoDB/email/browser tests were not completed in this environment. The client dependency installation did not complete before the environment timeout. Install dependencies on the target machine and test the new form with the configured MongoDB connection.

## Reliability, messaging and public-site update (18 Nov 2026)

- Replaced the hard-coded Mailtrap sandbox default with configurable SMTP (including Gmail SMTP for controlled testing) or Resend. Student registration now creates an account directly without a registration OTP; optional login OTP and password-reset OTP remain. Email send failures clear login OTPs and surface the provider error.
- Added MSG91 OTP send/verify integration for Indian mobile login, with Twilio retained as an optional fallback. The owner must supply an MSG91 AuthKey and an approved OTP template.
- Added Admin / Recruiter Email Center. Admin can email active students; a recruiter can email applicants to their own drives. Messages are sent individually and each attempt is stored in MongoDB `emaillogs`.
- Added Admin email replies for public enquiries, automatic `Replied` status on successful send, enquiry email history, and optional new-enquiry email notification to `ENQUIRY_NOTIFICATION_EMAIL`.
- Added a public Notices page and navigation; the homepage now shows verified placement highlights from published success stories and live drive totals rather than repeating a second full opportunity list.
- Reworked the About page, redesigned the shared footer, added an interactive OpenStreetMap embed, and added Admin-editable footer/contact/map settings.
- Added baseline responsive safety CSS and a provider setup guide at `EMAIL-AI-SMS-SETUP.md`.

## Verification limits

- Backend syntax check passed for 73 JavaScript files.
- Frontend TypeScript parser check passed for 53 JS/JSX files; relative-import check found no unresolved imports.
- `npm install` could not complete in this isolated build environment, so a Vite production build was not run.
- No live MongoDB URI, Gmail/Resend credentials, MSG91 account, Gemini API key or browser session was available. Real OTP delivery, email delivery, AI response quality, database persistence, responsive browser QA and end-to-end portal workflows remain to be tested in the owner's environment.
- Authentic KMV campus image files were not embedded. The About page links to the official KMV Placement Cell gallery instead of using third-party images with unverified reuse rights.


## Email-only sign-in update (19 Nov 2026)

- Removed the Mobile OTP option from the sign-in modal.
- Sign-in offers Email + Password and optional Email OTP. Student registration no longer requires OTP.
- Removed frontend phone OTP API calls, backend phone OTP routes/controllers and phone OTP-only schema fields.
- Student registration still collects a mobile number as a contact detail; no SMS OTP is sent.
- Updated the environment example and setup/audit documentation for Mailjet SMTP; removed SMS, Resend and Mailtrap configuration from the example.

## Requested interface and authentication update — 21 Nov 2026

- Removed the Nexa AI assistant, admin knowledge-base entry and corresponding chat/knowledge API mounts.
- Removed the Opportunities and current placement-drive preview sections from the public home page.
- Student registration no longer sends or asks for an email OTP; the account is marked verified and the student is signed in after successful registration.
- Added `Other — Write your own` for course/program and class/semester choices in registration, student profile and admin student provisioning.
- Added `npm run seed:admin` in the server package to create or reset the admin account from `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `server/.env`.
