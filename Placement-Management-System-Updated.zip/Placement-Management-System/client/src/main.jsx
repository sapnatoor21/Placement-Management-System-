
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';

const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error(
    'Root element not found. Please check client/index.html.'
  );
}

createRoot(rootElement).render(
  <App />
);
