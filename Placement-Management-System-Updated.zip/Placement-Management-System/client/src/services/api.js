
const API_BASE_URL = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/$/, '');
const TOKEN_KEY = 'kmv_placement_auth_token';

async function request(endpoint, options = {}) {
  const token = localStorage.getItem(TOKEN_KEY);

  const headers = {
    ...(options.body && !(typeof FormData !== 'undefined' && options.body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const contentType = response.headers.get('content-type') || '';
  const result = contentType.includes('application/json')
    ? await response.json()
    : await response.text();

  if (!response.ok || (result && result.success === false)) {
    const message =
      typeof result === 'object' && result !== null
        ? result.message || result.error
        : result;

    throw new Error(message || `Request failed (${response.status})`);
  }

  return result;
}

function getArray(result, key) {
  if (Array.isArray(result)) return result;
  if (Array.isArray(result?.[key])) return result[key];
  if (Array.isArray(result?.data)) return result.data;
  if (Array.isArray(result?.data?.[key])) return result.data[key];

  return [];
}

export const api = {
  // Authentication
  auth: {
    async login(email, password) {
      const result = await request('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });

      return {
        ...result,
        user: result.user || result.data?.user,
        token: result.token || result.data?.token,
      };
    },

    async sendLoginOTP(email) {
      return request('/auth/send-login-otp', { method: 'POST', body: JSON.stringify({ email }) });
    },

    async verifyLoginOTP(email, otp) {
      const result = await request('/auth/verify-login-otp', { method: 'POST', body: JSON.stringify({ email, otp }) });
      return { ...result, user: result.user || result.data?.user, token: result.token || result.data?.token };
    },

    async registerStudent(formData) {
      const result = await request('/auth/register-student', {
        method: 'POST',
        body: JSON.stringify(formData),
      });

      return {
        ...result,
        user: result.user || result.data?.user,
        token: result.token || result.data?.token,
      };
    },

    async getMe() {
      const result = await request('/auth/me');
      return result.user || result.data?.user || result.data || result;
    },

    async forgotPassword(email) {
      return request('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email }),
      });
    },

    async verifyForgotPasswordOTP(email, otp) {
      return request('/auth/verify-forgot-password-otp', {
        method: 'POST',
        body: JSON.stringify({ email, otp }),
      });
    },

    async resetPassword(email, otp, newPassword, confirmPassword) {
      return request('/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({ email, otp, newPassword, confirmPassword }),
      });
    },

    async changePassword(email, currentPassword, newPassword) {
      return request('/auth/change-password', { method: 'PUT', body: JSON.stringify({ email, currentPassword, newPassword }) });
    },

    async logout() {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem('kmv_placement_auth_user');
    },
  },

  // Student
  student: {
    async getProfile() {
      const result = await request('/student/profile');
      const profile = result.profile || result.data?.profile || result.data || result;
      return {
        ...profile,
        cgpa: profile.currentCGPA ?? profile.cgpa ?? '',
        skills: profile.technicalSkills || profile.skills || [],
        bio: profile.professionalSummary || profile.bio || '',
        linkedin: profile.linkedinUrl || profile.linkedin || '',
        github: profile.githubUrl || profile.github || '',
        projects: (profile.projects || []).map((item) => ({ ...item, techStack: item.techStack || item.technologies || [] })),
        certifications: (profile.certifications || []).map((item) => ({ ...item, title: item.title || item.name || '', issueDate: item.issueDate || (item.year ? `${item.year}-01-01` : '') })),
      };
    },

    async updateProfile(userIdOrData, maybeProfileData) {
      // Backward-compatible with older screens that pass (userId, data).
      const profileData = maybeProfileData ?? userIdOrData ?? {};
      const toList = (value) => Array.isArray(value) ? value : String(value || '').split(',').map((item) => item.trim()).filter(Boolean);
      const payload = {
        ...profileData,
        fullName: profileData.fullName ?? profileData.name,
        currentCGPA: profileData.currentCGPA ?? profileData.cgpa ?? '',
        technicalSkills: toList(profileData.technicalSkills ?? profileData.skills),
        softSkills: toList(profileData.softSkills),
        programmingLanguages: toList(profileData.programmingLanguages),
        professionalSummary: profileData.professionalSummary ?? profileData.bio,
        linkedinUrl: profileData.linkedinUrl ?? profileData.linkedin,
        githubUrl: profileData.githubUrl ?? profileData.github,
        projects: (profileData.projects || []).map((item) => ({
          title: item.title || '',
          description: item.description || '',
          technologies: toList(item.technologies ?? item.techStack),
        })),
        certifications: (profileData.certifications || []).map((item) => ({
          name: item.name || item.title || '',
          issuer: item.issuer || '',
          year: item.year || (item.issueDate ? Number(String(item.issueDate).slice(0, 4)) : null),
        })),
      };
      const result = await request('/student/profile', { method: 'PUT', body: JSON.stringify(payload) });
      const profile = result.profile || result.data?.profile || result.data || result;
      return {
        ...profile,
        cgpa: profile.currentCGPA ?? '',
        skills: profile.technicalSkills || [],
        bio: profile.professionalSummary || '',
        linkedin: profile.linkedinUrl || '',
        github: profile.githubUrl || '',
        projects: (profile.projects || []).map((item) => ({ ...item, techStack: item.techStack || item.technologies || [] })),
        certifications: (profile.certifications || []).map((item) => ({ ...item, title: item.title || item.name || '', issueDate: item.issueDate || (item.year ? `${item.year}-01-01` : '') })),
      };
    },

    async getStats() {
      const result = await request('/student/stats');
      return result.stats || result.data?.stats || result.data || result;
    },

    async getApplications() {
      const result = await request('/student/applications');
      const statusMap = { 'Applied': 'applied', 'Under Review': 'under_review', 'Shortlisted': 'shortlisted', 'Written Test': 'assessment_round', 'Technical Interview': 'interview_scheduled', 'HR Interview': 'interview_scheduled', 'Selected': 'selected', 'Rejected': 'rejected', 'Withdrawn': 'withdrawn' };
      return getArray(result, 'applications').map(app => ({ ...app, status: statusMap[app.status] || app.status, drive: app.drive ? { ...app.drive, jobTitle: app.drive.jobRole || app.drive.jobTitle } : app.drive, interviewDetails: app.nextRound ? { ...app.nextRound, scheduledDate: app.nextRound.date ? new Date(app.nextRound.date).toLocaleDateString() : '', meetingLink: app.nextRound.meetLink || '', timeString: app.nextRound.time || '', roundName: app.nextRound.round || app.nextRound.title || '' } : app.interviewDetails }));
    },

    async saveAssessmentResult(assessmentData) {
      return request('/student/assessments', { method: 'POST', body: JSON.stringify(assessmentData) });
    },
    async saveAssessment(assessmentData) { return this.saveAssessmentResult(assessmentData); },
    async getAssessmentHistory() {
      const result = await request('/student/assessments');
      return getArray(result, 'assessments').map(item => ({ ...item, id: item._id || item.id }));
    },
    async getAssessments() { return this.getAssessmentHistory(); },
  },

  // Public site data from MongoDB-backed endpoints
  public: {
    async getHomeStats() {
      return request('/public/home-stats');
    },
    async getSiteSettings() { const r = await request('/public/site-settings'); return r.settings || {}; },
    async getPlacementHighlights() { return request('/public/placement-highlights'); },
    async askAI(question) {
      return request('/advanced/ask-ai', { method: 'POST', body: JSON.stringify({ question }) });
    },
    async submitEnquiry(data) {
      return request('/public/enquiries', { method: 'POST', body: JSON.stringify(data) });
    },
  },

  // Placement drives
  drives: {
    async getAllDrives() {
      const result = await request('/public/placement-drives');
      return getArray(result, 'drives');
    },
  },

  // Applications
  applications: {
    async getMyApplications() {
      const result = await request('/applications/my-applications');
      return getArray(result, 'applications');
    },

    async apply(driveId, applicationData = {}) {
      return request(`/applications/apply/${encodeURIComponent(driveId)}`, {
        method: 'POST',
        body: JSON.stringify(applicationData),
      });
    },
  },

  // Announcements
  announcements: {
    async getAnnouncements() {
      const result = await request('/announcements');
      return getArray(result, 'announcements');
    },
    async getManageAnnouncements() {
      const result = await request('/announcements/manage');
      return getArray(result, 'announcements');
    },
    async createAnnouncement(data) {
      const result = await request('/announcements', { method: 'POST', body: JSON.stringify(data) });
      return result.notice || result;
    },
    async updateAnnouncement(id, data) { return request(`/announcements/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(data) }); },
    async deleteAnnouncement(id) { return request(`/announcements/${encodeURIComponent(id)}`, { method: 'DELETE' });
    },
  },

  successStories: {
    async getAll() { const result = await request('/success-stories'); return getArray(result, 'stories'); },
    async getManageAll() { const result = await request('/success-stories/manage/all'); return getArray(result, 'stories'); },
    async create(data) { const result = await request('/success-stories', { method: 'POST', body: JSON.stringify(data) }); return result.story || result; },
    async update(id, data) { const result = await request(`/success-stories/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(data) }); return result.story || result; },
    async remove(id) { return request(`/success-stories/${encodeURIComponent(id)}`, { method: 'DELETE' }); },
  },

  resources: {
    async getAll(filters = {}) {
      const query = new URLSearchParams(filters).toString();
      const result = await request(`/resources${query ? `?${query}` : ''}`);
      return getArray(result, 'resources');
    },
    getDownloadUrl(id) {
      return `${API_BASE_URL}/resources/${encodeURIComponent(id)}/download`;
    },
    async upload(data) { return request('/resources/upload', { method: 'POST', body: data }); },
    async getManageAll() { const result = await request('/resources/manage/all'); return getArray(result, 'resources'); },
    async update(id, data) { return request(`/resources/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(data) }); },
    async remove(id) { return request(`/resources/${encodeURIComponent(id)}`, { method: 'DELETE' }); },
  },

  resume: {
    async upload(file) { const form = new FormData(); form.append('resume', file); return request('/resume', { method: 'POST', body: form }); },
    async getAll() { const result = await request('/resume'); return getArray(result, 'resumes'); },
    async getDefault() { return request('/resume/default'); },
    async setDefault(id) { return request(`/resume/${encodeURIComponent(id)}/default`, { method: 'PATCH' }); },
    async remove(id) { return request(`/resume/${encodeURIComponent(id)}`, { method: 'DELETE' }); },
  },

  resumeStudio: {
    async list() { const r=await request('/resume-studio'); return r.resumes||[]; },
    async get(id) { return request(`/resume-studio/${encodeURIComponent(id)}`); },
    async create(data) { return request('/resume-studio',{method:'POST',body:JSON.stringify(data)}); },
    async update(id,data) { return request(`/resume-studio/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(data)}); },
    async duplicate(id) { return request(`/resume-studio/${encodeURIComponent(id)}/duplicate`,{method:'POST'}); },
    async remove(id) { return request(`/resume-studio/${encodeURIComponent(id)}`,{method:'DELETE'}); },
    async restore(id,version) { return request(`/resume-studio/${encodeURIComponent(id)}/restore/${version}`,{method:'POST'}); },
    async share(id,permissions='view') { return request(`/resume-studio/${encodeURIComponent(id)}/share`,{method:'POST',body:JSON.stringify({permissions})}); },
    async revokeShare(id) { return request(`/resume-studio/${encodeURIComponent(id)}/share`,{method:'DELETE'}); },
  },
  resumeDraft: {
    async get() { return request('/resume-draft'); },
    async save(data) { return request('/resume-draft', { method: 'PUT', body: JSON.stringify({ data }) }); },
  },

  aptitude: {
    async getQuestions(category = 'All', limit = 10) { const result = await request(`/aptitude/questions?category=${encodeURIComponent(category)}&limit=${limit}`); return getArray(result, 'questions'); },
    async submit(data) { return request('/aptitude/submit', { method: 'POST', body: JSON.stringify(data) }); },
    async getHistory() { const result = await request('/aptitude/history'); return getArray(result, 'attempts'); },
    async getAdminQuestions() { const result = await request('/aptitude/admin/questions'); return getArray(result, 'questions'); },
    async createQuestion(data) { return request('/aptitude/admin/questions', { method: 'POST', body: JSON.stringify(data) }); },
    async updateQuestion(id,data) { return request(`/aptitude/admin/questions/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(data) }); },
    async deleteQuestion(id) { return request(`/aptitude/admin/questions/${encodeURIComponent(id)}`, { method: 'DELETE' }); },
  },

  career: {
    async getRecommendations() { const r=await request('/career/recommendations'); return r.recommendations||[]; },
    async getDashboard() { return request('/career/dashboard'); },
    async getTasks() { const r=await request('/career/tasks'); return r.tasks || []; },
    async createTask(data) { return request('/career/tasks',{method:'POST',body:JSON.stringify(data)}); },
    async updateTask(id,data) { return request(`/career/tasks/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(data)}); },
    async deleteTask(id) { return request(`/career/tasks/${encodeURIComponent(id)}`,{method:'DELETE'}); },
    async generateGuidance(data) { return request('/career/guidance',{method:'POST',body:JSON.stringify(data)}); },
    async getReports() { const r=await request('/career/reports'); return r.reports || []; },
    async getReport(id) { return request(`/career/reports/${encodeURIComponent(id)}`); },
    async skillGap(data) { return request('/career/skill-gap',{method:'POST',body:JSON.stringify(data)}); },
  },
  staffMail: {
    async getRecipients() { const r = await request('/staff-mail/recipients'); return r.students || []; },
    async send(data) { return request('/staff-mail/send', { method: 'POST', body: JSON.stringify(data) }); },
    async getHistory() { const r = await request('/staff-mail/history'); return r.emails || []; },
  },
  advanced: {
    async evaluateMockInterview(data) {
      return request('/advanced/mock-interview/evaluate', { method: 'POST', body: JSON.stringify(data) });
    },
    async getMockInterviewHistory() {
      const result = await request('/advanced/mock-interview/history');
      return getArray(result, 'history');
    },
    async getCareerGuidance(data) {
      return request('/advanced/career-guidance', { method: 'POST', body: JSON.stringify(data) });
    },
    async runCode(data) {
      return request('/advanced/coding/run', { method: 'POST', body: JSON.stringify(data) });
    },
    async getCodingHistory() {
      const result = await request('/advanced/coding/history');
      return getArray(result, 'history');
    },
  },

  // Notifications
  notifications: {
    async getMyNotifications() {
      const result = await request('/notifications');
      return getArray(result, 'notifications');
    },
    async markRead(notificationId) {
      return request(`/notifications/${encodeURIComponent(notificationId)}/read`, { method: 'PATCH' });
    },
    async markAllRead() {
      return request('/notifications/read-all', { method: 'PATCH' });
    },
    async remove(notificationId) {
      return request(`/notifications/${encodeURIComponent(notificationId)}`, { method: 'DELETE' });
    },
  },

  // Recruiter methods
  recruiter: {
    async getProfile() {
      const result = await request('/recruiter/profile');
      return result.profile || result.recruiter || result.data || result;
    },
    async updateProfile(_userId, data) {
      return request('/recruiter/profile', { method: 'PUT', body: JSON.stringify(data) });
    },
    async getMyDrives() {
      const result = await request('/recruiter/drives');
      return getArray(result, 'drives').map((drive) => ({ ...drive, id: drive._id || drive.id, jobTitle: drive.jobRole || drive.jobTitle, ctcSalary: drive.package || drive.ctc || 'Not specified', status: String(drive.status || '').toLowerCase(), applicantsCount: drive.applicants || 0 }));
    },
    async createDrive(_userId, data) {
      const payload = { companyName: data.companyName, jobRole: data.jobTitle || data.jobRole, description: data.description, location: data.location, jobType: data.jobType === 'Full-Time' ? 'Full-time' : data.jobType, package: data.ctcSalary, eligibility: `Minimum CGPA ${data.eligibilityCriteria?.minCgpa ?? 0}; courses: ${(data.eligibilityCriteria?.allowedCourses || []).join(', ')}`, eligibleCourses: data.eligibilityCriteria?.allowedCourses || [], minCGPA: data.eligibilityCriteria?.minCgpa || 0, maxBacklogs: data.eligibilityCriteria?.maxBacklogs ?? 0, skills: data.skillsRequired || [], applicationDeadline: data.applicationDeadline, status: 'Open' };
      return request('/recruiter/drives', { method: 'POST', body: JSON.stringify(payload) });
    },
    async updateDrive(driveId, data) {
      const payload = { ...data, status: data.status ? (String(data.status).toLowerCase() === 'open' ? 'Open' : 'Closed') : undefined };
      return request(`/recruiter/drives/${encodeURIComponent(driveId)}`, { method: 'PUT', body: JSON.stringify(payload) });
    },
    async getApplications() {
      const result = await request('/recruiter/applications');
      return getArray(result, 'applications').map((app) => ({ ...app, driveId: String(app.drive?._id || app.driveId?._id || app.driveId || ''), drive: app.drive ? { ...app.drive, jobTitle: app.drive.jobRole || app.drive.jobTitle } : app.drive, status: ({ 'Applied': 'applied', 'Under Review': 'under_review', 'Shortlisted': 'shortlisted', 'Written Test': 'assessment_round', 'Technical Interview': 'interview_scheduled', 'HR Interview': 'interview_scheduled', 'Selected': 'selected', 'Rejected': 'rejected' })[app.status] || app.status }));
    },
    async getDriveApplicants(driveId) {
      const applications = await this.getApplications();
      return applications.filter((app) => String(app.drive?._id || app.driveId?._id || app.driveId) === String(driveId));
    },
    async updateApplicationStatus(applicationId, status, note = '') {
      return request(`/recruiter/applications/${encodeURIComponent(applicationId)}/status`, { method: 'PATCH', body: JSON.stringify({ status, note }) });
    },
    async updateApplicantStatus(applicationId, uiStatus, feedbackNote = '', interviewDetails) {
      const statusMap = { under_review: 'Under Review', shortlisted: 'Shortlisted', assessment_round: 'Written Test', interview_scheduled: 'Technical Interview', selected: 'Selected', rejected: 'Rejected' };
      const result = await this.updateApplicationStatus(applicationId, statusMap[uiStatus] || uiStatus, feedbackNote);
      if (interviewDetails) await request(`/applications/${encodeURIComponent(applicationId)}/schedule`, { method: 'PATCH', body: JSON.stringify({ title: interviewDetails.roundName || 'Interview', round: interviewDetails.roundName || 'Technical Interview', date: interviewDetails.scheduledDate, time: interviewDetails.timeString || '', meetLink: interviewDetails.meetingLink || '' }) });
      return result;
    },
  },

  // Personal private cloud, reminders and admin knowledge base
  files: {
    async list() { const r = await request('/files'); return getArray(r, 'files'); },
    async upload(file, folder='My Files') { const body=new FormData(); body.append('file',file); body.append('folder',folder); return request('/files',{method:'POST',body}); },
    async addVersion(id,file) { const body=new FormData(); body.append('file',file); return request(`/files/${encodeURIComponent(id)}/version`,{method:'POST',body}); },
    async download(id) { return request(`/files/${encodeURIComponent(id)}/download`); },
    async versions(id) { const r=await request(`/files/${encodeURIComponent(id)}/versions`); return getArray(r,'versions'); },
    async restoreVersion(id,version) { return request(`/files/${encodeURIComponent(id)}/restore/${version}`,{method:'POST'}); },
    async share(id,permissions='view',expiresAt) { return request(`/files/${encodeURIComponent(id)}/share`,{method:'POST',body:JSON.stringify({permissions,expiresAt})}); },
    async revoke(id) { return request(`/files/${encodeURIComponent(id)}/share`,{method:'DELETE'}); },
    async remove(id) { return request(`/files/${encodeURIComponent(id)}`,{method:'DELETE'}); },
  },
  reminders: {
    async list() { const r=await request('/reminders'); return getArray(r,'reminders'); },
    async create(data) { return request('/reminders',{method:'POST',body:JSON.stringify(data)}); },
    async update(id,data) { return request(`/reminders/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(data)}); },
    async remove(id) { return request(`/reminders/${encodeURIComponent(id)}`,{method:'DELETE'}); },
  },
  knowledge: {
    async list() { const r=await request('/admin/knowledge'); return getArray(r,'documents'); },
    async add({title,description,file,text,isPublished=true}) { const body=new FormData();body.append('title',title);body.append('description',description||'');body.append('isPublished',String(isPublished));if(file)body.append('document',file);if(text)body.append('text',text);return request('/admin/knowledge',{method:'POST',body}); },
    async update(id,data) { return request(`/admin/knowledge/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(data)}); },
    async remove(id) { return request(`/admin/knowledge/${encodeURIComponent(id)}`,{method:'DELETE'}); },
  },

  // Admin methods
  admin: {
    async getStudents() { const result = await request('/admin/students'); return getArray(result, 'students'); },
    async getRecruiters() { const result = await request('/admin/recruiters'); return getArray(result, 'recruiters'); },
    async getAllStudents() {
      const users = await this.getStudents();
      return users.map(u => ({ user: { id: u._id || u.id, name: u.name, email: u.email, phone: u.phone, isActive: u.isActive !== false }, profile: u.profile ? { ...u.profile, cgpa: u.profile.currentCGPA, skills: u.profile.technicalSkills || [], backlogs: u.profile.backlogs || 0, placementStatus: u.profile.placementStatus || 'Looking for Opportunities' } : null }));
    },
    async getAllRecruiters() {
      const users = await this.getRecruiters();
      return users.map(u => ({ user: { id: u._id || u.id, name: u.name, email: u.email, phone: u.phone, isActive: u.isActive !== false }, profile: { companyName: u.companyName || '', industry: u.industry || '', website: u.website || '', location: u.location || '', contactPerson: u.contactPerson || '', designation: u.designation || '', aboutCompany: u.aboutCompany || '' } }));
    },
    async toggleUserStatus(userId) {
      const result = await request(`/admin/users/${encodeURIComponent(userId)}/status`, { method: 'PATCH', body: JSON.stringify({}) });
      return result.user || result;
    },
    async getAnalytics() { return request('/admin/stats'); },
    async getSiteSettings() { const r = await request('/admin/site-settings'); return r.settings || {}; },
    async updateSiteSettings(data) { return request('/admin/site-settings', { method: 'PATCH', body: JSON.stringify(data) }); },
    async getEnquiries() { const result = await request('/admin/enquiries'); return getArray(result, 'enquiries'); },
    async updateEnquiry(id, data) { return request(`/admin/enquiries/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(data) }); },
    async deleteEnquiry(id) { return request(`/admin/enquiries/${encodeURIComponent(id)}`, { method: 'DELETE' }); },
    async replyToEnquiry(id, data) { return request(`/admin/enquiries/${encodeURIComponent(id)}/reply`, { method: 'POST', body: JSON.stringify(data) }); },
    async getDrives() {
      const result = await request('/admin/drives');
      return getArray(result, 'drives').map(d => ({ ...d, id: d._id || d.id, jobTitle: d.jobRole || d.jobTitle, ctcSalary: d.package || d.ctc || 'Not specified' }));
    },
    async createDrive(data) { const result = await request('/admin/drives', { method: 'POST', body: JSON.stringify(data) }); return result.drive || result; },
    async updateDrive(id, data) { const result = await request(`/admin/drives/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(data) }); return result.drive || result; },
    async getApplications() {
      const result = await request('/admin/applications');
      const statusMap = { 'Applied': 'applied', 'Under Review': 'under_review', 'Shortlisted': 'shortlisted', 'Written Test': 'assessment_round', 'Technical Interview': 'interview_scheduled', 'HR Interview': 'interview_scheduled', 'Selected': 'selected', 'Rejected': 'rejected' };
      return getArray(result, 'applications').map(a => ({ ...a, id: a._id || a.id, student: a.studentId, drive: a.driveId ? { ...a.driveId, jobTitle: a.driveId.jobRole || a.driveId.jobTitle } : null, driveId: String(a.driveId?._id || a.driveId || ''), status: statusMap[a.status] || a.status }));
    },
    async updateApplicantStatus(applicationId, uiStatus, note = '', interviewDetails) {
      const statusMap = { under_review: 'Under Review', shortlisted: 'Shortlisted', assessment_round: 'Written Test', interview_scheduled: 'Technical Interview', selected: 'Selected', rejected: 'Rejected' };
      const result = await request(`/admin/applications/${encodeURIComponent(applicationId)}/status`, { method: 'PATCH', body: JSON.stringify({ status: statusMap[uiStatus] || uiStatus, note }) });
      if (interviewDetails) await request(`/applications/${encodeURIComponent(applicationId)}/schedule`, { method: 'PATCH', body: JSON.stringify({ title: interviewDetails.roundName || 'Interview', round: interviewDetails.roundName || 'Technical Interview', date: interviewDetails.scheduledDate, time: interviewDetails.timeString || '', meetLink: interviewDetails.meetingLink || '' }) });
      return result;
    },
  },
};

export default api;
