// Deprecated: application data must come from the authenticated API.
// This module intentionally contains no seeded users, passwords, drives,
// placement statistics, testimonials or simulated resource downloads.
export const dbStore = Object.freeze({
  getDrives: () => [],
  getAnnouncements: () => [],
  getResources: () => [],
  getApplicationsByStudentId: () => [],
});
