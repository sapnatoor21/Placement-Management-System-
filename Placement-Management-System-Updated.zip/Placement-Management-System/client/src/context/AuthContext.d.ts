
import type { ReactElement, ReactNode } from 'react';

export interface AuthUser {
  id?: string;
  _id?: string;
  name?: string;
  email?: string;
  role?: string;
  [key: string]: unknown;
}

export interface AuthContextValue {
  user: AuthUser | null;
  role: string | null;
  token: string | null;
  isLoading: boolean;

  login: (email: string, password: string) => Promise<AuthUser>;
  registerStudent: (formData: Record<string, unknown>) => Promise<AuthUser>;

  logout: () => void;
  refreshUser: () => Promise<AuthUser | null | void>;
  updateProfileState: (profile: Record<string, unknown>) => void;

  toast: { message: string; type: string } | null;
  showToast: (message: string, type?: string) => void;
  clearToast: () => void;

  authModal: unknown;
  setAuthModal: (value: unknown) => void;

  currentRoute: string;
  navigate: (route: string) => void;
}

export function AuthProvider(
  props: { children: ReactNode }
): ReactElement;

export function useAuth(): AuthContextValue;
