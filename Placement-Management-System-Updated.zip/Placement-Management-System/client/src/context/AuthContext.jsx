
import {
  createContext,
  useContext,
  useState,
  useEffect,
} from 'react';

import { api } from '../services/api';

const AuthContext = createContext(null);

const AUTH_USER_KEY = 'kmv_placement_auth_user';
const AUTH_TOKEN_KEY = 'kmv_placement_auth_token';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [toast, setToast] = useState(null);
  const [authModal, setAuthModal] = useState(null);
  const [currentRoute, setCurrentRoute] = useState('home');

  useEffect(() => {
    let cancelled = false;

    async function restoreSession() {
      const savedToken = localStorage.getItem(AUTH_TOKEN_KEY);
      const savedUser = localStorage.getItem(AUTH_USER_KEY);

      if (!savedToken || !savedUser) {
        if (!cancelled) setIsLoading(false);
        return;
      }

      try {
        const parsedUser = JSON.parse(savedUser);

        if (!cancelled) {
          setToken(savedToken);
          setUser(parsedUser);
        }

        const freshUser = await api.auth.getMe();

        if (!cancelled && freshUser) {
          setUser(freshUser);

          localStorage.setItem(
            AUTH_USER_KEY,
            JSON.stringify(freshUser)
          );
        }
      } catch (error) {
        console.error('Session restore failed:', error);

        if (!cancelled) {
          setUser(null);
          setToken(null);

          localStorage.removeItem(AUTH_TOKEN_KEY);
          localStorage.removeItem(AUTH_USER_KEY);
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    restoreSession();

    return () => {
      cancelled = true;
    };
  }, []);

  // Save authenticated user session
  function saveSession(authData) {
    const newToken =
      authData?.token || authData?.data?.token;

    const newUser =
      authData?.user || authData?.data?.user;

    if (!newToken || !newUser) {
      throw new Error(
        'Login response does not contain both user and token.'
      );
    }

    setToken(newToken);
    setUser(newUser);

    localStorage.setItem(AUTH_TOKEN_KEY, newToken);

    localStorage.setItem(
      AUTH_USER_KEY,
      JSON.stringify(newUser)
    );

    return newUser;
  }

  // Login and navigate according to user role
  async function login(email, password) {
    const result = await api.auth.login(email, password);

    const loggedInUser = saveSession(result);
    setAuthModal(null);

    showToast('Login Successful!', 'success');

    const role = loggedInUser.role?.toLowerCase();

    if (role === 'student') {
      navigate('student/dashboard');
    } else if (role === 'recruiter') {
      navigate('recruiter/dashboard');
    } else if (role === 'admin') {
      navigate('admin/dashboard');
    } else {
      showToast(
        'Login successful, but user role is not recognized.',
        'error'
      );
    }

    return loggedInUser;
  }

  // Passwordless email OTP login.
  async function loginWithOTP(email, otp) {
    const result = await api.auth.verifyLoginOTP(email, otp);
    const loggedInUser = saveSession(result);
    setAuthModal(null);
    showToast('Login successful!', 'success');
    const role = loggedInUser.role?.toLowerCase();
    if (role === 'student') navigate('student/dashboard');
    else if (role === 'recruiter') navigate('recruiter/dashboard');
    else if (role === 'admin') navigate('admin/dashboard');
    return loggedInUser;
  }


  // Register student
  async function registerStudent(formData) {
    const result = await api.auth.registerStudent(formData);
    if (result?.token || result?.data?.token) {
      const registeredUser = saveSession(result);
      setAuthModal(null);
      return registeredUser;
    }
    return result;
  }

  // Logout user
  function logout() {
    setUser(null);
    setToken(null);
    setCurrentRoute('home');

    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(AUTH_USER_KEY);
  }

  // Refresh user details
  async function refreshUser() {
    const freshUser = await api.auth.getMe();

    if (freshUser) {
      setUser(freshUser);

      localStorage.setItem(
        AUTH_USER_KEY,
        JSON.stringify(freshUser)
      );
    }

    return freshUser;
  }

  // Update profile state
  function updateProfileState(profile) {
    setUser((previousUser) => {
      if (!previousUser) return previousUser;

      const updatedUser = {
        ...previousUser,
        ...profile,
      };

      localStorage.setItem(
        AUTH_USER_KEY,
        JSON.stringify(updatedUser)
      );

      return updatedUser;
    });
  }

  // Show toast notification
  function showToast(message, type = 'info') {
    setToast({
      message,
      type,
    });
  }

  useEffect(() => {
    if (!toast) return undefined;
    const timer = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(timer);
  }, [toast]);

  // Clear toast notification
  function clearToast() {
    setToast(null);
  }

  // Navigate to application route
  function navigate(route) {
    setCurrentRoute(route);
  }

  const value = {
    user,
    role: user?.role || null,
    token,
    isLoading,

    login,
    loginWithOTP,
    registerStudent,
    logout,
    refreshUser,
    updateProfileState,

    toast,
    showToast,
    clearToast,

    authModal,
    setAuthModal,

    currentRoute,
    navigate,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error(
      'useAuth must be used within an AuthProvider'
    );
  }

  return context;
}
