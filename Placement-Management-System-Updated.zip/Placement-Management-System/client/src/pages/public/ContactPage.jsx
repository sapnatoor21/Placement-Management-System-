import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle2, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

const initialForm = {
  name: '',
  email: '',
  phone: '',
  subject: 'Campus Recruitment Invitation',
  message: '',
};

export const ContactPage = () => {
  const { showToast } = useAuth();
  const [formData, setFormData] = useState(initialForm);
  const [submitted, setSubmitted] = useState(false);
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      await api.public.submitEnquiry(formData);
      setSubmitted(true);
      showToast('Your enquiry has been submitted successfully.', 'success');
    } catch (error) {
      showToast(error.message || 'Unable to submit your enquiry. Please try again.', 'error');
    } finally {
      setBusy(false);
    }
  };

  const update = (event) => setFormData((current) => ({ ...current, [event.target.name]: event.target.value }));

  return (
    <div className="mx-auto max-w-7xl space-y-10 px-4 py-10 sm:px-6 lg:px-8">
      <header className="border-b border-[#DCE3F5] pb-6">
        <span className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Get in Touch</span>
        <h1 className="mt-2 text-2xl font-extrabold text-[#20245B] sm:text-3xl">Contact KMV Training & Placement Cell</h1>
        <p className="mt-2 max-w-3xl text-sm text-[#66739A]">Reach out for corporate drive scheduling, campus invitations, student credentials verification, or placement guidance.</p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:gap-8">
        <section className="space-y-5 rounded-2xl border border-[#DCE3F5] bg-white p-5 shadow-sm sm:p-7 lg:col-span-5">
          <div><h2 className="text-lg font-bold text-[#20245B]">Placement Cell Office</h2><p className="mt-1 text-sm text-[#66739A]">Office of the Dean, Training & Placement Services</p></div>
          <div className="space-y-3 text-sm">
            <ContactInfo icon={MapPin} title="Campus Address">Kanya Maha Vidyalaya (Autonomous), Vidyalaya Marg, Tanda Road, Jalandhar, Punjab, India.</ContactInfo>
            <ContactInfo icon={Phone} title="Telephone Enquiries">+91 181 2296605 / 2296606</ContactInfo>
            <ContactInfo icon={Mail} title="Official Email"><a className="hover:underline" href="mailto:placement@kmv.ac.in">placement@kmv.ac.in</a></ContactInfo>
            <ContactInfo icon={Clock} title="Working Hours">Monday to Saturday: 9:00 AM – 4:30 PM IST</ContactInfo>
          </div>
        </section>

        <section className="rounded-2xl border border-[#DCE3F5] bg-white p-5 shadow-sm sm:p-7 lg:col-span-7">
          <div className="mb-6"><h2 className="text-lg font-bold text-[#20245B]">Send an Official Enquiry</h2><p className="mt-1 text-sm text-[#66739A]">Recruiters and students may send enquiries directly to our coordinators.</p></div>
          {submitted ? (
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50/70 p-7 text-center">
              <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-600" />
              <h3 className="mt-3 font-bold text-[#20245B]">Thank you! Your message was received.</h3>
              <p className="mx-auto mt-2 max-w-md text-sm text-[#66739A]">Your enquiry has been saved. A member of the Placement Management System team will review it and respond via email or telephone.</p>
              <button type="button" onClick={() => { setFormData(initialForm); setSubmitted(false); }} className="mt-5 rounded-lg bg-[#3154B8] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#25469e]">Send Another Message</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Your Name *"><input name="name" required maxLength={120} value={formData.name} onChange={update} placeholder="Your full name" className={inputClass} /></Field>
                <Field label="Email Address *"><input name="email" type="email" required maxLength={180} value={formData.email} onChange={update} placeholder="you@example.com" className={inputClass} /></Field>
                <Field label="Contact Phone"><input name="phone" type="tel" maxLength={30} value={formData.phone} onChange={update} placeholder="+91 98765 00000" className={inputClass} /></Field>
                <Field label="Query Subject"><select name="subject" value={formData.subject} onChange={update} className={inputClass}>{['Campus Recruitment Invitation', 'Student Placement Verification', 'Internship Collaboration', 'Technical Workshop & Guest Lecture', 'General Student Guidance'].map((subject) => <option key={subject}>{subject}</option>)}</select></Field>
              </div>
              <Field label="Message Details *"><textarea name="message" required minLength={10} maxLength={5000} rows={5} value={formData.message} onChange={update} placeholder="Please provide details about your enquiry..." className={inputClass} /></Field>
              <button disabled={busy} type="submit" className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#3154B8] px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#25469e] disabled:cursor-not-allowed disabled:opacity-60">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}{busy ? 'Submitting…' : 'Submit Official Message'}
              </button>
            </form>
          )}
        </section>
      </div>
    </div>
  );
};

const inputClass = 'mt-1 w-full rounded-xl border border-[#DCE3F5] bg-[#F8FAFF] px-3.5 py-3 text-sm text-[#252B63] outline-none transition focus:border-[#3154B8] focus:ring-2 focus:ring-[#3154B8]/10';
function Field({ label, children }) { return <label className="block text-xs font-semibold text-[#252B63]">{label}{children}</label>; }
function ContactInfo({ icon: Icon, title, children }) { return <div className="flex items-start gap-3 rounded-xl border border-[#DCE3F5] bg-[#F8FAFF] p-3.5"><Icon className="mt-0.5 h-5 w-5 shrink-0 text-[#3154B8]"/><div className="min-w-0"><p className="font-bold text-[#20245B]">{title}</p><p className="mt-1 break-words text-[#66739A]">{children}</p></div></div>; }
