import React, { useEffect, useState } from 'react';
import { BadgeCheck, Trophy } from 'lucide-react';
import { api } from '../../services/api';

export const SuccessStoriesPage = () => {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const load = async () => { setLoading(true); setError(''); try { setStories(await api.successStories.getAll()); } catch (e) { setError(e.message || 'Unable to load success stories.'); } finally { setLoading(false); } };
  useEffect(() => { load(); }, []);
  return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
    <header className="border-b border-[#DCE3F5] pb-6"><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Verified Achievements</p><h1 className="mt-1 text-3xl font-extrabold text-[#20245B]">Placement Management System Success Stories & Testimonials</h1><p className="mt-2 text-sm text-[#66739A]">Real stories of transformation, resilience, and campus placements from Kanya Maha Vidyalaya alumni.</p></header>
    {loading ? <p className="rounded-xl border border-[#DCE3F5] bg-white p-5 text-sm text-[#66739A]">Loading verified stories…</p> : error ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-700">{error}<button onClick={load} className="ml-3 font-bold underline">Retry</button></div> : stories.length ? <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">{stories.map(s => <article key={s._id} className="rounded-2xl border border-[#DCE3F5] bg-white p-6"><div className="flex items-center justify-between"><div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#20245B] font-bold text-white">{s.studentName.split(/\s+/).map(x => x[0]).slice(0,2).join('').toUpperCase()}</div><span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700"><BadgeCheck className="mr-1 inline h-3.5 w-3.5"/>Verified</span></div><p className="mt-4 text-2xl font-extrabold text-[#3154B8]">{s.package || 'Package not disclosed'}</p><h2 className="mt-2 font-bold text-[#252B63]">{s.studentName}</h2><p className="text-xs text-[#66739A]">{s.course} · {s.batch}</p><div className="mt-4 border-t border-[#DCE3F5] pt-4"><p className="font-semibold text-[#20245B]">{s.company}</p><p className="text-xs text-[#66739A]">{s.role}</p></div>{s.testimonial && <blockquote className="mt-4 text-sm italic leading-6 text-[#66739A]">“{s.testimonial}”</blockquote>}</article>)}</div> : <div className="rounded-2xl border border-dashed border-[#BFC9E6] bg-white py-14 text-center"><Trophy className="mx-auto h-8 w-8 text-[#66739A]"/><h2 className="mt-3 font-semibold text-[#252B63]">No verified success stories published yet</h2><p className="mt-1 text-sm text-[#66739A]">Verified alumni achievements will appear here after placement-office review.</p></div>}
  </div>;
};
