import React from 'react';
import { Award, Building2, GraduationCap, ShieldCheck, Target, Users, BookOpen, BriefcaseBusiness, ArrowUpRight } from 'lucide-react';

const objectives = [
  { icon: Building2, title: 'Industry–Academia Integration', text: 'Connect academic learning with industry interaction, career counselling, workshops and recruitment exposure.' },
  { icon: ShieldCheck, title: 'Transparent Recruitment', text: 'Support a centralized and trackable process for published opportunities, eligibility and application progress.' },
  { icon: Users, title: 'Holistic Career Readiness', text: 'Help students strengthen communication, aptitude, technical knowledge, resumes and interview confidence.' },
  { icon: Target, title: 'Equal Career Opportunities', text: 'Help students discover suitable pathways while keeping selection decisions with the recruiting organizations.' },
];

export const AboutPage = ({ onNavigate }) => <div className="mx-auto max-w-7xl space-y-12 px-4 py-10 sm:px-6 lg:px-8">
  <section className="overflow-hidden rounded-3xl border border-[#DCE3F5] bg-white">
    <div className="grid lg:grid-cols-[1.2fr_.8fr]">
      <div className="p-7 sm:p-10 lg:p-12">
        <p className="text-xs font-bold uppercase tracking-[.18em] text-[#3154B8]">Institutional Heritage & Excellence</p>
        <h1 className="mt-4 max-w-2xl text-3xl font-extrabold leading-tight text-[#102B50] sm:text-5xl">A legacy of empowering women since 1886.</h1>
        <p className="mt-5 max-w-2xl text-sm leading-7 text-[#667A98]">Kanya Maha Vidyalaya, Jalandhar, combines a long educational heritage with a continuing focus on academic development, student support and career readiness.</p>
        <div className="mt-7 flex flex-wrap gap-3"><button onClick={() => onNavigate('opportunities')} className="rounded-xl bg-[#0D6EFD] px-5 py-3 text-sm font-semibold text-white">Explore Opportunities</button><a href="https://www.kmvjalandhar.ac.in/photo_galleries/placement-cell/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl border border-[#DCE3F5] px-5 py-3 text-sm font-semibold text-[#16345C]">Official Placement Cell Gallery <ArrowUpRight size={15}/></a></div>
      </div>
      <div className="flex min-h-[250px] flex-col justify-between bg-[#102B50] p-7 text-white sm:p-10"><div className="flex items-center gap-3"><div className="rounded-xl bg-white/10 p-3"><GraduationCap size={28}/></div><div><p className="text-xs uppercase tracking-widest text-blue-200">Kanya Maha Vidyalaya</p><p className="mt-1 text-sm font-semibold">Autonomous Heritage Institution</p></div></div><div><p className="text-6xl font-extrabold tracking-tight">1886</p><p className="mt-2 text-sm text-blue-100">A continuing commitment to women's education and empowerment.</p></div></div>
    </div>
  </section>

  <section className="grid gap-5 md:grid-cols-2">
    <article className="rounded-2xl border border-[#DCE3F5] bg-white p-6 sm:p-8"><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">About the Institution</p><h2 className="mt-2 text-2xl font-bold text-[#102B50]">Learning, opportunity and growth</h2><p className="mt-4 text-sm leading-7 text-[#667A98]">Kanya Maha Vidyalaya is a women's educational institution in Jalandhar. Its academic and student-support ecosystem includes career counselling, employability training and placement-related activities that help students prepare for transitions beyond college.</p><p className="mt-3 text-sm leading-7 text-[#667A98]">For current institutional information, programmes and official updates, visitors should refer to KMV's official website.</p><a href="https://www.kmvjalandhar.ac.in/" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-[#3154B8]">Visit official KMV website <ArrowUpRight size={15}/></a></article>
    <article className="rounded-2xl border border-[#DCE3F5] bg-[#F5F8FC] p-6 sm:p-8"><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Training & Placement Cell</p><h2 className="mt-2 text-2xl font-bold text-[#102B50]">From campus learning to career readiness</h2><p className="mt-4 text-sm leading-7 text-[#667A98]">The Placement Cell acts as an interface between students and employment opportunities. Career counselling, employability workshops, professional training and recruitment activities help students understand career options and develop the skills employers look for.</p><button onClick={() => onNavigate('resources')} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#102B50] px-4 py-3 text-sm font-semibold text-white">Explore Career Resources <ArrowUpRight size={15}/></button></article>
  </section>

  <section>
    <div className="max-w-2xl"><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Our Focus</p><h2 className="mt-2 text-2xl font-bold text-[#102B50] sm:text-3xl">Supporting the complete placement journey</h2><p className="mt-3 text-sm leading-7 text-[#667A98]">The Placement Management System brings important recruitment and preparation activities into one connected digital experience.</p></div>
    <div className="mt-6 grid gap-4 sm:grid-cols-2">{objectives.map(({ icon: Icon, title, text }, index) => <article key={title} className="rounded-2xl border border-[#DCE3F5] bg-white p-6"><div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#EAF2FF] text-[#0D6EFD]"><Icon size={20}/></span><span className="text-xs font-bold text-[#8BA0BE]">0{index + 1}</span></div><h3 className="mt-4 font-bold text-[#16345C]">{title}</h3><p className="mt-2 text-sm leading-6 text-[#6B85A8]">{text}</p></article>)}</div>
  </section>

  <section className="rounded-2xl border border-[#DCE3F5] bg-white p-6 sm:p-8"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Explore KMV</p><h2 className="mt-2 text-xl font-bold text-[#102B50]">Explore official campus information</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#667A98]">See official campus facilities, placement-cell activities and institutional updates through KMV's own website and gallery.</p></div><div className="flex flex-wrap gap-2"><a href="https://www.kmvjalandhar.ac.in/sitepages/campus-profile/" target="_blank" rel="noreferrer" className="rounded-xl border border-[#DCE3F5] px-4 py-3 text-sm font-semibold text-[#16345C]">Campus Profile</a><a href="https://www.kmvjalandhar.ac.in/photo_galleries/placement-cell/" target="_blank" rel="noreferrer" className="rounded-xl bg-[#0D6EFD] px-4 py-3 text-sm font-semibold text-white">Placement Gallery</a></div></div></section>
</div>;
