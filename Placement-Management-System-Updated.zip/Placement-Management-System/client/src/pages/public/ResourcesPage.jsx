import React, { useEffect, useMemo, useState } from 'react';
import { Download, Search, FileText } from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

const categories = [
  { id: 'All', label: 'All Resources' },
  { id: 'programming', label: 'Programming' },
  { id: 'dsa', label: 'Data Structures & Algorithms' },
  { id: 'aptitude', label: 'Aptitude' },
  { id: 'communication', label: 'Communication' },
  { id: 'dbms', label: 'Database Management' },
  { id: 'web_development', label: 'Web Development' },
  { id: 'artificial_intelligence', label: 'Artificial Intelligence' },
  { id: 'data_science', label: 'Data Science' },
  { id: 'interview_preparation', label: 'Interview Preparation' },
  { id: 'resume_preparation', label: 'Resume Preparation' },
];

export const ResourcesPage = () => {
  const {user,showToast,setAuthModal}=useAuth();
  const [resources, setResources] = useState([]);
  const [progress,setProgress]=useState([]);
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const load = async () => {
    setLoading(true); setError('');
    try { const [items,p]=await Promise.all([api.resources.getAll(),user?.role==='student'?api.resources.getMyProgress().catch(()=>[]):Promise.resolve([])]);setResources(items);setProgress(p); }
    catch (e) { setError(e.message || 'Unable to load resources.'); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [user?.id,user?.role]);
  const updateProgress=async(id,patch)=>{if(!user){setAuthModal('login');return;}try{const r=await api.resources.updateProgress(id,patch);setProgress(old=>[...old.filter(x=>String(x.resourceId)!==String(id)),r.progress]);showToast('Resource progress saved.','success');}catch(e){showToast(e.message||'Could not save progress.','error');}};
  const filtered = useMemo(() => resources.filter(r => (category === 'All' || r.category === category) && `${r.title} ${r.description || ''}`.toLowerCase().includes(search.toLowerCase())), [resources, category, search]);
  return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-7">
    <header className="border-b border-[#DCE3F5] pb-6"><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Curated Placement Material</p><h1 className="mt-1 text-3xl font-extrabold text-[#20245B]">Career Resources & Interview Handbooks</h1><p className="mt-2 text-sm text-[#66739A]">Study materials, aptitude formula guides, technical references and resume formats published by the Placement Cell.</p></header>
    <div className="flex flex-col gap-4"><div className="flex flex-wrap gap-2">{categories.map(c => <button key={c.id} onClick={() => setCategory(c.id)} className={`rounded-lg px-3 py-2 text-xs font-semibold ${category === c.id ? 'bg-[#3154B8] text-white' : 'border border-[#DCE3F5] bg-white text-[#252B63]'}`}>{c.label}</button>)}</div><div className="relative max-w-sm"><Search className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search resources…" className="w-full rounded-xl border border-[#DCE3F5] bg-white py-2.5 pl-9 pr-3 text-sm"/></div></div>
    {loading ? <p className="rounded-xl border border-[#DCE3F5] bg-white p-5 text-sm text-[#66739A]">Loading resources…</p> : error ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-700">{error}<button onClick={load} className="ml-3 font-bold underline">Retry</button></div> : filtered.length ? <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">{filtered.map(r => <article key={r._id || r.id} className="flex flex-col justify-between rounded-2xl border border-[#DCE3F5] bg-white p-5"><div><div className="flex items-center justify-between gap-2"><span className="rounded-md bg-blue-50 px-2 py-1 text-[10px] font-bold uppercase text-[#3154B8]">{r.category}</span><span className="text-[10px] font-semibold text-[#66739A]">{r.fileType || 'File'}{r.fileSize ? ` · ${r.fileSize}` : ''}</span></div><h2 className="mt-4 font-bold text-[#252B63]">{r.title}</h2><p className="mt-2 text-xs leading-5 text-[#66739A]">{r.description}</p></div><div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-[#DCE3F5] pt-4"><div className="flex gap-2"><button onClick={()=>updateProgress(r._id||r.id,{bookmarked:!progress.find(x=>String(x.resourceId)===String(r._id||r.id))?.bookmarked})} className="rounded-lg border px-2 py-1 text-[10px]">{progress.find(x=>String(x.resourceId)===String(r._id||r.id))?.bookmarked?'★ Saved':'☆ Save'}</button><button onClick={()=>updateProgress(r._id||r.id,{completed:!progress.find(x=>String(x.resourceId)===String(r._id||r.id))?.completed})} className="rounded-lg border px-2 py-1 text-[10px]">{progress.find(x=>String(x.resourceId)===String(r._id||r.id))?.completed?'Completed':'Mark complete'}</button></div><span className="text-[11px] text-[#66739A]">{Number(r.downloadCount || 0)} downloads</span><a href={api.resources.getDownloadUrl(r._id || r.id)} className="inline-flex items-center gap-2 rounded-lg bg-[#20245B] px-3 py-2 text-xs font-semibold text-white"><Download className="h-3.5 w-3.5"/> Download</a></div></article>)}</div> : <div className="rounded-2xl border border-dashed border-[#BFC9E6] bg-white py-14 text-center"><FileText className="mx-auto h-8 w-8 text-[#66739A]"/><h2 className="mt-3 font-semibold text-[#252B63]">No resources published yet</h2><p className="mt-1 text-sm text-[#66739A]">The Placement Cell will add downloadable study materials here.</p></div>}
  </div>;
};
