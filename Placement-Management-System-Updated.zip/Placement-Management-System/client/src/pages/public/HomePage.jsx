import React, { useEffect, useState } from 'react';
import { ArrowRight, GraduationCap, BookOpen, Trophy, Megaphone, CalendarDays } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

export const HomePage = ({ onNavigate }) => {
  const { user, setAuthModal } = useAuth();
  const [notices, setNotices] = useState([]);
  const [stats, setStats] = useState(null);
  const [highlights, setHighlights] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [retryKey, setRetryKey] = useState(0);

  useEffect(() => {
    let active = true;
    Promise.allSettled([
      api.announcements.getAnnouncements(),
      api.public.getHomeStats(),
      api.public.getPlacementHighlights(),
    ]).then(([noticeResult, statsResult, highlightResult]) => {
      if (!active) return;
      const errors = [];
      if (noticeResult.status === 'fulfilled') {
        const result = noticeResult.value;
        setNotices(Array.isArray(result) ? result : result?.announcements || result?.notices || result?.data?.announcements || []);
      } else errors.push('notices');
      if (statsResult.status === 'fulfilled') setStats(statsResult.value.statistics || statsResult.value.stats || null);
      else errors.push('statistics');
      if (highlightResult.status === 'fulfilled') setHighlights(highlightResult.value.highlights || null);
      else setHighlights(null);
      if (errors.length) setLoadError(`Could not load ${errors.join(', ')}. Please retry.`);
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [retryKey]);

  const openPortal = () => onNavigate(`${user.role}/dashboard`);
  const stories = highlights?.stories || [];

  return <div className="pb-16 space-y-14">
    <section className="border-b border-[#DCE3F5] bg-white">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Kanya Maha Vidyalaya · Estd. 1886</p>
          <h1 className="mt-4 text-4xl font-extrabold leading-tight text-[#20245B] sm:text-5xl">Build your career.<br/><span className="text-[#3154B8]">Prepare with confidence.</span></h1>
          <p className="mt-5 max-w-xl text-sm leading-7 text-[#66739A] sm:text-base">Welcome to the Placement Management System — one platform for student placement support, recruitment preparation and career development.</p>
          <p className="mt-2 max-w-xl text-xs font-semibold leading-5 text-[#3154B8]">An Integrated Platform for Campus Recruitment and Career Development</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <button onClick={() => onNavigate('about')} className="rounded-xl bg-[#3154B8] px-5 py-3 text-sm font-semibold text-white">Learn More About KMV <ArrowRight className="ml-2 inline h-4 w-4"/></button>
            <button onClick={() => onNavigate('stories')} className="rounded-xl border border-[#DCE3F5] bg-white px-5 py-3 text-sm font-semibold text-[#252B63]">Success Stories</button>
          </div>
          {stats && <div className="mt-9 grid grid-cols-2 gap-3 border-t border-[#DCE3F5] pt-5">{[['Students', stats.students], ['Recruiters', stats.recruiters]].map(([label, value]) => <div key={label}><p className="text-2xl font-bold text-[#20245B]">{Number(value || 0).toLocaleString()}</p><p className="text-xs text-[#66739A]">{label}</p></div>)}</div>}
        </div>

        <div className="rounded-2xl border border-[#DCE3F5] bg-[#F5F8FC] p-6 sm:p-8">
          <div className="flex items-center gap-3 border-b border-[#DCE3F5] pb-5">
            <div className="rounded-xl bg-[#3154B8] p-3 text-white"><GraduationCap/></div>
            <div><h2 className="font-bold text-[#20245B]">Student Gateway</h2><p className="text-xs text-[#66739A]">Placement and career development portal</p></div>
          </div>
          <p className="mt-5 text-sm leading-6 text-[#66739A]">Sign in to manage your student profile, applications, resume, assessments and career preparation activities.</p>
          <div className="mt-5 border-t border-[#DCE3F5] pt-5">
            {user
              ? <button onClick={openPortal} className="w-full rounded-xl bg-[#20245B] px-4 py-3 text-sm font-semibold text-white">Open My Portal</button>
              : <div className="grid grid-cols-2 gap-2"><button onClick={() => setAuthModal('login')} className="rounded-xl bg-[#20245B] px-4 py-3 text-sm font-semibold text-white">Sign In</button><button onClick={() => setAuthModal('register')} className="rounded-xl bg-[#3154B8] px-4 py-3 text-sm font-semibold text-white">Student Register</button></div>}
          </div>
        </div>
      </div>
    </section>

    <section className="mx-auto grid max-w-7xl grid-cols-1 gap-5 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-8">
      {[[Trophy, 'Success Stories', 'Read verified experiences shared by KMV alumni.', 'stories'], [BookOpen, 'Career Resources', 'Access aptitude, technical and interview preparation material.', 'resources'], [Megaphone, 'Campus Notices', 'Stay informed about placement announcements and deadlines.', 'notices']].map(([Icon, title, description, route]) => <button key={title} onClick={() => onNavigate(route)} className="rounded-2xl border border-[#DCE3F5] bg-white p-6 text-left transition hover:-translate-y-0.5 hover:border-[#3154B8]"><Icon className="h-7 w-7 text-[#3154B8]"/><h2 className="mt-4 font-bold text-[#20245B]">{title}</h2><p className="mt-2 text-sm leading-6 text-[#66739A]">{description}</p><span className="mt-4 inline-flex items-center text-xs font-semibold text-[#3154B8]">Explore <ArrowRight className="ml-1 h-3.5 w-3.5"/></span></button>)}
    </section>

    <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
        <div><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Placement Highlights</p><h2 className="mt-1 text-2xl font-bold text-[#20245B]">Verified student achievements</h2><p className="mt-2 text-sm text-[#66739A]">Only alumni stories verified and published by the Placement Cell appear here.</p></div>
        <button onClick={() => onNavigate('stories')} className="inline-flex items-center gap-1 text-sm font-semibold text-[#3154B8]">View Success Stories <ArrowRight size={15}/></button>
      </div>
      {stories.length ? <div className="mt-5 grid gap-4 md:grid-cols-3">{stories.map((story) => <article key={story._id} className="rounded-2xl border border-[#DCE3F5] bg-white p-5"><p className="text-xs font-bold uppercase tracking-wide text-[#3154B8]">{story.company}</p><h3 className="mt-2 text-base font-bold text-[#20245B]">{story.studentName}</h3><p className="mt-1 text-sm text-[#66739A]">{story.role} · {story.course}{story.batch ? ` · ${story.batch}` : ''}</p>{story.testimonial && <p className="mt-3 line-clamp-3 text-sm leading-6 text-[#66739A]">“{story.testimonial}”</p>}</article>)}</div> : <div className="mt-5 rounded-2xl border border-dashed border-[#C9D5EC] bg-white p-7 text-center"><Trophy className="mx-auto h-8 w-8 text-[#A7B4CF]"/><p className="mt-3 font-semibold text-[#20245B]">No verified success stories published yet</p><p className="mt-1 text-sm text-[#66739A]">Verified alumni achievements will appear here after placement-office review.</p></div>}
    </section>

    <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="flex items-end justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Latest Updates</p><h2 className="mt-1 text-2xl font-bold text-[#20245B]">Campus Notices</h2></div><button onClick={() => onNavigate('notices')} className="text-xs font-semibold text-[#3154B8]">View All Notices <ArrowRight className="ml-1 inline h-3.5 w-3.5"/></button></div>
      {loading ? <p className="mt-5 rounded-xl border border-[#DCE3F5] bg-white p-6 text-sm text-[#66739A]">Loading latest updates…</p> : notices.length ? <div className="mt-5 grid gap-4 md:grid-cols-3">{notices.slice(0, 3).map((notice) => <article key={notice._id || notice.id} className="rounded-xl border border-[#DCE3F5] bg-white p-5"><div className="flex items-center gap-2 text-xs text-[#3154B8]"><CalendarDays size={14}/>{notice.createdAt ? new Date(notice.createdAt).toLocaleDateString() : 'Latest notice'}</div><h3 className="mt-2 text-sm font-bold text-[#252B63]">{notice.title}</h3><p className="mt-2 line-clamp-3 text-xs leading-5 text-[#66739A]">{notice.message || notice.description}</p></article>)}</div> : <p className="mt-5 rounded-xl border border-dashed border-[#BFC9E6] bg-white p-6 text-sm text-[#66739A]">No campus notices available right now.</p>}
      {loadError && <p className="mt-3 text-xs text-rose-700" role="alert">{loadError} <button onClick={() => { setLoading(true); setLoadError(''); setRetryKey((value) => value + 1); }} className="font-bold underline">Retry</button></p>}
    </section>
  </div>;
};
