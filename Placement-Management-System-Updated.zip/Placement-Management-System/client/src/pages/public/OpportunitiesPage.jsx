import React, { useEffect, useMemo, useState } from 'react';
import { Search, MapPin, BriefcaseBusiness, CalendarDays, ArrowRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

export const OpportunitiesPage = () => {
  const { user, setAuthModal, showToast } = useAuth();
  const [drives, setDrives] = useState([]);
  const [applications, setApplications] = useState([]);
  const [recommendations,setRecommendations]=useState([]);
  const [search, setSearch] = useState('');
  const [jobType, setJobType] = useState('All');
  const [course, setCourse] = useState('All');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [applyingId, setApplyingId] = useState('');

  const load = async () => {
    setLoading(true); setError('');
    try {
      const results = await Promise.all([api.drives.getAllDrives(), user?.role === 'student' ? api.student.getApplications() : Promise.resolve([]), user?.role==='student'?api.career.getRecommendations().catch(()=>[]):Promise.resolve([])]);
      setDrives(results[0]); setApplications(results[1]); setRecommendations(results[2]);
    } catch (e) { setError(e.message || 'Unable to load placement drives.'); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [user?.id, user?.role]);

  const filtered = useMemo(() => drives.filter(d => {
    const title = d.jobRole || '';
    const skills = Array.isArray(d.skills) ? d.skills.join(' ') : '';
    const eligible = Array.isArray(d.eligibleCourses) ? d.eligibleCourses : [];
    const matchesSearch = `${title} ${d.companyName || ''} ${d.description || ''} ${skills}`.toLowerCase().includes(search.toLowerCase());
    const matchesType = jobType === 'All' || d.jobType === jobType;
    const matchesCourse = course === 'All' || eligible.some(c => c.toLowerCase().includes(course.toLowerCase()));
    return matchesSearch && matchesType && matchesCourse;
  }), [drives, search, jobType, course]);

  const apply = async (drive) => {
    if (!user) { setAuthModal('login'); return; }
    if (user.role !== 'student') { showToast('Only student accounts can apply to placement drives.', 'error'); return; }
    const id = drive._id || drive.id;
    setApplyingId(id);
    try {
      await api.applications.apply(id);
      showToast('Application submitted successfully.', 'success');
      await load();
    } catch (e) { showToast(e.message || 'Unable to submit application.', 'error'); }
    finally { setApplyingId(''); }
  };
  const recommended = new Set(recommendations.map(d=>String(d._id||d.id)));
  const applied = new Set(applications.map(a => String(a.driveId?._id || a.driveId || a.drive?._id || '')));

  return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-7">
    <header className="border-b border-[#DCE3F5] pb-6"><p className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Campus Opportunities</p><h1 className="mt-1 text-3xl font-extrabold text-[#20245B]">Institutional Placement Drives</h1><p className="mt-2 text-sm text-[#66739A]">Discover placement drives and apply for opportunities that match your goals.</p></header>
    <div className="rounded-2xl border border-[#DCE3F5] bg-white p-5 grid md:grid-cols-12 gap-3"><div className="relative md:col-span-6"><Search className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search company, role or skills…" className="w-full rounded-xl border border-[#DCE3F5] bg-[#F5F6FF] py-2.5 pl-9 pr-3 text-sm"/></div><select value={jobType} onChange={e => setJobType(e.target.value)} className="md:col-span-3 rounded-xl border border-[#DCE3F5] bg-[#F5F6FF] px-3 py-2.5 text-sm"><option>All</option><option value="Full-time">Full-time Job</option><option value="Internship">Internship</option><option value="Part-time">Part-time Job</option></select><select value={course} onChange={e => setCourse(e.target.value)} className="md:col-span-3 rounded-xl border border-[#DCE3F5] bg-[#F5F6FF] px-3 py-2.5 text-sm"><option>All</option><option>BCA</option><option>MCA</option><option>B.Sc IT</option><option>M.Sc IT</option><option>B.Com</option></select></div>
    {loading ? <p className="rounded-xl border border-[#DCE3F5] bg-white p-6 text-sm text-[#66739A]">Loading placement drives…</p> : error ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-700">{error}<button onClick={load} className="ml-3 font-bold underline">Retry</button></div> : filtered.length ? <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">{filtered.map(d => { const id = d._id || d.id; const hasApplied = applied.has(String(id)); return <article key={id} className="rounded-2xl border border-[#DCE3F5] bg-white p-5 flex flex-col"><div className="flex items-start justify-between gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#F5F6FF] font-bold text-[#20245B]">{(d.companyName || 'C').slice(0,1)}</div><div className="flex flex-col items-end gap-1"><span className="rounded-full bg-blue-50 px-2.5 py-1 text-[10px] font-bold text-[#3154B8]">{d.status}</span>{recommended.has(String(id))&&<span className="rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-bold text-emerald-700">Recommended for you</span>}</div></div><h2 className="mt-4 font-bold text-[#252B63]">{d.jobRole}</h2><p className="mt-1 text-sm font-semibold text-[#3154B8]">{d.companyName}</p><span className="mt-2 inline-flex w-fit rounded-full bg-blue-50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-[#3154B8]">{d.jobType === 'Internship' ? 'INTERNSHIP' : d.jobType === 'Part-time' ? 'PART-TIME JOB' : d.jobType === 'Full-time' ? 'FULL-TIME JOB' : 'OPPORTUNITY'}</span><div className="mt-4 space-y-2 border-y border-[#DCE3F5] py-3 text-xs text-[#66739A]"><p className="flex items-center gap-2"><BriefcaseBusiness className="h-3.5 w-3.5"/>{d.jobType || 'Role not specified'}</p><p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5"/>{d.location || 'Location not specified'}</p><p className="flex items-center gap-2"><CalendarDays className="h-3.5 w-3.5"/>Apply by: {d.applicationDeadline ? new Date(d.applicationDeadline).toLocaleDateString() : 'Not specified'}</p><p><b className="text-[#252B63]">Package:</b> {d.package || (d.ctc ? `${d.ctc} LPA` : 'Not specified')}</p></div><p className="mt-3 line-clamp-3 text-xs leading-5 text-[#66739A]">{d.description}</p><button disabled={hasApplied || applyingId === id || d.status !== 'Open'} onClick={() => apply(d)} className="mt-auto pt-5"><span className={`flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold ${hasApplied ? 'bg-emerald-50 text-emerald-700' : 'bg-[#20245B] text-white disabled:opacity-50'}`}>{hasApplied ? 'Already Applied' : applyingId === id ? 'Submitting…' : 'Apply Now'} <ArrowRight className="h-3.5 w-3.5"/></span></button></article>; })}</div> : <div className="rounded-2xl border border-dashed border-[#BFC9E6] bg-white py-14 text-center"><BriefcaseBusiness className="mx-auto h-8 w-8 text-[#66739A]"/><h2 className="mt-3 font-semibold text-[#252B63]">No placement drives found</h2><p className="mt-1 text-sm text-[#66739A]">Try another search or check again later.</p><button onClick={() => {setSearch('');setJobType('All');setCourse('All');}} className="mt-4 text-xs font-semibold text-[#3154B8] underline">Clear filters</button></div>}
  </div>;
};
