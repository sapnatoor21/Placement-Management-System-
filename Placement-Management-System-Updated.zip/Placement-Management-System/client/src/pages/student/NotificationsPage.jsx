import React, { useEffect, useState } from 'react';
import { Bell, CheckCheck, Trash2 } from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { io } from 'socket.io-client';

export const NotificationsPage = () => {
  const { showToast } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const load = async () => { setLoading(true); setError(''); try { setItems(await api.notifications.getMyNotifications()); } catch (e) { setError(e.message || 'Unable to load notifications.'); } finally { setLoading(false); } };
  useEffect(() => {
    load();
    const token = localStorage.getItem('kmv_placement_auth_token');
    const apiUrl = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/api\/?$/, '');
    if (!token) return;
    const socket = io(apiUrl, { auth: { token }, transports: ['websocket', 'polling'], reconnection: true });
    socket.on('notification:new', (notification) => setItems(prev => [notification, ...prev.filter(item => item._id !== notification._id)]));
    socket.on('application:updated', () => load());
    return () => socket.disconnect();
  }, []);
  const markAll = async () => { try { await api.notifications.markAllRead(); await load(); } catch (e) { showToast(e.message, 'error'); } };
  const markRead = async (id) => { try { await api.notifications.markRead(id); setItems(prev => prev.map(n => n._id === id ? { ...n, isRead: true } : n)); } catch (e) { showToast(e.message, 'error'); } };
  const remove = async (id) => { try { await api.notifications.remove(id); setItems(prev => prev.filter(n => n._id !== id)); } catch (e) { showToast(e.message, 'error'); } };
  return <div className="space-y-5"><div className="flex items-center justify-between"><div><h2 className="text-xl font-bold text-[#20245B]">Notifications & Alerts</h2><p className="text-xs text-[#66739A]">Placement updates and account activity for your student account.</p></div><button onClick={markAll} disabled={!items.some(n => !n.isRead)} className="inline-flex items-center gap-2 rounded-lg border border-[#DCE3F5] bg-white px-3 py-2 text-xs font-semibold text-[#252B63] disabled:opacity-40"><CheckCheck className="h-4 w-4"/> Mark all read</button></div>
    {loading ? <p className="rounded-xl border border-[#DCE3F5] bg-white p-5 text-sm text-[#66739A]">Loading notifications…</p> : error ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-700">{error}<button onClick={load} className="ml-3 font-bold underline">Retry</button></div> : items.length ? <div className="space-y-3">{items.map(n => <article key={n._id} className={`flex items-start gap-3 rounded-xl border p-4 ${n.isRead ? 'border-[#DCE3F5] bg-white' : 'border-blue-200 bg-blue-50/50'}`}><Bell className="mt-1 h-4 w-4 shrink-0 text-[#3154B8]"/><div className="min-w-0 flex-1"><h3 className="text-sm font-bold text-[#252B63]">{n.title}</h3><p className="mt-1 text-xs leading-5 text-[#66739A]">{n.message}</p><p className="mt-2 text-[10px] text-[#66739A]">{new Date(n.createdAt).toLocaleString()}</p></div><div className="flex gap-2">{!n.isRead && <button onClick={() => markRead(n._id)} className="text-[11px] font-semibold text-[#3154B8]">Mark read</button>}<button onClick={() => remove(n._id)} aria-label="Delete notification" className="text-slate-400 hover:text-rose-600"><Trash2 className="h-4 w-4"/></button></div></article>)}</div> : <div className="rounded-2xl border border-dashed border-[#BFC9E6] bg-white py-14 text-center"><Bell className="mx-auto h-8 w-8 text-[#66739A]"/><h3 className="mt-3 font-semibold text-[#252B63]">No notifications yet</h3><p className="mt-1 text-sm text-[#66739A]">New application and interview updates will appear here.</p></div>}
  </div>;
};
