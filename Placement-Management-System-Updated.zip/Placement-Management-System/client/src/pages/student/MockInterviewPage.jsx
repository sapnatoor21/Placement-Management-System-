import React, { useEffect, useMemo, useState } from 'react';
import { Sparkles, MessageSquare, ChevronRight, LoaderCircle, Mic, MicOff } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

const QUESTIONS = [
  { id: 1, type: 'technical', company: 'TCS', role: 'Assistant System Engineer', question: 'Explain the difference between SQL and NoSQL databases. When would you choose MongoDB over MySQL?', tips: 'Compare relational structure, schema flexibility, transactions, indexing and scaling.' },
  { id: 2, type: 'hr', company: 'Deloitte', role: 'Associate Analyst', question: 'Tell me about a challenging situation in a team project where team members had conflicting opinions. How did you resolve it?', tips: 'Use Situation, Task, Action and Result. Focus on your own contribution.' },
  { id: 3, type: 'technical', company: 'Infosys', role: 'Specialist Programmer', question: 'How does indexing work in a relational database? What are the tradeoffs of adding too many indexes?', tips: 'Discuss B-tree indexes, read performance, storage and write overhead.' },
  { id: 4, type: 'hr', company: 'Wipro', role: 'Project Engineer', question: 'Why do you want to join our organization, and where do you see yourself in the next three to five years?', tips: 'Connect your genuine interests, current skills and realistic learning goals.' },
  { id: 5, type: 'behavioral', company: 'General', role: 'Behavioral Round', question: 'Describe a time you had to learn a new skill quickly to complete a task. What did you do and what was the result?', tips: 'Use Situation, Task, Action and Result. Be clear about your own contribution.' },
  { id: 6, type: 'project', company: 'Project Review', role: 'Project-Based Interview', question: 'Explain the architecture of one project you built, the problem it solves, your contribution and one challenge you faced.', tips: 'Explain the real project, technology choices, your work and verifiable outcomes.' },
  { id: 7, type: 'company', company: 'Company Research', role: 'Company-Specific Round', question: 'What do you understand about this company and how does this role align with your current skills and learning goals?', tips: 'Research the employer and adapt your answer; do not invent company facts.' },
];

export const MockInterviewPage = () => {
  const { showToast } = useAuth();
  const [category, setCategory] = useState('all');
  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [evaluation, setEvaluation] = useState(null);
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [history,setHistory]=useState([]);
  useEffect(()=>{api.advanced.getMockInterviewHistory().then(setHistory).catch(()=>setHistory([]));},[]);
  const questions = useMemo(() => QUESTIONS.filter(q => category === 'all' || q.type === category), [category]);
  const question = questions[index % questions.length];

  const evaluate = async () => {
    if (answer.trim().length < 30) return showToast('Please write at least 30 characters before evaluation.', 'error');
    setBusy(true); setEvaluation(null);
    try {
      const result = await api.advanced.evaluateMockInterview({ question: question.question, answer, category: question.type, company: question.company, role: question.role });
      setEvaluation(result.evaluation);
      setHistory(await api.advanced.getMockInterviewHistory().catch(()=>[]));showToast('Your answer was evaluated and saved.', 'success');
    } catch (error) {
      showToast(error.message || 'AI evaluation is unavailable.', 'error');
    } finally { setBusy(false); }
  };
  const startVoice = () => { const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SpeechRecognition) return showToast('Speech recognition is not supported in this browser. You can type your answer instead.', 'error'); const recognition = new SpeechRecognition(); recognition.lang = 'en-IN'; recognition.interimResults = false; recognition.onstart = () => setListening(true); recognition.onend = () => setListening(false); recognition.onerror = () => { setListening(false); showToast('Microphone recognition failed. Check browser microphone permission.', 'error'); }; recognition.onresult = event => setAnswer(old => `${old}${old ? ' ' : ''}${event.results[0][0].transcript}`); recognition.start(); };
  const next = () => { setIndex(v => (v + 1) % questions.length); setAnswer(''); setEvaluation(null); };

  return <div className="space-y-6">
    <header className="border-b border-[#DCE3F5] pb-4"><span className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">Simulated Mock Interviews</span><h2 className="mt-1 text-2xl font-bold text-[#20245B]">Technical & HR Mock Interview Simulator</h2><p className="text-sm text-slate-500">Practice interview questions and receive structured feedback from your configured AI provider.</p></header>
    <div className="flex flex-wrap gap-2">{[['all','All Categories'],['technical','Technical'],['hr','HR'],['behavioral','Behavioral (STAR)'],['project','Project-Based'],['company','Company-Specific']].map(([value,label]) => <button key={value} onClick={() => {setCategory(value);setIndex(0);setEvaluation(null);setAnswer('');}} className={`rounded-lg px-3 py-2 text-xs font-semibold ${category===value?'bg-[#20245B] text-white':'border border-[#DCE3F5] bg-white text-[#20245B]'}`}>{label}</button>)}</div>
    <div className="grid gap-5 lg:grid-cols-5">
      <section className="space-y-4 rounded-2xl border border-[#DCE3F5] bg-white p-5 lg:col-span-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3"><div><span className="rounded bg-[#20245B] px-2 py-1 text-xs font-bold text-white">{question.company}</span><span className="ml-2 text-xs text-slate-500">{question.role}</span></div><span className="text-xs font-bold uppercase text-[#3154B8]">{question.type} round</span></div>
        <div className="rounded-xl border border-[#DCE3F5] bg-[#F5F6FF] p-4"><div className="mb-2 flex items-center gap-2 text-xs font-bold uppercase text-[#3154B8]"><MessageSquare size={15}/> Interviewer Prompt</div><h3 className="font-semibold leading-relaxed text-[#20245B]">“{question.question}”</h3><p className="mt-3 text-xs leading-5 text-slate-600"><b>Interviewer tip:</b> {question.tips}</p></div>
        <label className="block text-sm font-semibold text-[#20245B]">Your proposed answer<textarea rows={8} value={answer} onChange={e=>setAnswer(e.target.value)} placeholder="Write your answer here. Use clear examples and explain your own contribution." className="mt-2 w-full rounded-xl border border-[#DCE3F5] bg-white p-3 text-sm outline-none focus:border-[#3154B8]"/></label><button type="button" onClick={startVoice} className="flex items-center gap-2 rounded-lg border border-[#DCE3F5] px-3 py-2 text-xs font-semibold text-[#20245B]">{listening?<MicOff size={14}/>:<Mic size={14}/>} {listening?'Listening…':'Answer with microphone'}</button>
        <div className="flex flex-wrap justify-between gap-3"><button onClick={next} className="rounded-lg border border-[#DCE3F5] px-4 py-2 text-sm font-semibold text-[#20245B]">Skip / Next Question</button><button disabled={busy} onClick={evaluate} className="flex items-center gap-2 rounded-lg bg-[#20245B] px-5 py-2 text-sm font-semibold text-white disabled:opacity-60">{busy?<LoaderCircle className="animate-spin" size={16}/>:<Sparkles size={16}/>} {busy?'Evaluating…':'Evaluate My Answer'}</button></div>
      </section>
      <aside className="space-y-4 lg:col-span-2">
        <section className="rounded-2xl border border-[#DCE3F5] bg-white p-5"><h3 className="font-bold text-[#20245B]">Structured AI Evaluation</h3>{evaluation ? <div className="mt-3 space-y-3 text-sm"><p className="text-3xl font-bold text-[#3154B8]">{Number(evaluation.score)}/100</p><p className="text-slate-600">{evaluation.summary}</p>{[['Strengths',evaluation.strengths],['Areas to improve',evaluation.improvements],['Missing points',evaluation.missingPoints]].map(([title,items])=><div key={title}><h4 className="font-semibold text-[#20245B]">{title}</h4><ul className="mt-1 list-disc space-y-1 pl-5 text-xs text-slate-600">{(items||[]).map((item,i)=><li key={i}>{item}</li>)}</ul></div>)}{evaluation.starBreakdown&&<div className="grid grid-cols-2 gap-2">{Object.entries(evaluation.starBreakdown).map(([part,value])=><div key={part} className="rounded-lg bg-[#F5F6FF] p-2"><p className="text-[10px] font-bold uppercase text-[#3154B8]">{part}</p><p className="text-sm font-bold text-[#20245B]">{value===null?'N/A':`${value}/20`}</p></div>)}</div>}{evaluation.feedback&&<p className="text-xs text-slate-600">{evaluation.feedback}</p>}{evaluation.idealAnswer&&<div className="rounded-lg bg-[#F5F6FF] p-3"><b>Suggested answer</b><p className="mt-1 whitespace-pre-wrap text-xs text-slate-700">{evaluation.idealAnswer}</p></div>}</div>:<p className="mt-2 text-sm leading-6 text-slate-500">Submit your answer to receive a score, strengths, improvement points and an improved answer. AI credentials must be configured by the project administrator.</p>}</section>
        <section className="rounded-2xl border border-[#DCE3F5] bg-white p-5"><h3 className="font-bold text-[#20245B]">Interview Framework</h3><ol className="mt-3 space-y-2 text-sm text-slate-600">{['Situation — set the context','Task — explain your responsibility','Action — describe what you did','Result — share the outcome'].map(x=><li key={x} className="flex gap-2"><ChevronRight size={16} className="text-[#3154B8]"/>{x}</li>)}</ol></section>
      </aside>
    </div>
  </div>;
};
