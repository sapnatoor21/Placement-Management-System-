import React, { useState } from 'react';
import { Code2, Play, RotateCcw, LoaderCircle, AlertTriangle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import Editor from '@monaco-editor/react';

const PROBLEMS = [
  { id:'two-sum', title:'Two Sum', difficulty:'Easy', company:'Practice', description:'Given an array of integers nums and an integer target, return the indices of the two numbers that add up to target.', examples:['nums = [2,7,11,15], target = 9 → [0,1]','nums = [3,2,4], target = 6 → [1,2]'], javascript:'function twoSum(nums, target) {\n  // Write your solution\n  return [];\n}', python:'def two_sum(nums, target):\n    # Write your solution\n    return []', c:'#include <stdio.h>\nint main(void) {\n  // Write your solution\n  return 0;\n}', cpp:'#include <bits/stdc++.h>\nusing namespace std;\nint main() {\n  // Write your solution\n  return 0;\n}', java:'class Main {\n  public static void main(String[] args) {\n    // Write your solution\n  }\n}' },
  { id:'valid-parentheses', title:'Valid Parentheses', difficulty:'Easy', company:'Practice', description:'Given a string containing (), {} and [], determine whether brackets are correctly matched and nested.', examples:['s = "()[]{}" → true','s = "(]" → false'], javascript:'function isValid(s) {\n  // Write your solution\n  return false;\n}', python:'def is_valid(s):\n    # Write your solution\n    return False', c:'int main(void) {\n  // Write your solution\n  return 0;\n}', cpp:'#include <bits/stdc++.h>\nusing namespace std;\nint main() {\n  // Write your solution\n}', java:'class Main {\n  public static void main(String[] args) {\n    // Write your solution\n  }\n}' },
  { id:'palindrome-number', title:'Palindrome Number', difficulty:'Easy', company:'Practice', description:'Given an integer x, return true if it reads the same forward and backward; otherwise return false.', examples:['x = 121 → true','x = -121 → false'], javascript:'function isPalindrome(x) {\n  // Write your solution\n  return false;\n}', python:'def is_palindrome(x):\n    # Write your solution\n    return False', c:'int main(void) {\n  // Write your solution\n  return 0;\n}', cpp:'#include <bits/stdc++.h>\nusing namespace std;\nint main() {\n  // Write your solution\n}', java:'class Main {\n  public static void main(String[] args) {\n    // Write your solution\n  }\n}' },
];
const LANGUAGES = [{id:'javascript',label:'JavaScript (Node.js)',judgeId:63},{id:'python',label:'Python 3',judgeId:71},{id:'c',label:'C (GCC)',judgeId:50},{id:'cpp',label:'C++ (GCC)',judgeId:54},{id:'java',label:'Java',judgeId:62}];

export const CodingArenaPage = () => {
  const { showToast } = useAuth();
  const [problem,setProblem] = useState(PROBLEMS[0]);
  const [language,setLanguage] = useState('javascript');
  const [code,setCode] = useState(PROBLEMS[0].javascript);
  const [stdin,setStdin] = useState('');
  const [result,setResult] = useState(null);
  const [busy,setBusy] = useState(false);
  const chooseProblem = p => {setProblem(p);setCode(p[language] || '');setResult(null);};
  const chooseLanguage = value => {setLanguage(value);setCode(problem[value] || '');setResult(null);};
  const run = async () => {
    if (!code.trim()) return showToast('Please enter your solution code.', 'error');
    setBusy(true);setResult(null);
    try { const response = await api.advanced.runCode({problemId:problem.id,language,languageId:LANGUAGES.find(l=>l.id===language)?.judgeId,sourceCode:code,stdin});setResult(response.result);showToast('Execution completed by the configured code runner.', 'success'); }
    catch(error){setResult({unavailable:true,message:error.message});showToast(error.message || 'Code execution failed.', 'error');}
    finally{setBusy(false);}
  };
  return <div className="space-y-5">
    <header className="border-b border-[#DCE3F5] pb-4"><span className="text-xs font-bold uppercase tracking-wider text-[#3154B8]">DSA Practice Environment</span><h2 className="mt-1 text-2xl font-bold text-[#20245B]">CodeForge</h2><p className="text-sm text-slate-500">Solve programming problems. Execution runs only through the configured Judge0 sandbox.</p></header>
    <div className="flex flex-wrap gap-2">{PROBLEMS.map(p=><button key={p.id} onClick={()=>chooseProblem(p)} className={`rounded-lg px-3 py-2 text-xs font-semibold ${problem.id===p.id?'bg-[#20245B] text-white':'border border-[#DCE3F5] bg-white text-[#20245B]'}`}>{p.title}</button>)}</div>
    <div className="grid gap-5 lg:grid-cols-2">
      <section className="rounded-2xl border border-[#DCE3F5] bg-white p-5"><div className="flex items-center justify-between border-b border-slate-100 pb-3"><h3 className="font-bold text-[#20245B]">{problem.title}</h3><span className="rounded bg-[#E8EDFF] px-2 py-1 text-xs font-bold text-[#3154B8]">{problem.difficulty}</span></div><p className="mt-4 text-sm leading-6 text-slate-600">{problem.description}</p><h4 className="mt-5 text-xs font-bold uppercase text-[#20245B]">Examples</h4><div className="mt-2 space-y-2">{problem.examples.map((x,i)=><pre key={i} className="overflow-x-auto rounded-lg bg-[#F5F6FF] p-3 text-xs text-slate-700">{x}</pre>)}</div><label className="mt-5 block text-xs font-semibold text-[#20245B]">Custom standard input (optional)<textarea value={stdin} onChange={e=>setStdin(e.target.value)} rows={3} className="mt-2 w-full rounded-lg border border-[#DCE3F5] p-3 font-mono text-xs" placeholder="Input passed to stdin"/></label></section>
      <section className="flex flex-col rounded-2xl bg-[#20245B] p-4 text-white"><div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/15 pb-3"><div className="flex items-center gap-2 text-sm font-semibold"><Code2 size={17}/> Solution Editor</div><select value={language} onChange={e=>chooseLanguage(e.target.value)} className="rounded-lg border border-white/20 bg-white/10 px-3 py-2 text-xs text-white">{LANGUAGES.map(l=><option key={l.id} value={l.id} className="text-slate-900">{l.label}</option>)}</select></div><div className="mt-3 min-h-[350px] overflow-hidden rounded-lg border border-white/10"><Editor height="390px" language={({javascript:'javascript',python:'python',c:'c',cpp:'cpp',java:'java'})[language]} value={code} onChange={value=>setCode(value||'')} theme="vs-dark" options={{minimap:{enabled:false},fontSize:13,wordWrap:'on',automaticLayout:true,scrollBeyondLastLine:false,tabSize:4}}/></div><div className="mt-3 flex flex-wrap items-center justify-between gap-2"><button onClick={()=>setCode(problem[language]||'')} className="flex items-center gap-2 text-xs text-slate-300"><RotateCcw size={14}/> Reset Solution</button><button onClick={run} disabled={busy} className="flex items-center gap-2 rounded-lg bg-[#4268D5] px-4 py-2.5 text-xs font-bold text-white disabled:opacity-60">{busy?<LoaderCircle size={15} className="animate-spin"/>:<Play size={15}/>} Run Code</button></div>
      {result&&<div className={`mt-4 rounded-lg border p-3 text-xs ${result.unavailable?'border-amber-400/40 bg-amber-950/40 text-amber-100':'border-white/20 bg-white/10 text-white'}`}>{result.unavailable?<><div className="flex items-center gap-2 font-bold"><AlertTriangle size={15}/> Execution unavailable</div><p className="mt-1">{result.message}</p></>:<><p className="font-bold">{result.status?.description || 'Execution response received'}</p>{result.stdout&&<pre className="mt-2 whitespace-pre-wrap">{result.stdout}</pre>}{result.stderr&&<pre className="mt-2 whitespace-pre-wrap text-rose-200">{result.stderr}</pre>}{result.compile_output&&<pre className="mt-2 whitespace-pre-wrap text-amber-200">{result.compile_output}</pre>}</>}</div>}
      </section>
    </div>
    <p className="text-xs text-slate-500">Supported languages depend on Judge0 configuration. This page does not execute submitted code inside the application server. Test-case grading and hidden tests require a configured problem judge.</p>
  </div>;
};
