import React, { useEffect, useState } from 'react';
import {
  CloudUpload,
  Download,
  History,
  Link2,
  Lock,
  Trash2,
} from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function PrivateCloudPage() {
  const { showToast } = useAuth();
  const [files, setFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [folder, setFolder] = useState('My Files');
  const [busy, setBusy] = useState(false);
  const [versions, setVersions] = useState({});

  const loadFiles = async () => {
    try {
      const result = await api.files.list();
      setFiles(Array.isArray(result) ? result : []);
    } catch (error) {
      showToast(error.message || 'Unable to load your files.', 'error');
    }
  };

  useEffect(() => {
    loadFiles();
    // loadFiles is intentionally called once when the page mounts.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleUpload = async (event) => {
    event.preventDefault();
    if (!selectedFile) return;

    setBusy(true);
    try {
      await api.files.upload(selectedFile, folder.trim() || 'My Files');
      setSelectedFile(null);
      event.currentTarget.reset();
      await loadFiles();
      showToast('File uploaded to your private cloud.', 'success');
    } catch (error) {
      showToast(error.message || 'File upload failed.', 'error');
    } finally {
      setBusy(false);
    }
  };

  const handleDownload = async (fileId) => {
    try {
      const result = await api.files.download(fileId);
      if (!result?.url) throw new Error('A secure download link was not returned.');
      window.location.assign(result.url);
    } catch (error) {
      showToast(error.message || 'Unable to download this file.', 'error');
    }
  };

  const handleShare = async (fileId) => {
    const permission = window.prompt('Sharing permission: view or download', 'view');
    if (!permission) return;

    const normalizedPermission = permission.trim().toLowerCase();
    if (!['view', 'download'].includes(normalizedPermission)) {
      showToast('Choose view or download.', 'error');
      return;
    }

    try {
      const result = await api.files.share(fileId, normalizedPermission);
      if (!result?.shareUrl) throw new Error('A share link was not returned.');

      try {
        await navigator.clipboard.writeText(result.shareUrl);
        showToast('Secure share link copied.', 'success');
      } catch {
        window.prompt('Copy your secure share link:', result.shareUrl);
      }
    } catch (error) {
      showToast(error.message || 'Unable to create a share link.', 'error');
    }
  };

  const handleRevoke = async (fileId) => {
    try {
      await api.files.revoke(fileId);
      showToast('File share link revoked.', 'success');
    } catch (error) {
      showToast(error.message || 'Unable to revoke the share link.', 'error');
    }
  };

  const handleToggleVersions = async (fileId) => {
    if (versions[fileId]) {
      setVersions((current) => ({ ...current, [fileId]: null }));
      return;
    }

    try {
      // Fetch first; do not put await inside the React state updater.
      const versionList = await api.files.versions(fileId);
      setVersions((current) => ({ ...current, [fileId]: versionList }));
    } catch (error) {
      showToast(error.message || 'Unable to load file versions.', 'error');
    }
  };

  const handleRestoreVersion = async (fileId, versionNumber) => {
    try {
      await api.files.restoreVersion(fileId, versionNumber);
      setVersions((current) => ({ ...current, [fileId]: null }));
      await loadFiles();
      showToast('Selected version restored as a new version.', 'success');
    } catch (error) {
      showToast(error.message || 'Unable to restore this version.', 'error');
    }
  };

  const handleAddVersion = async (fileId, event) => {
    const nextFile = event.target.files?.[0];
    if (!nextFile) return;

    try {
      await api.files.addVersion(fileId, nextFile);
      setVersions((current) => ({ ...current, [fileId]: null }));
      await loadFiles();
      showToast('New file version saved.', 'success');
    } catch (error) {
      showToast(error.message || 'Unable to save a new version.', 'error');
    } finally {
      event.target.value = '';
    }
  };

  const handleDelete = async (fileId) => {
    if (!window.confirm('Delete this file and its stored versions?')) return;

    try {
      await api.files.remove(fileId);
      await loadFiles();
      showToast('File deleted.', 'success');
    } catch (error) {
      showToast(error.message || 'Unable to delete this file.', 'error');
    }
  };

  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-[#DCE8F7] bg-white p-5">
        <h3 className="font-bold text-[#16345C]">Personal Private Cloud</h3>
        <p className="mt-1 text-sm text-slate-500">
          Store personal documents privately. Files are scoped to your account and delivered through short-lived signed links.
        </p>

        <form
          onSubmit={handleUpload}
          className="mt-4 grid gap-3 sm:grid-cols-[1fr_180px_auto]"
        >
          <input
            required
            type="file"
            onChange={(event) => setSelectedFile(event.target.files?.[0] || null)}
            className="rounded-xl border p-3 text-sm"
          />
          <input
            value={folder}
            onChange={(event) => setFolder(event.target.value)}
            placeholder="Folder name"
            className="rounded-xl border p-3 text-sm"
          />
          <button
            type="submit"
            disabled={!selectedFile || busy}
            className="flex items-center justify-center gap-2 rounded-xl bg-[#102B50] px-4 py-3 text-sm font-semibold text-white disabled:opacity-50"
          >
            <CloudUpload size={16} />
            {busy ? 'Uploading…' : 'Upload file'}
          </button>
        </form>
        <p className="mt-2 text-xs text-slate-400">
          Maximum file size: 25 MB. Cloudinary credentials are required. Each new version is saved separately.
        </p>
      </section>

      <section className="space-y-3">
        {files.length > 0 ? (
          files.map((fileItem) => (
            <article
              key={fileItem._id}
              className="rounded-2xl border border-[#DCE8F7] bg-white p-4"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="break-all font-semibold text-[#16345C]">{fileItem.name}</p>
                  <p className="mt-1 text-xs text-slate-500">
                    {fileItem.folder} · {(Number(fileItem.bytes || 0) / 1024 / 1024).toFixed(2)} MB · {fileItem.versions?.length || 1} version(s)
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button type="button" onClick={() => handleDownload(fileItem._id)} className="rounded-lg border px-3 py-2 text-xs" title="Download">
                    <Download size={14} />
                  </button>
                  <button type="button" onClick={() => handleShare(fileItem._id)} className="rounded-lg border px-3 py-2 text-xs" title="Share">
                    <Link2 size={14} />
                  </button>
                  <button type="button" onClick={() => handleRevoke(fileItem._id)} className="rounded-lg border px-3 py-2 text-xs">
                    Revoke
                  </button>
                  <label className="cursor-pointer rounded-lg border px-3 py-2 text-xs">
                    New version
                    <input type="file" className="hidden" onChange={(event) => handleAddVersion(fileItem._id, event)} />
                  </label>
                  <button type="button" onClick={() => handleToggleVersions(fileItem._id)} className="rounded-lg border px-3 py-2 text-xs" title="Version history">
                    <History size={14} />
                  </button>
                  <button type="button" onClick={() => handleDelete(fileItem._id)} className="rounded-lg border px-3 py-2 text-xs text-rose-600" title="Delete">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              {Array.isArray(versions[fileItem._id]) && (
                <div className="mt-3 space-y-2 border-t pt-3">
                  {versions[fileItem._id].length ? versions[fileItem._id].map((versionItem) => (
                    <div key={versionItem._id || versionItem.version} className="flex items-center justify-between gap-3">
                      <p className="text-xs text-slate-500">
                        Version {versionItem.version} · {new Date(versionItem.createdAt).toLocaleString()} · {(Number(versionItem.bytes || 0) / 1024).toFixed(0)} KB
                      </p>
                      <button type="button" onClick={() => handleRestoreVersion(fileItem._id, versionItem.version)} className="text-xs text-blue-600">
                        Restore
                      </button>
                    </div>
                  )) : (
                    <p className="text-xs text-slate-500">No version history is available.</p>
                  )}
                </div>
              )}
            </article>
          ))
        ) : (
          <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-slate-500">
            <Lock className="mx-auto mb-2" />
            No files uploaded yet.
          </div>
        )}
      </section>
    </div>
  );
}
