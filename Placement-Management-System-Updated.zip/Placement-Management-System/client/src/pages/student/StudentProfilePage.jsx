import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { User, GraduationCap, Code, Award, FolderGit2, FileText, Lock, Plus, Trash2, Save, } from 'lucide-react';
export const StudentProfilePage = () => {
    const { user, showToast, refreshUser } = useAuth();
    const [activeTab, setActiveTab] = useState('personal');
    // Form State
    const [name, setName] = useState(user?.name || '');
    const [phone, setPhone] = useState(user?.phone || '');
    const [course, setCourse] = useState('BCA');
    const [courseOther, setCourseOther] = useState('');
    const [semester, setSemester] = useState('Semester 6');
    const [semesterOther, setSemesterOther] = useState('');
    const [cgpa, setCgpa] = useState('');
    const [tenthPercentage, setTenthPercentage] = useState(undefined);
    const [twelfthPercentage, setTwelfthPercentage] = useState(undefined);
    const [backlogs, setBacklogs] = useState(0);
    const [skills, setSkills] = useState([]);
    const [programmingLanguages, setProgrammingLanguages] = useState([]);
    const [softSkills, setSoftSkills] = useState([]);
    const [skillInputs, setSkillInputs] = useState({technical:'', programming:'', soft:''});
    const [newSkill, setNewSkill] = useState('');
    const [bio, setBio] = useState('');
    const [linkedin, setLinkedin] = useState('');
    const [github, setGithub] = useState('');
    const [portfolioUrl, setPortfolioUrl] = useState('');
    const [resumeUrl, setResumeUrl] = useState('');
    // Projects State
    const [projects, setProjects] = useState([]);
    const [newProject, setNewProject] = useState({
        title: '',
        description: '',
        techStack: '',
        githubUrl: '',
        liveUrl: '',
    });
    // Certifications State
    const [certifications, setCertifications] = useState([]);
    const [newCert, setNewCert] = useState({
        title: '',
        issuer: '',
        issueDate: '',
        credentialUrl: '',
    });
    // Password State
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmNewPassword, setConfirmNewPassword] = useState('');
    const [saving, setSaving] = useState(false);
    // Load profile data on mount
    useEffect(() => {
        if (!user)
            return;
        api.student.getProfile(user.id).then((prof) => {
            if (prof) {
                const knownCourses = ['BCA', 'MCA', 'B.Tech CSE', 'B.Sc IT', 'M.Sc IT', 'B.Com', 'BBA', 'B.Voc', 'B.Sc', 'M.Sc', 'BA', 'M.Com'];
                const knownSemesters = Array.from({ length: 8 }, (_, i) => `Semester ${i + 1}`);
                if (knownCourses.includes(prof.course)) setCourse(prof.course);
                else { setCourse('Other'); setCourseOther(prof.course || ''); }
                if (knownSemesters.includes(prof.semester)) setSemester(prof.semester);
                else { setSemester(prof.semester ? 'Other' : 'Semester 6'); setSemesterOther(prof.semester || ''); }
                setCgpa(prof.currentCGPA ?? prof.cgpa ?? '');
                setTenthPercentage(prof.tenthPercentage);
                setTwelfthPercentage(prof.twelfthPercentage);
                setBacklogs(prof.backlogs || 0);
                setSkills(prof.technicalSkills || prof.skills || []);
                setProgrammingLanguages(prof.programmingLanguages || []);
                setSoftSkills(prof.softSkills || []);
                setBio(prof.bio || '');
                setLinkedin(prof.linkedin || '');
                setGithub(prof.github || '');
                setPortfolioUrl(prof.portfolioUrl || '');
                setResumeUrl(prof.resumeUrl || '');
                setProjects(prof.projects || []);
                setCertifications(prof.certifications || []);
            }
        });
    }, [user]);
    const handleSaveProfile = async () => {
        if (!user)
            return;
        if (course === 'Other' && !courseOther.trim()) { showToast('Please enter your course / degree.', 'error'); return; }
        if (semester === 'Other' && !semesterOther.trim()) { showToast('Please enter your current semester.', 'error'); return; }
        if (cgpa !== '' && (!Number.isFinite(Number(cgpa)) || Number(cgpa) < 1 || Number(cgpa) > 10)) { showToast('CGPA must be between 1 and 10, or left blank.', 'error'); return; }
        setSaving(true);
        try {
            await api.student.updateProfile(user.id, {
                name,
                phone,
                course: course === 'Other' ? courseOther.trim() : course,
                semester: semester === 'Other' ? semesterOther.trim() : semester,
                cgpa: cgpa === '' ? '' : Number(cgpa),
                tenthPercentage,
                twelfthPercentage,
                backlogs,
                skills,
                technicalSkills: skills,
                programmingLanguages,
                softSkills,
                bio,
                linkedin,
                github,
                portfolioUrl,
                resumeUrl,
                projects,
                certifications,
            });
            await refreshUser();
            showToast('Profile information saved and synchronized!', 'success');
        }
        catch (err) {
            showToast(err.message || 'Error updating profile', 'error');
        }
        finally {
            setSaving(false);
        }
    };
    const handleAddSkill = (e) => {
        e.preventDefault();
        if (!newSkill.trim())
            return;
        if (skills.includes(newSkill.trim()))
            return;
        setSkills([...skills, newSkill.trim()]);
        setNewSkill('');
    };
    const handleRemoveSkill = (skillToRemove) => {
        setSkills(skills.filter((s) => s !== skillToRemove));
    };
    const handleAddProject = () => {
        if (!newProject.title.trim() || !newProject.description.trim()) {
            showToast('Please provide project title and description', 'error');
            return;
        }
        const stack = newProject.techStack
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean);
        setProjects([
            ...projects,
            {
                title: newProject.title,
                description: newProject.description,
                techStack: stack,
                githubUrl: newProject.githubUrl,
                liveUrl: newProject.liveUrl,
            },
        ]);
        setNewProject({ title: '', description: '', techStack: '', githubUrl: '', liveUrl: '' });
    };
    const handleRemoveProject = (index) => {
        setProjects(projects.filter((_, i) => i !== index));
    };
    const handleAddCert = () => {
        if (!newCert.title.trim() || !newCert.issuer.trim()) {
            showToast('Please provide certification title and issuer', 'error');
            return;
        }
        setCertifications([...certifications, { ...newCert }]);
        setNewCert({ title: '', issuer: '', issueDate: '', credentialUrl: '' });
    };
    const handleRemoveCert = (index) => {
        setCertifications(certifications.filter((_, i) => i !== index));
    };
    const handleChangePassword = async (e) => {
        e.preventDefault();
        if (newPassword !== confirmNewPassword) {
            showToast('New passwords do not match.', 'error');
            return;
        }
        if (newPassword.length < 6) {
            showToast('New password must be at least 6 characters.', 'error');
            return;
        }
        try {
            await api.auth.changePassword(user?.email || '', currentPassword, newPassword);
            showToast('Password changed successfully!', 'success');
            setCurrentPassword('');
            setNewPassword('');
            setConfirmNewPassword('');
        }
        catch (err) {
            showToast(err.message || 'Failed to change password', 'error');
        }
    };
    const tabs = [
        { id: 'personal', label: 'Personal Details', icon: User },
        { id: 'academic', label: 'Academic & CGPA', icon: GraduationCap },
        { id: 'skills', label: 'Skills & Tools', icon: Code },
        { id: 'projects', label: 'Projects', icon: FolderGit2 },
        { id: 'certifications', label: 'Certifications', icon: Award },
        { id: 'resume', label: 'Resume & Links', icon: FileText },
        { id: 'security', label: 'Security', icon: Lock },
    ];
    return (_jsxs("div", { className: "space-y-6", children: [_jsx("div", { className: "flex items-center gap-1 overflow-x-auto pb-2 border-b border-[#DCE3F5]", children: tabs.map((t) => {
                    const Icon = t.icon;
                    const isActive = activeTab === t.id;
                    return (_jsxs("button", { onClick: () => setActiveTab(t.id), className: `px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer ${isActive
                            ? 'bg-[#3154B8] text-white shadow-xs'
                            : 'bg-white text-[#252B63] border border-[#DCE3F5] hover:border-[#3154B8]'}`, children: [_jsx(Icon, { className: "w-4 h-4" }), _jsx("span", { children: t.label })] }, t.id));
                }) }), activeTab === 'personal' && (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-bold text-base text-[#252B63]", children: "Personal Information" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Your identity details as registered with the institution" })] }), _jsxs("button", { onClick: handleSaveProfile, disabled: saving, className: "px-4 py-2 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50", children: [_jsx(Save, { className: "w-4 h-4" }), _jsx("span", { children: saving ? 'Saving...' : 'Save Changes' })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Full Name" }), _jsx("input", { type: "text", value: name, onChange: (e) => setName(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:outline-hidden focus:border-[#3154B8]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Email Address" }), _jsx("input", { type: "email", value: user?.email, disabled: true, className: "w-full px-3.5 py-2.5 bg-slate-100 border border-[#DCE3F5] rounded-xl text-xs text-[#66739A] cursor-not-allowed" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Mobile Number" }), _jsx("input", { type: "tel", value: phone, onChange: (e) => setPhone(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:outline-hidden focus:border-[#3154B8]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "College Name" }), _jsx("input", { type: "text", value: "Kanya Maha Vidyalaya (Autonomous)", disabled: true, className: "w-full px-3.5 py-2.5 bg-slate-100 border border-[#DCE3F5] rounded-xl text-xs text-[#66739A] cursor-not-allowed" })] })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Professional Bio & Career Objective" }), _jsx("textarea", { rows: 4, value: bio, onChange: (e) => setBio(e.target.value), placeholder: "Brief professional introduction, core interests, and placement objectives...", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:outline-hidden focus:border-[#3154B8]" })] })] })), activeTab === 'academic' && (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-bold text-base text-[#252B63]", children: "Academic Records & CGPA" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Used by placement algorithms to verify drive prerequisites" })] }), _jsxs("button", { onClick: handleSaveProfile, disabled: saving, className: "px-4 py-2 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50", children: [_jsx(Save, { className: "w-4 h-4" }), _jsx("span", { children: saving ? 'Saving...' : 'Save Academic Details' })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Course / Degree" }), _jsxs("select", { value: course, onChange: (e) => setCourse(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:border-[#3154B8]", children: [_jsx("option", { value: "BCA", children: "Bachelor of Computer Applications (BCA)" }), _jsx("option", { value: "MCA", children: "Master of Computer Applications (MCA)" }), _jsx("option", { value: "B.Tech CSE", children: "B.Tech Computer Science" }), _jsx("option", { value: "B.Sc IT", children: "B.Sc Information Technology" }), _jsx("option", { value: "M.Sc IT", children: "M.Sc Information Technology" }), _jsx("option", { value: "B.Com", children: "B.Com Professional" }), _jsx("option", { value: "BBA", children: "BBA" }), _jsx("option", { value: "B.Voc", children: "B.Voc" }), _jsx("option", { value: "B.Sc", children: "B.Sc" }), _jsx("option", { value: "M.Sc", children: "M.Sc" }), _jsx("option", { value: "BA", children: "BA" }), _jsx("option", { value: "M.Com", children: "M.Com" }), _jsx("option", { value: "Other", children: "Other — Write your own" })] }), course === 'Other' && _jsx("input", { value: courseOther, onChange: (e) => setCourseOther(e.target.value), placeholder: "Enter your course / degree", className: "mt-2 w-full px-3.5 py-2.5 bg-white border border-[#DCE3F5] rounded-xl text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Current Semester" }), _jsxs("select", { value: semester, onChange: (e) => setSemester(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:border-[#3154B8]", children: [...Array.from({ length: 8 }, (_, i) => _jsx("option", { value: `Semester ${i + 1}`, children: `Semester ${i + 1}` }, `sem-${i + 1}`)), _jsx("option", { value: "Other", children: "Other — Write your own" })] }), semester === 'Other' && _jsx("input", { value: semesterOther, onChange: (e) => setSemesterOther(e.target.value), placeholder: "Enter semester / year / term", className: "mt-2 w-full px-3.5 py-2.5 bg-white border border-[#DCE3F5] rounded-xl text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Current Cumulative CGPA (1 - 10)" }), _jsx("input", { type: "number", step: "0.01", min: "1", max: "10", value: cgpa, onChange: (e) => setCgpa(e.target.value), placeholder: "e.g. 8.4", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs font-bold text-[#3154B8] focus:border-[#3154B8]" })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Class 10th Percentage (%)" }), _jsx("input", { type: "number", step: "0.1", min: "0", max: "100", value: tenthPercentage || '', onChange: (e) => setTenthPercentage(parseFloat(e.target.value) || undefined), placeholder: "e.g. 92.4", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:border-[#3154B8]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Class 12th Percentage (%)" }), _jsx("input", { type: "number", step: "0.1", min: "0", max: "100", value: twelfthPercentage || '', onChange: (e) => setTwelfthPercentage(parseFloat(e.target.value) || undefined), placeholder: "e.g. 89.6", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:border-[#3154B8]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Active Backlogs (Arrears)" }), _jsx("input", { type: "number", min: "0", max: "10", value: backlogs, onChange: (e) => setBacklogs(parseInt(e.target.value, 10) || 0), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:border-[#3154B8]" })] })] })] })), activeTab === 'skills' && (_jsxs('div', { className: 'bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs space-y-6', children: [_jsxs('div', { className: 'flex items-center justify-between pb-4 border-b border-[#DCE3F5]', children: [_jsxs('div', { children: [_jsx('h3', { className: 'font-bold text-base text-[#252B63]', children: 'Skills & Technical Expertise' }), _jsx('p', { className: 'text-xs text-[#66739A]', children: 'Maintain three separate skill lists. Press Enter or Add to save each skill.' })] }), _jsx('button', { onClick: handleSaveProfile, disabled: saving, className: 'px-4 py-2 rounded-xl bg-[#3154B8] text-white text-xs font-semibold', children: saving ? 'Saving...' : 'Save All Skills' })] }), ...[['technical','Technical Skills',skills,setSkills,'React, SQL, Excel, Cloud Computing'],['programming','Programming Languages',programmingLanguages,setProgrammingLanguages,'JavaScript, Python, Java, C++'],['soft','Professional / Soft Skills',softSkills,setSoftSkills,'Communication, Teamwork, Problem Solving']].map(([key,label,values,setValues,placeholder]) => _jsxs('section', { className: 'space-y-3 rounded-xl border border-[#DCE3F5] p-4', children: [_jsx('h4', { className: 'font-semibold text-sm text-[#16345C]', children: label }), _jsxs('form', { className: 'flex gap-2', onSubmit: e => { e.preventDefault(); const value=skillInputs[key].trim(); if(value && !values.some(v=>v.toLowerCase()===value.toLowerCase())) setValues([...values,value]); setSkillInputs({...skillInputs,[key]:''}); }, children: [_jsx('input', { value:skillInputs[key], onChange:e=>setSkillInputs({...skillInputs,[key]:e.target.value}), placeholder, className:'flex-1 min-w-0 px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs' }), _jsx('button', { type:'submit', className:'px-4 py-2 rounded-xl bg-[#20245B] text-white text-xs font-semibold', children:'Add' })] }), _jsx('div', { className:'flex flex-wrap gap-2', children: values.length ? values.map((value,i)=>_jsxs('span',{className:'px-3 py-1.5 rounded-lg bg-[#3154B8]/10 border border-[#3154B8]/20 text-xs font-semibold text-[#3154B8] flex items-center gap-2',children:[value,_jsx('button',{type:'button',onClick:()=>setValues(values.filter((_,index)=>index!==i)),className:'text-slate-500 hover:text-rose-600',children:'×','aria-label':`Remove ${value}`})]},`${key}-${i}`)) : _jsx('p',{className:'text-xs text-slate-400',children:'No skills added yet.'}) })] },key))] })) , activeTab === 'projects' && (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-bold text-base text-[#252B63]", children: "Academic & Capstone Projects" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Highlighted on your placement resume" })] }), _jsxs("button", { onClick: handleSaveProfile, disabled: saving, className: "px-4 py-2 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer", children: [_jsx(Save, { className: "w-4 h-4" }), _jsx("span", { children: "Save Projects" })] })] }), _jsxs("div", { className: "p-4 rounded-xl bg-[#F5F6FF] border border-[#DCE3F5] space-y-3", children: [_jsx("h4", { className: "font-bold text-xs text-[#20245B] uppercase tracking-wider", children: "Add New Project" }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [_jsx("input", { type: "text", placeholder: "Project Title (e.g. Campus Event Portal)", value: newProject.title, onChange: (e) => setNewProject({ ...newProject, title: e.target.value }), className: "px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" }), _jsx("input", { type: "text", placeholder: "Tech Stack comma-separated (e.g. React, Node.js, MongoDB)", value: newProject.techStack, onChange: (e) => setNewProject({ ...newProject, techStack: e.target.value }), className: "px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsx("textarea", { rows: 2, placeholder: "Project description, architecture and results...", value: newProject.description, onChange: (e) => setNewProject({ ...newProject, description: e.target.value }), className: "w-full px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [_jsx("input", { type: "url", placeholder: "GitHub Repository URL", value: newProject.githubUrl, onChange: (e) => setNewProject({ ...newProject, githubUrl: e.target.value }), className: "px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" }), _jsxs("button", { type: "button", onClick: handleAddProject, className: "py-2 px-4 rounded-lg bg-[#20245B] text-white text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-[#252B63]", children: [_jsx(Plus, { className: "w-4 h-4" }), _jsx("span", { children: "Append to Projects List" })] })] })] }), _jsx("div", { className: "space-y-3", children: projects.map((proj, idx) => (_jsxs("div", { className: "p-4 rounded-xl border border-[#DCE3F5] bg-white space-y-2 relative", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("h4", { className: "font-bold text-sm text-[#252B63]", children: proj.title }), _jsx("button", { onClick: () => handleRemoveProject(idx), className: "p-1 text-slate-400 hover:text-rose-600 rounded-md", children: _jsx(Trash2, { className: "w-4 h-4" }) })] }), _jsx("p", { className: "text-xs text-[#66739A] leading-relaxed", children: proj.description }), _jsx("div", { className: "flex flex-wrap gap-1.5 pt-1", children: proj.techStack.map((tech, i) => (_jsx("span", { className: "px-2 py-0.5 rounded-md bg-[#F5F6FF] text-[#252B63] text-[10px] font-semibold border border-[#DCE3F5]", children: tech }, i))) })] }, idx))) })] })), activeTab === 'certifications' && (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-bold text-base text-[#252B63]", children: "Professional Certifications" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Coursera, HackerRank, Oracle, AWS, etc." })] }), _jsxs("button", { onClick: handleSaveProfile, disabled: saving, className: "px-4 py-2 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer", children: [_jsx(Save, { className: "w-4 h-4" }), _jsx("span", { children: "Save Certifications" })] })] }), _jsxs("div", { className: "p-4 rounded-xl bg-[#F5F6FF] border border-[#DCE3F5] space-y-3", children: [_jsx("h4", { className: "font-bold text-xs text-[#20245B] uppercase tracking-wider", children: "Add Verified Certification" }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [_jsx("input", { type: "text", placeholder: "Certification Name", value: newCert.title, onChange: (e) => setNewCert({ ...newCert, title: e.target.value }), className: "px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" }), _jsx("input", { type: "text", placeholder: "Issuing Organization (e.g. Coursera / Meta)", value: newCert.issuer, onChange: (e) => setNewCert({ ...newCert, issuer: e.target.value }), className: "px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [_jsx("input", { type: "date", value: newCert.issueDate, onChange: (e) => setNewCert({ ...newCert, issueDate: e.target.value }), className: "px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" }), _jsxs("button", { type: "button", onClick: handleAddCert, className: "py-2 px-4 rounded-lg bg-[#20245B] text-white text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-[#252B63]", children: [_jsx(Plus, { className: "w-4 h-4" }), _jsx("span", { children: "Add Certification" })] })] })] }), _jsx("div", { className: "space-y-3", children: certifications.map((cert, idx) => (_jsxs("div", { className: "p-3.5 rounded-xl border border-[#DCE3F5] bg-white flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("h4", { className: "font-bold text-xs text-[#252B63]", children: cert.title }), _jsxs("p", { className: "text-[11px] text-[#66739A]", children: ["Issued by ", cert.issuer, " \u2022 ", cert.issueDate] })] }), _jsx("button", { onClick: () => handleRemoveCert(idx), className: "p-1 text-slate-400 hover:text-rose-600 rounded-md", children: _jsx(Trash2, { className: "w-4 h-4" }) })] }, idx))) })] })), activeTab === 'resume' && (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-bold text-base text-[#252B63]", children: "Resume & Professional Profiles" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Share links with campus recruitment panels" })] }), _jsxs("button", { onClick: handleSaveProfile, disabled: saving, className: "px-4 py-2 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer", children: [_jsx(Save, { className: "w-4 h-4" }), _jsx("span", { children: "Save Links" })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "LinkedIn Profile URL" }), _jsx("input", { type: "url", value: linkedin, onChange: (e) => setLinkedin(e.target.value), placeholder: "https://linkedin.com/in/username", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "GitHub Profile URL" }), _jsx("input", { type: "url", value: github, onChange: (e) => setGithub(e.target.value), placeholder: "https://github.com/username", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Portfolio / Personal Website" }), _jsx("input", { type: "url", value: portfolioUrl, onChange: (e) => setPortfolioUrl(e.target.value), placeholder: "https://yourname.dev", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Hosted Resume Document Link (Google Drive / Cloud)" }), _jsx("input", { type: "url", value: resumeUrl, onChange: (e) => setResumeUrl(e.target.value), placeholder: "https://drive.google.com/your-resume-pdf", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] })] })] })), activeTab === 'security' && (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs max-w-xl space-y-6", children: [_jsxs("div", { className: "pb-4 border-b border-[#DCE3F5]", children: [_jsx("h3", { className: "font-bold text-base text-[#252B63]", children: "Change Account Password" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Update your account password" })] }), _jsxs("form", { onSubmit: handleChangePassword, className: "space-y-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Current Password *" }), _jsx("input", { type: "password", required: true, value: currentPassword, onChange: (e) => setCurrentPassword(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "New Password (min 6 characters) *" }), _jsx("input", { type: "password", required: true, value: newPassword, onChange: (e) => setNewPassword(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Confirm New Password *" }), _jsx("input", { type: "password", required: true, value: confirmNewPassword, onChange: (e) => setConfirmNewPassword(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsx("button", { type: "submit", className: "py-2.5 px-5 rounded-xl bg-[#3154B8] text-white text-xs font-semibold hover:bg-[#4268D5] cursor-pointer", children: "Update Password" })] })] }))] }));
};
