
import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { StatCard } from '../../components/common/StatCard';
import { StatusBadge } from '../../components/common/Badge';
import {
  FileSpreadsheet,
  CheckCircle,
  Video,
  FileText,
  Code2,
  Calendar,
  Award,
  ExternalLink,
} from 'lucide-react';


const getItems = (result) => {
  if (Array.isArray(result)) return result;
  if (Array.isArray(result?.applications)) return result.applications;
  if (Array.isArray(result?.drives)) return result.drives;
  if (Array.isArray(result?.announcements)) return result.announcements;
  if (Array.isArray(result?.data)) return result.data;
  return [];
};

export const StudentDashboard = ({ onSelectTab = () => {} }) => {
  const { user } = useAuth();

  const [stats, setStats] = useState(null);
  const [applications, setApplications] = useState(null);
  const [drives, setDrives] = useState(null);
  const [announcements, setAnnouncements] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [retryKey, setRetryKey] = useState(0);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    let isMounted = true;

    async function loadDashboardData() {
      setLoading(true);
      setError('');

      const results = await Promise.allSettled([
        api.student.getStats(user.id || user._id),
        api.student.getApplications(user.id || user._id),
        api.drives.getAllDrives(),
        api.announcements.getAnnouncements(),
      ]);

      if (!isMounted) return;

      const [statsResult, applicationsResult, drivesResult, announcementsResult] =
        results;

      if (statsResult.status === 'fulfilled') {
        const value = statsResult.value;
        const actualStats = value?.stats || value?.data?.stats || value;

        setStats(actualStats || null);
      } else {
        console.error('Could not load student statistics:', statsResult.reason);
        setStats(null);
      }

      if (applicationsResult.status === 'fulfilled') {
        setApplications(getItems(applicationsResult.value));
      } else {
        console.error('Could not load applications:', applicationsResult.reason);
        setApplications(null);
      }

      if (drivesResult.status === 'fulfilled') {
        setDrives(getItems(drivesResult.value).slice(0, 3));
      } else {
        console.error('Could not load placement drives:', drivesResult.reason);
        setDrives(null);
      }

      if (announcementsResult.status === 'fulfilled') {
        setAnnouncements(getItems(announcementsResult.value).slice(0, 2));
      } else {
        console.error('Could not load announcements:', announcementsResult.reason);
        setAnnouncements(null);
      }

      if (results.some((result) => result.status === 'rejected')) {
        setError('Some dashboard information could not be loaded. Please retry.');
      }

      setLoading(false);
    }

    loadDashboardData().catch((err) => {
      console.error('Error loading dashboard:', err);
      if (isMounted) {
        setError('Unable to load dashboard data. Please try again.');
        setLoading(false);
      }
    });

    return () => {
      isMounted = false;
    };
  }, [user, retryKey]);

  const upcomingInterview = (applications || []).find(
    (application) =>
      application.status === 'interview_scheduled' &&
      application.interviewDetails
  );

  return (
    <div className="space-y-8">
      <section className="bg-[#20245B] rounded-2xl p-6 sm:p-8 text-white flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md">
        <div className="space-y-2">
          <span className="inline-flex px-2.5 py-1 rounded-full bg-white/10 text-xs font-semibold text-blue-200">
            Placement Management System
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome back, {user?.name || 'Student'}!
          </h2>
          <p className="text-sm text-slate-200 max-w-xl">
            Track your applications, prepare for interviews and stay updated
            with placement opportunities.
          </p>
        </div>

        <div className="bg-white/10 rounded-xl p-4 border border-white/15 flex items-center gap-4">
          <div className="relative w-16 h-16 flex items-center justify-center">
            <svg viewBox="0 0 64 64" className="w-full h-full -rotate-90">
              <circle cx="32" cy="32" r="26" stroke="currentColor"
                strokeWidth="6" className="text-white/20" fill="none" />
              <circle cx="32" cy="32" r="26" stroke="currentColor"
                strokeWidth="6" strokeLinecap="round"
                strokeDasharray={163.3}
                strokeDashoffset={163.3 - 163.3 * Math.min(100, Math.max(0, Number(stats?.profileCompletion) || 0)) / 100}
                className="text-white" fill="none" />
            </svg>
            <span className="absolute text-sm font-bold">
              {stats?.profileCompletion ?? '—'}%
            </span>
          </div>
          <div>
            <p className="text-xs font-bold uppercase text-blue-200">
              Profile Status
            </p>
            <p className="text-sm font-semibold mt-1">
              {stats?.profileCompletion == null ? 'Status unavailable' : stats.profileCompletion >= 80 ? 'Almost Complete' : 'Needs Completion'}
            </p>
            <button onClick={() => onSelectTab('profile')}
              className="text-xs text-blue-200 underline mt-1">
              Update Profile Details →
            </button>
          </div>
        </div>
      </section>

      {loading && (
        <p className="rounded-xl border border-[#DCE3F5] bg-white p-4 text-sm text-[#66739A]" role="status">
          Loading your dashboard...
        </p>
      )}

      {!loading && error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700" role="alert">
          {error} <button onClick={() => setRetryKey(value => value + 1)} className="ml-2 font-bold underline">Retry</button>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <StatCard title="Applications Sent" value={stats?.totalApplied ?? '—'} subtitle="Drives applied to date" icon={FileSpreadsheet} variant="blue" />
        <StatCard title="Shortlisted" value={stats?.shortlistedCount ?? '—'} subtitle="Cleared screening tests" icon={CheckCircle} variant="emerald" />
        <StatCard title="Interviews Scheduled" value={stats?.interviewsScheduled ?? '—'} subtitle="Technical & HR rounds" icon={Video} variant="amber" />
        <StatCard title="Offers Received" value={stats?.offersReceived ?? '—'} subtitle="Placement offers" icon={Award} variant="navy" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { id: 'aptitude', title: 'Aptitude Practice', subtitle: 'Timed Questions', icon: CheckCircle },
          { id: 'coding-arena', title: 'Coding Arena', subtitle: 'Coding Challenges', icon: Code2 },
          { id: 'resume-builder', title: 'Resume Builder', subtitle: 'Build Your Resume', icon: FileText },
          { id: 'mock-interview', title: 'Mock Interview', subtitle: 'Interview Practice', icon: Video },
        ].map(({ id, title, subtitle, icon: Icon }) => (
          <button key={id} onClick={() => onSelectTab(id)}
            className="p-4 rounded-xl bg-white border border-[#DCE3F5] hover:border-[#3154B8] text-left group">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Icon className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-xs text-[#252B63] mt-3">{title}</h4>
            <p className="text-[11px] text-[#66739A] mt-1">{subtitle}</p>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <section className="lg:col-span-8 bg-white rounded-2xl border border-[#DCE3F5] p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#DCE3F5]">
            <div>
              <h3 className="font-bold text-base text-[#252B63]">Recent Applications</h3>
              <p className="text-xs text-[#66739A]">Track your submitted applications</p>
            </div>
            <button onClick={() => onSelectTab('applications')}
              className="text-xs font-semibold text-blue-600">
              View All ({applications?.length ?? '—'})
            </button>
          </div>

          {applications === null ? (
            <p className="py-8 text-center text-xs text-rose-700">Applications could not be loaded. Please retry the dashboard.</p>
          ) : applications.length === 0 ? (
            <div className="py-10 text-center space-y-2">
              <FileSpreadsheet className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="text-sm font-semibold text-[#252B63]">No applications submitted yet.</p>
              <p className="text-xs text-[#66739A]">Explore available placement drives to get started.</p>
              <button onClick={() => onSelectTab('drives')}
                className="mt-3 px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold">
                Explore Open Drives
              </button>
            </div>
          ) : (
            <div className="divide-y divide-[#DCE3F5]">
              {applications.slice(0, 4).map((app, index) => (
                <div key={app.id || app._id || index}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-[#252B63]">
                        {app.drive?.companyName || app.companyName || 'Company'}
                      </span>
                      <StatusBadge status={app.status || 'pending'} />
                    </div>
                    <p className="text-xs text-[#66739A]">
                      Role: {app.drive?.jobTitle || app.jobTitle || 'Graduate Trainee'}
                      {' • '}Applied: {app.appliedAt ? new Date(app.appliedAt).toLocaleDateString() : 'Date unavailable'}
                    </p>
                    {app.recruiterFeedback && (
                      <p className="text-xs text-slate-700 bg-slate-50 p-2 rounded-lg">
                        Feedback: {app.recruiterFeedback}
                      </p>
                    )}
                  </div>
                  {app.status === 'interview_scheduled' && app.interviewDetails?.meetingLink && (
                    <a href={app.interviewDetails.meetingLink} target="_blank" rel="noopener noreferrer"
                      className="px-3 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold flex items-center gap-2">
                      Join Interview <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>

        <aside className="lg:col-span-4 space-y-6">
          {upcomingInterview ? (
            <section className="bg-[#20245B] rounded-2xl p-6 text-white space-y-4">
              <span className="text-xs font-bold uppercase text-amber-300">Upcoming Interview</span>
              <h4 className="font-bold">{upcomingInterview.drive?.companyName || 'Company Interview'}</h4>
              <p className="text-xs text-blue-200">
                {upcomingInterview.interviewDetails.roundName || 'Interview Round'}
              </p>
              <div className="p-3 bg-white/10 rounded-xl space-y-2 text-xs">
                <p className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {upcomingInterview.interviewDetails.scheduledDate || 'Date to be confirmed'}
                </p>
                <p>Time: {upcomingInterview.interviewDetails.timeString || 'To be confirmed'}</p>
              </div>
              {upcomingInterview.interviewDetails.meetingLink && (
                <a href={upcomingInterview.interviewDetails.meetingLink}
                  target="_blank" rel="noopener noreferrer"
                  className="block text-center py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold">
                  Launch Virtual Meeting
                </a>
              )}
            </section>
          ) : (
            <section className="bg-white rounded-2xl border border-[#DCE3F5] p-6 text-center space-y-2">
              <Calendar className="w-8 h-8 text-slate-300 mx-auto" />
              <h4 className="font-bold text-sm text-[#252B63]">No Interviews Scheduled</h4>
              <p className="text-xs text-[#66739A]">Scheduled interviews will appear here.</p>
            </section>
          )}

          <section className="bg-white rounded-2xl border border-[#DCE3F5] p-6 space-y-4">
            <h4 className="font-bold text-sm text-[#252B63] pb-2 border-b border-[#DCE3F5]">
              Campus Notices
            </h4>
            {announcements === null ? (
              <p className="text-xs text-rose-700">Campus notices could not be loaded.</p>
            ) : announcements.length === 0 ? (
              <p className="text-xs text-[#66739A]">No campus notices available right now.</p>
            ) : (
              <div className="space-y-4">
                {announcements.map((ann, index) => (
                  <div key={ann.id || ann._id || index} className="space-y-1">
                    <p className="text-xs font-bold text-[#252B63]">{ann.title || 'Campus Notice'}</p>
                    <p className="text-[11px] text-[#66739A] line-clamp-2">{ann.content || ann.message || ''}</p>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="bg-white rounded-2xl border border-[#DCE3F5] p-5">
            <h4 className="font-bold text-sm text-[#252B63]">Placement Drives</h4>
            {drives === null ? (
              <p className="text-xs text-rose-700 mt-2">Placement drives could not be loaded.</p>
            ) : drives.length === 0 ? (
              <p className="text-xs text-[#66739A] mt-2">No placement drives available right now.</p>
            ) : (
              <div className="space-y-3 mt-3">
                {drives.map((drive, index) => (
                  <div key={drive.id || drive._id || index} className="border-t border-slate-100 pt-3">
                    <p className="text-xs font-bold text-[#252B63]">{drive.companyName || drive.company?.name || 'Company'}</p>
                    <p className="text-xs text-[#66739A]">{drive.jobTitle || drive.position || 'Placement Opportunity'}</p>
                  </div>
                ))}
              </div>
            )}
            <button onClick={() => onSelectTab('drives')}
              className="mt-4 text-xs font-semibold text-blue-600">
              View Placement Drives →
            </button>
          </section>
        </aside>
      </div>
    </div>
  );
};
