import React, { useEffect, useState } from 'react';
import { Plus, RefreshCw, Power } from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

const empty = {
  companyName: '', jobRole: '', description: '', location: 'Jalandhar',
  jobType: 'Full-time', package: '', eligibleCourses: '', minCGPA: '0',
  maxBacklogs: '0', skills: '', applicationDeadline: '', driveDate: '',
};

export const ManagePlacementDrivesPage = () => {
  const { showToast } = useAuth();
  const [drives, setDrives] = useState([]);
  const [form, setForm] = useState(empty);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    setError('');
    try { setDrives(await api.admin.getDrives()); }
    catch (e) { setError(e.message || 'Unable to load placement drives.'); }
  };
  useEffect(() => { load(); }, []);
  const change = (e) => setForm((previous) => ({ ...previous, [e.target.name]: e.target.value }));

  const create = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.admin.createDrive({
        ...form,
        opportunityType: form.jobType,
        eligibleCourses: form.eligibleCourses.split(',').map((x) => x.trim()).filter(Boolean),
        skills: form.skills.split(',').map((x) => x.trim()).filter(Boolean),
        minCGPA: Number(form.minCGPA),
        maxBacklogs: Number(form.maxBacklogs),
        applicationDeadline: form.applicationDeadline || null,
        driveDate: form.driveDate || null,
      });
      setForm(empty);
      await load();
      showToast('Placement drive created.', 'success');
    } catch (e) { showToast(e.message || 'Unable to create drive.', 'error'); }
    finally { setBusy(false); }
  };

  const toggle = async (drive) => {
    try {
      await api.admin.updateDrive(drive._id, { status: drive.status === 'Open' ? 'Closed' : 'Open', isActive: drive.status !== 'Open' });
      await load();
      showToast('Drive status updated.', 'success');
    } catch (e) { showToast(e.message, 'error'); }
  };

  return <div className="space-y-5">
    <header className="flex flex-wrap items-center justify-between gap-2">
      <div><h2 className="text-xl font-bold text-[#20245B]">Institutional Placement Drives</h2><p className="text-sm text-slate-500">Create, review and close campus opportunities stored in MongoDB.</p></div>
      <button onClick={load} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold"><RefreshCw size={14}/> Refresh</button>
    </header>
    <form onSubmit={create} className="grid gap-3 rounded-2xl border border-[#DCE3F5] bg-white p-5 md:grid-cols-2">
      <h3 className="font-bold text-[#20245B] md:col-span-2">Create a new placement drive</h3>
      <label className="text-xs font-semibold text-slate-600">Company name<input required name="companyName" value={form.companyName} onChange={change} className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600">Job role<input required name="jobRole" value={form.jobRole} onChange={change} className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600">Opportunity Type
        <select name="jobType" value={form.jobType} onChange={change} className="mt-1 w-full rounded-lg border bg-white p-2.5 text-sm font-normal">
          <option value="All">All</option>
          <option value="Internship">Internship</option>
          <option value="Full-time">Full-time Job</option>
          <option value="Part-time">Part-time Job</option>
        </select>
      </label>
      <label className="text-xs font-semibold text-slate-600">Location<input name="location" value={form.location} onChange={change} className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600">Package / CTC<input name="package" value={form.package} onChange={change} placeholder="e.g. ₹18,000/month or 3.5 LPA" className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600">Eligible courses (comma separated)<input name="eligibleCourses" value={form.eligibleCourses} onChange={change} placeholder="BCA, MCA, B.Sc IT" className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600">Minimum CGPA<input type="number" min="0" max="10" step="0.01" name="minCGPA" value={form.minCGPA} onChange={change} className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600">Maximum backlogs<input type="number" min="0" name="maxBacklogs" value={form.maxBacklogs} onChange={change} className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600 md:col-span-2">Required skills (comma separated)<input name="skills" value={form.skills} onChange={change} placeholder="Python, SQL, Communication" className="mt-1 w-full rounded-lg border p-2.5 text-sm font-normal"/></label>
      <label className="text-xs font-semibold text-slate-600">Application deadline<input type="date" name="applicationDeadline" value={form.applicationDeadline} onChange={change} className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label>
      <label className="text-xs font-semibold text-slate-600">Drive date<input type="date" name="driveDate" value={form.driveDate} onChange={change} className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label>
      <textarea name="description" value={form.description} onChange={change} placeholder="Job description and selection process" rows={3} className="rounded-lg border p-3 text-sm md:col-span-2"/>
      <button disabled={busy} className="flex items-center justify-center gap-2 rounded-lg bg-[#20245B] p-3 text-sm font-semibold text-white disabled:opacity-50 md:col-span-2"><Plus size={16}/>{busy ? 'Creating…' : 'Create Drive'}</button>
    </form>
    {error && <p className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}<button onClick={load} className="ml-2 underline">Retry</button></p>}
    <div className="space-y-3">{drives.map((d) => <article key={d._id || d.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#DCE3F5] bg-white p-4"><div><h3 className="font-semibold text-[#20245B]">{d.companyName} — {d.jobRole || d.jobTitle}</h3><p className="text-xs text-slate-500">{d.opportunityType || d.jobType || 'Not specified'} · {d.package || 'Package not specified'} · {d.location || 'Location not specified'} · {d.eligibleCourses?.join(', ') || 'No course filter'}</p><p className="mt-1 text-xs text-slate-500">Status: {d.status} · Deadline: {d.applicationDeadline ? new Date(d.applicationDeadline).toLocaleDateString() : 'Not specified'}</p></div><button onClick={() => toggle(d)} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold"><Power size={14}/>{d.status === 'Open' ? 'Close drive' : 'Reopen drive'}</button></article>)}{!error && !drives.length && <p className="rounded-xl border border-dashed p-8 text-center text-sm text-slate-500">No placement drives have been created yet.</p>}</div>
  </div>;
};
