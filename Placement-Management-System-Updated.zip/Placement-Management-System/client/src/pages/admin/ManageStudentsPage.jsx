import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { Search, Plus } from 'lucide-react';
export const ManageStudentsPage = () => {
    const { showToast } = useAuth();
    const [students, setStudents] = useState([]);
    const [search, setSearch] = useState('');
    const [courseFilter, setCourseFilter] = useState('All');
    const [selectedStudent, setSelectedStudent] = useState(null);
    // Add student modal
    const [showAddModal, setShowAddModal] = useState(false);
    const [addName, setAddName] = useState('');
    const [addEmail, setAddEmail] = useState('');
    const [addPhone, setAddPhone] = useState('');
    const [addEnrollment, setAddEnrollment] = useState('');
    const [addCourse, setAddCourse] = useState('BCA');
    const [addCourseOther, setAddCourseOther] = useState('');
    const [addSemester, setAddSemester] = useState('Semester 1');
    const [addSemesterOther, setAddSemesterOther] = useState('');
    useEffect(() => {
        api.admin.getAllStudents().then((res) => setStudents(res));
    }, []);
    const handleToggleStatus = async (userId) => {
        try {
            const updated = await api.admin.toggleUserStatus(userId);
            setStudents((prev) => prev.map((s) => (s.user.id === userId ? { ...s, user: { ...s.user, isActive: updated.isActive } } : s)));
            showToast(`Student account status is now ${updated.isActive ? 'Active' : 'Deactivated'}.`, 'success');
        }
        catch (err) {
            showToast(err.message || 'Status toggle failed', 'error');
        }
    };
    const handleCreateStudent = async (e) => {
        e.preventDefault();
        try {
            if (addCourse === 'Other' && !addCourseOther.trim()) { showToast('Write the course / program name.', 'error'); return; }
            if (addSemester === 'Other' && !addSemesterOther.trim()) { showToast('Write the class / semester.', 'error'); return; }
            const temporaryPassword = window.prompt('Set a temporary password for this student (minimum 8 characters):');
            if (!temporaryPassword || temporaryPassword.length < 8) {
                showToast('A temporary password of at least 8 characters is required.', 'error');
                return;
            }
            await api.auth.registerStudent({
                name: addName,
                email: addEmail,
                phone: addPhone,
                password: temporaryPassword,
                confirmPassword: temporaryPassword,
                enrollmentNumber: addEnrollment,
                course: addCourse === 'Other' ? addCourseOther.trim() : addCourse,
                semester: addSemester === 'Other' ? addSemesterOther.trim() : addSemester,
                collegeName: 'Kanya Maha Vidyalaya',
            });
            showToast('Student account created. Share the temporary password securely with the student.', 'success');
            setShowAddModal(false);
            const res = await api.admin.getAllStudents();
            setStudents(res);
            setAddName('');
            setAddEmail('');
            setAddPhone('');
            setAddEnrollment('');
            setAddCourse('BCA');
            setAddCourseOther('');
            setAddSemester('Semester 1');
            setAddSemesterOther('');
        }
        catch (err) {
            showToast(err.message || 'Failed to register student', 'error');
        }
    };
    const filtered = students.filter((s) => {
        const matchCourse = courseFilter === 'All' || s.profile?.course === courseFilter;
        const matchSearch = s.user.name.toLowerCase().includes(search.toLowerCase()) ||
            s.user.email.toLowerCase().includes(search.toLowerCase()) ||
            s.profile?.enrollmentNumber?.toLowerCase().includes(search.toLowerCase());
        return matchCourse && matchSearch;
    });
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-xl font-bold text-[#20245B]", children: "Student Management & Eligibility" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Verify academic transcripts, review CGPA compliance, and activate or deactivate accounts." })] }), _jsxs("button", { onClick: () => setShowAddModal(true), className: "px-4 py-2 rounded-xl bg-[#3154B8] text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer", children: [_jsx(Plus, { className: "w-4 h-4" }), _jsx("span", { children: "Provision Student Account" })] })] }), _jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-4 shadow-xs flex flex-col sm:flex-row gap-3", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "w-4 h-4 text-[#66739A] absolute left-3 top-3" }), _jsx("input", { type: "text", value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search by student name, roll number, or email...", className: "w-full pl-9 pr-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsx("div", { className: "sm:w-56", children: _jsxs("select", { value: courseFilter, onChange: (e) => setCourseFilter(e.target.value), className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]", children: [_jsx("option", { value: "All", children: "All Academic Programs" }), _jsx("option", { value: "BCA", children: "BCA" }), _jsx("option", { value: "MCA", children: "MCA" }), _jsx("option", { value: "B.Tech CSE", children: "B.Tech CSE" }), _jsx("option", { value: "B.Sc IT", children: "B.Sc IT" })] }) })] }), _jsx("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] shadow-xs overflow-hidden", children: _jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full text-left text-xs", children: [_jsx("thead", { className: "bg-[#F5F6FF] border-b border-[#DCE3F5] text-[#66739A] uppercase font-bold text-[10px] tracking-wider", children: _jsxs("tr", { children: [_jsx("th", { className: "px-6 py-3.5", children: "Student" }), _jsx("th", { className: "px-6 py-3.5", children: "Enrollment No." }), _jsx("th", { className: "px-6 py-3.5", children: "Program & CGPA" }), _jsx("th", { className: "px-6 py-3.5", children: "Placement Status" }), _jsx("th", { className: "px-6 py-3.5", children: "Account State" }), _jsx("th", { className: "px-6 py-3.5 text-right", children: "Actions" })] }) }), _jsx("tbody", { className: "divide-y divide-[#DCE3F5]", children: filtered.map((item) => (_jsxs("tr", { className: "hover:bg-slate-50/70", children: [_jsxs("td", { className: "px-6 py-4", children: [_jsx("p", { className: "font-bold text-[#252B63]", children: item.user.name }), _jsx("p", { className: "text-[11px] text-[#66739A]", children: item.user.email })] }), _jsx("td", { className: "px-6 py-4 font-mono font-semibold text-[#20245B]", children: item.profile?.enrollmentNumber || 'N/A' }), _jsxs("td", { className: "px-6 py-4", children: [_jsx("p", { className: "font-bold text-[#252B63]", children: item.profile?.course }), _jsxs("p", { className: "text-[11px] text-[#3154B8] font-semibold", children: ["CGPA: ", item.profile?.cgpa || 0] })] }), _jsx("td", { className: "px-6 py-4", children: _jsx(StatusBadge, { status: item.profile?.placementStatus || 'available' }) }), _jsx("td", { className: "px-6 py-4", children: _jsx("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold ${item.user.isActive
                                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                                    : 'bg-rose-50 text-rose-700 border border-rose-200'}`, children: item.user.isActive ? 'Active' : 'Deactivated' }) }), _jsxs("td", { className: "px-6 py-4 text-right space-x-2", children: [_jsx("button", { onClick: () => setSelectedStudent(item), className: "px-3 py-1.5 rounded-lg border border-[#DCE3F5] text-[#252B63] font-semibold hover:border-[#3154B8]", children: "Transcript" }), _jsx("button", { onClick: () => handleToggleStatus(item.user.id), className: `px-3 py-1.5 rounded-lg font-semibold text-xs ${item.user.isActive
                                                        ? 'text-rose-600 bg-rose-50 hover:bg-rose-100'
                                                        : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'}`, children: item.user.isActive ? 'Deactivate' : 'Activate' })] })] }, item.user.id))) })] }) }) }), _jsx(Modal, { isOpen: showAddModal, onClose: () => setShowAddModal(false), title: "Provision Student Record", subtitle: "Secure account creation by Placement Coordinator", maxWidth: "md", children: _jsxs("form", { onSubmit: handleCreateStudent, className: "space-y-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Full Name *" }), _jsx("input", { type: "text", required: true, value: addName, onChange: (e) => setAddName(e.target.value), placeholder: "e.g. Jaspreet Kaur", className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Email *" }), _jsx("input", { type: "email", required: true, value: addEmail, onChange: (e) => setAddEmail(e.target.value), placeholder: "e.g. jaspreet@kmv.ac.in", className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { className: "grid grid-cols-2 gap-3", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Enrollment No. *" }), _jsx("input", { type: "text", required: true, value: addEnrollment, onChange: (e) => setAddEnrollment(e.target.value), placeholder: "KMV/2023/BCA/...", className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Phone *" }), _jsx("input", { type: "tel", required: true, value: addPhone, onChange: (e) => setAddPhone(e.target.value), placeholder: "+91 98140...", className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-lg text-xs" })] })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Course" }), _jsxs("select", { value: addCourse, onChange: (e) => setAddCourse(e.target.value), className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-lg text-xs", children: [_jsx("option", { value: "BCA", children: "BCA" }), _jsx("option", { value: "MCA", children: "MCA" }), _jsx("option", { value: "B.Tech CSE", children: "B.Tech CSE" }), _jsx("option", { value: "B.Sc IT", children: "B.Sc IT" }), _jsx("option", { value: "M.Sc IT", children: "M.Sc IT" }), _jsx("option", { value: "B.Com", children: "B.Com" }), _jsx("option", { value: "BBA", children: "BBA" }), _jsx("option", { value: "B.Voc", children: "B.Voc" }), _jsx("option", { value: "B.Sc", children: "B.Sc" }), _jsx("option", { value: "M.Sc", children: "M.Sc" }), _jsx("option", { value: "BA", children: "BA" }), _jsx("option", { value: "M.Com", children: "M.Com" }), _jsx("option", { value: "Other", children: "Other — Write your own" })] }), addCourse === 'Other' && _jsx("input", { type: "text", required: true, value: addCourseOther, onChange: (e) => setAddCourseOther(e.target.value), placeholder: "Write your course / program", className: "mt-2 w-full px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Current Class / Semester" }), _jsxs("select", { value: addSemester, onChange: (e) => setAddSemester(e.target.value), className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-lg text-xs", children: [...Array.from({ length: 8 }, (_, i) => _jsx("option", { value: `Semester ${i + 1}`, children: `Semester ${i + 1}` }, `admin-sem-${i + 1}`)), _jsx("option", { value: "Other", children: "Other — Write your own" })] }), addSemester === 'Other' && _jsx("input", { type: "text", required: true, value: addSemesterOther, onChange: (e) => setAddSemesterOther(e.target.value), placeholder: "Write your class / semester / year", className: "mt-2 w-full px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { className: "pt-2 flex justify-end gap-2", children: [_jsx("button", { type: "button", onClick: () => setShowAddModal(false), className: "px-4 py-2 rounded-lg border border-[#DCE3F5] text-xs font-semibold", children: "Cancel" }), _jsx("button", { type: "submit", className: "px-5 py-2 rounded-lg bg-[#3154B8] text-white text-xs font-semibold", children: "Create Account" })] })] }) }), _jsx(Modal, { isOpen: !!selectedStudent, onClose: () => setSelectedStudent(null), title: selectedStudent?.user.name || 'Transcript', subtitle: `Roll: ${selectedStudent?.profile?.enrollmentNumber}`, maxWidth: "md", children: selectedStudent && (_jsxs("div", { className: "space-y-4 text-xs", children: [_jsxs("div", { className: "grid grid-cols-2 gap-3 p-4 bg-[#F5F6FF] rounded-xl border border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("span", { className: "text-[#66739A]", children: "Program" }), _jsx("p", { className: "font-bold text-[#20245B]", children: selectedStudent.profile.course })] }), _jsxs("div", { children: [_jsx("span", { className: "text-[#66739A]", children: "Semester" }), _jsx("p", { className: "font-bold text-[#20245B]", children: selectedStudent.profile.semester })] }), _jsxs("div", { children: [_jsx("span", { className: "text-[#66739A]", children: "CGPA" }), _jsx("p", { className: "font-bold text-[#3154B8]", children: selectedStudent.profile.cgpa })] }), _jsxs("div", { children: [_jsx("span", { className: "text-[#66739A]", children: "Backlogs" }), _jsx("p", { className: "font-bold text-emerald-600", children: selectedStudent.profile.backlogs })] })] }), _jsxs("div", { children: [_jsx("span", { className: "font-bold text-[#20245B] block mb-1", children: "Skills" }), _jsx("div", { className: "flex flex-wrap gap-1", children: selectedStudent.profile.skills?.map((sk, i) => (_jsx("span", { className: "px-2 py-0.5 rounded bg-blue-50 text-[#3154B8] text-[11px] font-semibold", children: sk }, i))) })] })] })) })] }));
};
