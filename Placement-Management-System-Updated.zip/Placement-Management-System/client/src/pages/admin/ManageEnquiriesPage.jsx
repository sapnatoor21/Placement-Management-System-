import React, { useEffect, useMemo, useState } from 'react';
import { Mail, Phone, Trash2, RefreshCw, MessageSquare, Search } from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

const statuses = ['New', 'In Progress', 'Replied', 'Resolved'];
const statusStyle = {
  New: 'bg-blue-50 text-blue-700',
  'In Progress': 'bg-amber-50 text-amber-700',
  Replied: 'bg-violet-50 text-violet-700',
  Resolved: 'bg-emerald-50 text-emerald-700',
};

export const ManageEnquiriesPage = () => {
  const { showToast } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState('');
  const [replyDrafts, setReplyDrafts] = useState({});

  const load = async () => {
    setLoading(true);
    try { setItems(await api.admin.getEnquiries()); }
    catch (error) { showToast(error.message || 'Unable to load enquiries.', 'error'); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const visible = useMemo(() => items.filter((item) => {
    const matchesStatus = filter === 'All' || item.status === filter;
    const term = search.trim().toLowerCase();
    const matchesSearch = !term || [item.name, item.email, item.phone, item.subject, item.message].some((value) => String(value || '').toLowerCase().includes(term));
    return matchesStatus && matchesSearch;
  }), [items, filter, search]);

  const update = async (item, patch) => {
    setBusyId(item._id);
    try {
      const result = await api.admin.updateEnquiry(item._id, patch);
      setItems((current) => current.map((entry) => entry._id === item._id ? result.enquiry : entry));
      showToast('Enquiry updated.', 'success');
    } catch (error) { showToast(error.message || 'Unable to update enquiry.', 'error'); }
    finally { setBusyId(''); }
  };


  const sendReply = async (item) => {
    const draft = replyDrafts[item._id] || {};
    const replySubject = draft.subject ?? `Re: ${item.subject}`;
    if (!String(replySubject).trim() || !String(draft.body || '').trim()) return showToast('Enter reply subject and message.', 'error');
    setBusyId(item._id);
    try {
      const result = await api.admin.replyToEnquiry(item._id, { subject: replySubject, body: draft.body });
      setItems((current) => current.map((entry) => entry._id === item._id ? result.enquiry : entry));
      setReplyDrafts((current) => ({ ...current, [item._id]: { subject: '', body: '' } }));
      showToast('Reply sent and enquiry marked as Replied.', 'success');
    } catch (error) { showToast(error.message || 'Reply could not be sent. Check email configuration.', 'error'); }
    finally { setBusyId(''); }
  };

  const remove = async (item) => {
    if (!window.confirm(`Delete the enquiry from ${item.name}? This cannot be undone.`)) return;
    setBusyId(item._id);
    try { await api.admin.deleteEnquiry(item._id); setItems((current) => current.filter((entry) => entry._id !== item._id)); showToast('Enquiry deleted.', 'success'); }
    catch (error) { showToast(error.message || 'Unable to delete enquiry.', 'error'); }
    finally { setBusyId(''); }
  };

  return <div className="space-y-5">
    <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div><h2 className="text-xl font-bold text-[#20245B]">Official Enquiries</h2><p className="mt-1 text-sm text-slate-500">Messages submitted through the public Contact page.</p></div>
      <button onClick={load} className="inline-flex items-center justify-center gap-2 rounded-lg border border-[#DCE3F5] bg-white px-3 py-2 text-sm font-semibold text-[#3154B8]"><RefreshCw size={15}/> Refresh</button>
    </header>
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{statuses.map((status) => <button key={status} onClick={() => setFilter(filter === status ? 'All' : status)} className={`rounded-xl border p-3 text-left ${filter === status ? 'border-[#3154B8] bg-blue-50' : 'border-[#DCE3F5] bg-white'}`}><p className="text-xs text-slate-500">{status}</p><p className="mt-1 text-xl font-bold text-[#20245B]">{items.filter((item) => item.status === status).length}</p></button>)}</div>
    <div className="flex flex-col gap-3 sm:flex-row"><label className="relative flex-1"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"/><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search name, email, subject or message" className="w-full rounded-xl border border-[#DCE3F5] bg-white py-3 pl-9 pr-3 text-sm outline-none focus:border-[#3154B8]"/></label><select value={filter} onChange={(event) => setFilter(event.target.value)} className="rounded-xl border border-[#DCE3F5] bg-white px-3 py-3 text-sm"><option>All</option>{statuses.map((status) => <option key={status}>{status}</option>)}</select></div>
    {loading ? <div className="rounded-xl border border-[#DCE3F5] bg-white p-10 text-center text-sm text-slate-500">Loading enquiries…</div> : visible.length === 0 ? <div className="rounded-xl border border-dashed border-[#C9D5EC] bg-white p-10 text-center"><MessageSquare className="mx-auto h-8 w-8 text-slate-300"/><p className="mt-3 font-semibold text-[#20245B]">No enquiries found</p><p className="mt-1 text-sm text-slate-500">New messages submitted from the public website will appear here.</p></div> : <div className="space-y-4">{visible.map((item) => <article key={item._id} className="rounded-2xl border border-[#DCE3F5] bg-white p-4 shadow-sm sm:p-5"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusStyle[item.status] || 'bg-slate-100 text-slate-600'}`}>{item.status}</span><span className="text-xs text-slate-400">{new Date(item.createdAt).toLocaleString()}</span></div><h3 className="mt-2 break-words font-bold text-[#20245B]">{item.subject}</h3><p className="mt-1 text-sm font-semibold text-slate-700">{item.name}</p><div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500"><a className="inline-flex items-center gap-1 hover:text-[#3154B8]" href={`mailto:${item.email}`}><Mail size={13}/>{item.email}</a>{item.phone && <a className="inline-flex items-center gap-1 hover:text-[#3154B8]" href={`tel:${item.phone}`}><Phone size={13}/>{item.phone}</a>}</div></div><button disabled={busyId === item._id} onClick={() => remove(item)} title="Delete enquiry" className="self-end rounded-lg border border-rose-100 p-2 text-rose-600 hover:bg-rose-50 disabled:opacity-50 sm:self-start"><Trash2 size={16}/></button></div><p className="mt-4 whitespace-pre-wrap break-words rounded-xl bg-[#F8FAFF] p-4 text-sm leading-6 text-slate-700">{item.message}</p><div className="mt-4 grid gap-3 sm:grid-cols-[1fr_190px]"><textarea aria-label="Internal admin notes" defaultValue={item.adminNotes || ''} onBlur={(event) => { if (event.target.value !== (item.adminNotes || '')) update(item, { adminNotes: event.target.value }); }} rows={2} placeholder="Internal notes (not visible to sender)" className="w-full rounded-lg border border-[#DCE3F5] p-3 text-xs outline-none focus:border-[#3154B8]"/><select disabled={busyId === item._id} value={item.status} onChange={(event) => update(item, { status: event.target.value })} className="rounded-lg border border-[#DCE3F5] bg-white px-3 py-2 text-sm"><option value="New">New</option><option value="In Progress">In Progress</option><option value="Replied">Replied</option><option value="Resolved">Resolved</option></select></div>
      <div className="mt-4 rounded-xl border border-[#DCE3F5] bg-[#FBFCFF] p-4"><h4 className="text-sm font-bold text-[#20245B]">Reply by email</h4><input value={replyDrafts[item._id]?.subject ?? `Re: ${item.subject}`} onChange={(e) => setReplyDrafts((current) => ({ ...current, [item._id]: { ...(current[item._id] || {}), subject: e.target.value } }))} maxLength={180} placeholder="Reply subject" className="mt-3 w-full rounded-lg border border-[#DCE3F5] bg-white px-3 py-2 text-sm"/><textarea value={replyDrafts[item._id]?.body || ''} onChange={(e) => setReplyDrafts((current) => ({ ...current, [item._id]: { ...(current[item._id] || {}), body: e.target.value } }))} rows={3} maxLength={8000} placeholder="Write your reply to the sender…" className="mt-2 w-full rounded-lg border border-[#DCE3F5] bg-white p-3 text-sm"/><button disabled={busyId === item._id} onClick={() => sendReply(item)} className="mt-2 inline-flex items-center gap-2 rounded-lg bg-[#102B50] px-4 py-2 text-xs font-semibold text-white disabled:opacity-50"><Mail size={14}/> Send Reply</button>
      {item.emailHistory?.length > 0 && <div className="mt-4 border-t border-[#DCE3F5] pt-3"><p className="text-xs font-bold text-[#20245B]">Email History</p><div className="mt-2 space-y-2">{item.emailHistory.map((entry, index) => <div key={`${entry._id || entry.messageId || index}`} className="rounded-lg bg-white p-3 text-xs"><div className="flex flex-wrap justify-between gap-2"><strong>{entry.subject}</strong><span className={entry.status === 'sent' ? 'text-emerald-700' : 'text-rose-700'}>{entry.status}</span></div><p className="mt-1 whitespace-pre-wrap text-slate-600">{entry.body}</p><p className="mt-1 text-slate-400">{entry.sentAt ? new Date(entry.sentAt).toLocaleString() : ''}</p>{entry.errorMessage && <p className="mt-1 text-rose-600">{entry.errorMessage}</p>}</div>)}</div></div>}</div></article>)}</div>}
  </div>;
};
