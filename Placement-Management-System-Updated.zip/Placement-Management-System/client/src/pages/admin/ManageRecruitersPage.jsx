import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Search } from 'lucide-react';
export const ManageRecruitersPage = () => {
    const { showToast } = useAuth();
    const [recruiters, setRecruiters] = useState([]);
    const [search, setSearch] = useState('');
    useEffect(() => {
        api.admin.getAllRecruiters().then((res) => setRecruiters(res));
    }, []);
    const handleToggleStatus = async (userId) => {
        try {
            const updated = await api.admin.toggleUserStatus(userId);
            setRecruiters((prev) => prev.map((r) => (r.user.id === userId ? { ...r, user: { ...r.user, isActive: updated.isActive } } : r)));
            showToast(`Recruiter account is now ${updated.isActive ? 'Active' : 'Deactivated'}`, 'success');
        }
        catch (err) {
            showToast(err.message || 'Status toggle failed', 'error');
        }
    };
    const filtered = recruiters.filter((r) => {
        const compName = r.profile?.companyName || '';
        const contact = r.user.name || '';
        return (compName.toLowerCase().includes(search.toLowerCase()) ||
            contact.toLowerCase().includes(search.toLowerCase()) ||
            r.user.email.toLowerCase().includes(search.toLowerCase()));
    });
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "border-b border-[#DCE3F5] pb-4", children: [_jsx("h2", { className: "text-xl font-bold text-[#20245B]", children: "Recruiter Partner Directory" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Review verified corporate employer accounts, point-of-contact details, and drive authorizations." })] }), _jsx("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-4 shadow-xs", children: _jsxs("div", { className: "relative", children: [_jsx(Search, { className: "w-4 h-4 text-[#66739A] absolute left-3 top-3" }), _jsx("input", { type: "text", value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search by corporate partner name, lead HR, or email...", className: "w-full pl-9 pr-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }) }), _jsx("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] shadow-xs overflow-hidden", children: _jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full text-left text-xs", children: [_jsx("thead", { className: "bg-[#F5F6FF] border-b border-[#DCE3F5] text-[#66739A] uppercase font-bold text-[10px] tracking-wider", children: _jsxs("tr", { children: [_jsx("th", { className: "px-6 py-3.5", children: "Company Partner" }), _jsx("th", { className: "px-6 py-3.5", children: "HR Contact Lead" }), _jsx("th", { className: "px-6 py-3.5", children: "Industry" }), _jsx("th", { className: "px-6 py-3.5", children: "Verification" }), _jsx("th", { className: "px-6 py-3.5", children: "Status" }), _jsx("th", { className: "px-6 py-3.5 text-right", children: "Actions" })] }) }), _jsx("tbody", { className: "divide-y divide-[#DCE3F5]", children: filtered.map((item) => (_jsxs("tr", { className: "hover:bg-slate-50/70", children: [_jsxs("td", { className: "px-6 py-4", children: [_jsx("p", { className: "font-bold text-[#252B63]", children: item.profile?.companyName || 'Corporate Recruiter' }), _jsx("p", { className: "text-[11px] text-[#66739A]", children: item.profile?.location || 'Pan India' })] }), _jsxs("td", { className: "px-6 py-4", children: [_jsx("p", { className: "font-semibold text-[#252B63]", children: item.user.name }), _jsx("p", { className: "text-[11px] text-[#66739A]", children: item.user.email })] }), _jsx("td", { className: "px-6 py-4 text-[#252B63]", children: item.profile?.industry || 'Technology' }), _jsx("td", { className: "px-6 py-4", children: _jsx("span", { className: "px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200", children: "Recruiter Account" }) }), _jsx("td", { className: "px-6 py-4", children: _jsx("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold ${item.user.isActive
                                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                                    : 'bg-rose-50 text-rose-700 border border-rose-200'}`, children: item.user.isActive ? 'Active' : 'Deactivated' }) }), _jsx("td", { className: "px-6 py-4 text-right", children: _jsx("button", { onClick: () => handleToggleStatus(item.user.id), className: `px-3 py-1.5 rounded-lg font-semibold text-xs ${item.user.isActive
                                                    ? 'text-rose-600 bg-rose-50 hover:bg-rose-100'
                                                    : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'}`, children: item.user.isActive ? 'Deactivate' : 'Activate' }) })] }, item.user.id))) })] }) }) })] }));
};
