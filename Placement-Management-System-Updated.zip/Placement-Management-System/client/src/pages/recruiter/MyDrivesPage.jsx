import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/Badge';
import { Briefcase, Plus, Users } from 'lucide-react';
export const MyDrivesPage = ({ onSelectTab }) => {
    const { user, showToast } = useAuth();
    const [drives, setDrives] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        if (user) {
            api.recruiter.getMyDrives(user.id).then((res) => {
                setDrives(res);
                setLoading(false);
            });
        }
    }, [user]);
    const handleToggleStatus = async (driveId, currentStatus) => {
        const newStatus = currentStatus === 'open' ? 'closed' : 'open';
        try {
            await api.recruiter.updateDrive(driveId, { status: newStatus });
            setDrives((prev) => prev.map((d) => (d.id === driveId ? { ...d, status: newStatus } : d)));
            showToast(`Drive status toggled to ${newStatus.toUpperCase()}`, 'success');
        }
        catch (err) {
            showToast(err.message || 'Status toggle failed', 'error');
        }
    };
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-xl font-bold text-[#20245B]", children: "My Placement Drives" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Manage, edit, or close corporate recruitment drives posted for students." })] }), _jsxs("button", { onClick: () => onSelectTab('create-drive'), className: "px-4 py-2 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-1.5 shadow-2xs", children: [_jsx(Plus, { className: "w-4 h-4" }), _jsx("span", { children: "Create New Drive" })] })] }), loading ? (_jsx("div", { className: "py-12 text-center text-xs text-[#66739A]", children: "Loading drives..." })) : drives.length === 0 ? (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-12 text-center space-y-3", children: [_jsx(Briefcase, { className: "w-10 h-10 text-slate-300 mx-auto" }), _jsx("h3", { className: "font-bold text-base text-[#20245B]", children: "No Drives Created Yet" }), _jsx("p", { className: "text-xs text-[#66739A] max-w-sm mx-auto", children: "Get started by posting your first placement drive. Specify compensation, eligible branches, and selection tests." }), _jsx("button", { onClick: () => onSelectTab('create-drive'), className: "px-4 py-2 rounded-xl bg-[#3154B8] text-white text-xs font-semibold", children: "Create First Drive" })] })) : (_jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: drives.map((drive) => (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 shadow-xs space-y-4 hover:border-[#3154B8]/40 transition-all flex flex-col justify-between", children: [_jsxs("div", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("h3", { className: "font-bold text-base text-[#20245B] leading-snug", children: drive.jobTitle }), _jsxs("p", { className: "text-xs font-semibold text-[#3154B8] mt-0.5", children: [drive.companyName, " \u2022 ", drive.location] })] }), _jsx(StatusBadge, { status: drive.status })] }), _jsxs("div", { className: "p-3 bg-[#F5F6FF] rounded-xl border border-[#DCE3F5] grid grid-cols-2 gap-2 text-xs", children: [_jsxs("div", { children: [_jsx("span", { className: "text-[#66739A] block text-[10px] uppercase font-bold", children: "CTC" }), _jsx("span", { className: "font-bold text-[#20245B]", children: drive.ctcSalary })] }), _jsxs("div", { children: [_jsx("span", { className: "text-[#66739A] block text-[10px] uppercase font-bold", children: "Applicants" }), _jsxs("span", { className: "font-bold text-[#3154B8]", children: [drive.applicantsCount, " Students"] })] })] }), _jsx("p", { className: "text-xs text-[#66739A] line-clamp-2 leading-relaxed", children: drive.description })] }), _jsxs("div", { className: "pt-4 border-t border-[#DCE3F5] flex items-center justify-between", children: [_jsx("button", { onClick: () => handleToggleStatus(drive.id, drive.status), className: "text-xs font-semibold text-[#66739A] hover:text-[#20245B] flex items-center gap-1 cursor-pointer", children: _jsx("span", { children: drive.status === 'open' ? 'Close Drive' : 'Reopen Drive' }) }), _jsxs("button", { onClick: () => onSelectTab('applicants'), className: "px-3.5 py-1.5 rounded-lg bg-[#20245B] hover:bg-[#252B63] text-white text-xs font-semibold flex items-center gap-1.5", children: [_jsx(Users, { className: "w-3.5 h-3.5" }), _jsxs("span", { children: ["View Applicants (", drive.applicantsCount, ")"] })] })] })] }, drive.id))) }))] }));
};
