import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { StatCard } from '../../components/common/StatCard';
import { StatusBadge } from '../../components/common/Badge';
import { Briefcase, Users, CheckSquare, PlusCircle, ArrowRight, Video, Building } from 'lucide-react';
export const RecruiterDashboard = ({ onSelectTab }) => {
    const { user } = useAuth();
    const [drives, setDrives] = useState([]);
    const [applicants, setApplicants] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        if (!user)
            return;
        const loadRecruiterData = async () => {
            try {
                const myDrives = await api.recruiter.getMyDrives(user.id);
                setDrives(myDrives);
                // Fetch all applicants for all drives owned by this recruiter
                let allApps = [];
                for (const d of myDrives) {
                    const apps = await api.recruiter.getDriveApplicants(d.id);
                    allApps = [...allApps, ...apps];
                }
                setApplicants(allApps);
            }
            catch (err) {
                console.error('Error loading recruiter dashboard', err);
            }
            finally {
                setLoading(false);
            }
        };
        loadRecruiterData();
    }, [user]);
    const shortlistedCount = applicants.filter((a) => ['shortlisted', 'assessment_round', 'interview_scheduled', 'selected'].includes(a.status)).length;
    const interviewsCount = applicants.filter((a) => a.status === 'interview_scheduled').length;
    return (_jsxs("div", { className: "space-y-8", children: [_jsxs("div", { className: "bg-[#20245B] rounded-2xl p-6 sm:p-8 text-white flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md border border-slate-700", children: [_jsxs("div", { className: "space-y-2", children: [_jsxs("div", { className: "inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-white/10 text-xs font-semibold text-blue-200", children: [_jsx(Building, { className: "w-3.5 h-3.5" }), _jsx("span", { children: "Corporate Recruitment Console" })] }), _jsxs("h2", { className: "text-2xl sm:text-3xl font-extrabold tracking-tight", children: ["Welcome, ", user?.name, "!"] }), _jsx("p", { className: "text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed", children: "Manage your on-campus placement drives, screen eligible student transcripts, shortlist applicants, and schedule virtual interviews." })] }), _jsxs("button", { onClick: () => onSelectTab('create-drive'), className: "px-5 py-3 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white font-semibold text-xs transition-colors flex items-center gap-2 shadow-sm flex-shrink-0 cursor-pointer", children: [_jsx(PlusCircle, { className: "w-4 h-4" }), _jsx("span", { children: "Post New Placement Drive" })] })] }), _jsxs("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6", children: [_jsx(StatCard, { title: "Active Drives", value: drives.filter((d) => d.status === 'open').length, subtitle: `Total ${drives.length} drives created`, icon: Briefcase, variant: "blue" }), _jsx(StatCard, { title: "Total Applicants", value: applicants.length, subtitle: "Student submissions", icon: Users, variant: "navy" }), _jsx(StatCard, { title: "Shortlisted", value: shortlistedCount, subtitle: "Advancing to test / interview", icon: CheckSquare, variant: "emerald" }), _jsx(StatCard, { title: "Interviews Set", value: interviewsCount, subtitle: "Live interview links issued", icon: Video, variant: "amber" })] }), _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8", children: [_jsxs("div", { className: "lg:col-span-6 bg-white rounded-2xl border border-[#DCE3F5] p-6 shadow-xs space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-[#DCE3F5]", children: [_jsx("h3", { className: "font-bold text-base text-[#20245B]", children: "My Placement Drives" }), _jsxs("button", { onClick: () => onSelectTab('my-drives'), className: "text-xs font-semibold text-[#3154B8] hover:underline", children: ["View All (", drives.length, ")"] })] }), drives.length === 0 ? (_jsxs("div", { className: "py-12 text-center text-[#66739A] space-y-2", children: [_jsx(Briefcase, { className: "w-8 h-8 text-slate-300 mx-auto" }), _jsx("p", { className: "text-xs", children: "You have not posted any placement drives yet." }), _jsx("button", { onClick: () => onSelectTab('create-drive'), className: "mt-2 px-4 py-2 rounded-lg bg-[#3154B8] text-white text-xs font-semibold", children: "Create First Drive" })] })) : (_jsx("div", { className: "space-y-3", children: drives.map((d) => (_jsxs("div", { className: "p-4 rounded-xl bg-[#F5F6FF] border border-[#DCE3F5] flex items-center justify-between", children: [_jsxs("div", { className: "space-y-0.5", children: [_jsx("p", { className: "font-bold text-xs text-[#252B63]", children: d.jobTitle }), _jsxs("p", { className: "text-[11px] text-[#66739A]", children: ["CTC: ", d.ctcSalary, " \u2022 ", d.applicantsCount, " Applicants"] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(StatusBadge, { status: d.status }), _jsx("button", { onClick: () => onSelectTab('applicants'), className: "p-1.5 rounded-lg text-[#3154B8] hover:bg-white transition-colors", title: "Review Applicants", children: _jsx(ArrowRight, { className: "w-4 h-4" }) })] })] }, d.id))) }))] }), _jsxs("div", { className: "lg:col-span-6 bg-white rounded-2xl border border-[#DCE3F5] p-6 shadow-xs space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-[#DCE3F5]", children: [_jsx("h3", { className: "font-bold text-base text-[#20245B]", children: "Recent Candidates" }), _jsxs("button", { onClick: () => onSelectTab('applicants'), className: "text-xs font-semibold text-[#3154B8] hover:underline", children: ["Review All (", applicants.length, ")"] })] }), applicants.length === 0 ? (_jsx("div", { className: "py-12 text-center text-xs text-[#66739A]", children: "No student applications submitted yet for your active drives." })) : (_jsx("div", { className: "space-y-3", children: applicants.slice(0, 4).map((app) => (_jsxs("div", { className: "p-3.5 rounded-xl border border-[#DCE3F5] bg-white flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "font-bold text-xs text-[#252B63]", children: app.student?.name || 'Student' }), _jsxs("p", { className: "text-[11px] text-[#66739A]", children: [app.studentProfile?.course || 'Course not provided', " \u2022 CGPA ", app.studentProfile?.cgpa ?? '—'] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(StatusBadge, { status: app.status }), _jsx("button", { onClick: () => onSelectTab('applicants'), className: "px-2.5 py-1 rounded-md bg-[#20245B] text-white text-[11px] font-semibold", children: "Review" })] })] }, app.id))) }))] })] })] }));
};
