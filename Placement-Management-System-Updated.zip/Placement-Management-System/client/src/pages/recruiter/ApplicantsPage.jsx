import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { Search } from 'lucide-react';
export const ApplicantsPage = () => {
    const { user, showToast } = useAuth();
    const [drives, setDrives] = useState([]);
    const [selectedDriveId, setSelectedDriveId] = useState('All');
    const [applicants, setApplicants] = useState([]);
    const [search, setSearch] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const [selectedCandidate, setSelectedCandidate] = useState(null);
    // Status updating dialog state
    const [updatingApp, setUpdatingApp] = useState(null);
    const [newStatus, setNewStatus] = useState('shortlisted');
    const [feedbackNote, setFeedbackNote] = useState('');
    const [loading, setLoading] = useState(true);
    const [loadError, setLoadError] = useState('');
    const [reloadKey, setReloadKey] = useState(0);
    const [interviewDate, setInterviewDate] = useState('');
    const [interviewTime, setInterviewTime] = useState('');
    const [interviewLink, setInterviewLink] = useState('');
    useEffect(() => {
        let active = true;
        const loadData = async () => {
            setLoading(true);
            setLoadError('');
            try {
                if (!user) return;
                if (user.role === 'admin') {
                    const [allDrives, allApps] = await Promise.all([api.admin.getDrives(), api.admin.getApplications()]);
                    if (active) { setDrives(allDrives); setApplicants(allApps); }
                } else {
                    const [myDrives, allApps] = await Promise.all([api.recruiter.getMyDrives(user.id), api.recruiter.getApplications()]);
                    if (active) { setDrives(myDrives); setApplicants(allApps); }
                }
            } catch (error) {
                console.error('Unable to load recruiter applications:', error);
                if (active) setLoadError(error.message || 'Applicants could not be loaded.');
            } finally { if (active) setLoading(false); }
        };
        loadData();
        return () => { active = false; };
    }, [user, reloadKey]);
    const filteredApplicants = applicants.filter((app) => {
        const matchesDrive = selectedDriveId === 'All' || app.driveId === selectedDriveId;
        const matchesStatus = statusFilter === 'All' || app.status === statusFilter;
        const studentName = app.student?.name || '';
        const enrollment = app.studentProfile?.enrollmentNumber || '';
        const matchesSearch = studentName.toLowerCase().includes(search.toLowerCase()) ||
            enrollment.toLowerCase().includes(search.toLowerCase()) ||
            (app.drive?.jobTitle || '').toLowerCase().includes(search.toLowerCase());
        return matchesDrive && matchesStatus && matchesSearch;
    });
    const handleOpenStatusModal = (app) => {
        setUpdatingApp(app);
        setNewStatus(app.status);
        setFeedbackNote(app.recruiterFeedback || '');
    };
    const handleSaveStatus = async () => {
        if (!updatingApp)
            return;
        if (newStatus === 'interview_scheduled' && (!interviewDate || !interviewTime.trim())) { showToast('Enter the interview date and time before scheduling.', 'error'); return; }
        try {
            const interviewDetails = newStatus === 'interview_scheduled'
                ? {
                    scheduledDate: interviewDate,
                    timeString: interviewTime,
                    roundName: 'Technical & Coding Round 1',
                    meetingLink: interviewLink,
                }
                : undefined;
            if (user.role === 'admin') await api.admin.updateApplicantStatus(updatingApp.id, newStatus, feedbackNote, interviewDetails);
            else await api.recruiter.updateApplicantStatus(updatingApp.id, newStatus, feedbackNote, interviewDetails);
            // Refresh list
            setApplicants((prev) => prev.map((a) => a.id === updatingApp.id
                ? { ...a, status: newStatus, recruiterFeedback: feedbackNote, interviewDetails }
                : a));
            showToast(`Candidate status updated to '${newStatus.replace('_', ' ').toUpperCase()}'.`, 'success');
            setUpdatingApp(null);
        }
        catch (err) {
            showToast(err.message || 'Failed to update applicant status', 'error');
        }
    };
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "border-b border-[#DCE3F5] pb-4", children: [_jsx("h2", { className: "text-xl font-bold text-[#20245B]", children: "Candidate Screening & Evaluation" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Review verified student profiles, evaluate project portfolios, and update recruitment round outcomes." })] }), _jsx("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-5 shadow-xs space-y-4", children: _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-12 gap-3 items-center", children: [_jsxs("div", { className: "md:col-span-5 relative", children: [_jsx(Search, { className: "w-4 h-4 text-[#66739A] absolute left-3 top-3.5" }), _jsx("input", { type: "text", value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search candidate name, roll number, or role...", className: "w-full pl-9 pr-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsx("div", { className: "md:col-span-4", children: _jsxs("select", { value: selectedDriveId, onChange: (e) => setSelectedDriveId(e.target.value), className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]", children: [_jsxs("option", { value: "All", children: ["All Drives (", drives.length, ")"] }), drives.map((d) => (_jsx("option", { value: d.id, children: d.jobTitle }, d.id)))] }) }), _jsx("div", { className: "md:col-span-3", children: _jsxs("select", { value: statusFilter, onChange: (e) => setStatusFilter(e.target.value), className: "w-full px-3 py-2 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]", children: [_jsx("option", { value: "All", children: "All Statuses" }), _jsx("option", { value: "applied", children: "Applied" }), _jsx("option", { value: "shortlisted", children: "Shortlisted" }), _jsx("option", { value: "interview_scheduled", children: "Interview Scheduled" }), _jsx("option", { value: "selected", children: "Selected" }), _jsx("option", { value: "rejected", children: "Rejected" })] }) })] }) }), _jsx("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] shadow-xs overflow-hidden", children: filteredApplicants.length === 0 ? (_jsx("div", { className: "py-16 text-center text-xs text-[#66739A]", children: "No candidate applications match your current filters." })) : (_jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full text-left text-xs", children: [_jsx("thead", { className: "bg-[#F5F6FF] border-b border-[#DCE3F5] text-[#66739A] uppercase font-bold text-[10px] tracking-wider", children: _jsxs("tr", { children: [_jsx("th", { className: "px-6 py-3.5", children: "Candidate" }), _jsx("th", { className: "px-6 py-3.5", children: "Drive / Role" }), _jsx("th", { className: "px-6 py-3.5", children: "Academic Transcript" }), _jsx("th", { className: "px-6 py-3.5", children: "Status" }), _jsx("th", { className: "px-6 py-3.5 text-right", children: "Actions" })] }) }), _jsx("tbody", { className: "divide-y divide-[#DCE3F5]", children: filteredApplicants.map((app) => (_jsxs("tr", { className: "hover:bg-slate-50/70 transition-colors", children: [_jsx("td", { className: "px-6 py-4", children: _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-8 h-8 rounded-full bg-[#20245B] text-white flex items-center justify-center font-bold text-xs", children: app.student?.name?.charAt(0) || 'S' }), _jsxs("div", { children: [_jsx("p", { className: "font-bold text-[#252B63]", children: app.student?.name }), _jsx("p", { className: "text-[11px] text-[#66739A]", children: app.studentProfile?.enrollmentNumber || 'Student' })] })] }) }), _jsxs("td", { className: "px-6 py-4", children: [_jsx("p", { className: "font-semibold text-[#252B63]", children: app.drive?.jobTitle }), _jsx("p", { className: "text-[11px] text-[#66739A]", children: app.drive?.companyName })] }), _jsxs("td", { className: "px-6 py-4", children: [_jsxs("p", { className: "font-bold text-[#3154B8]", children: ["CGPA: ", app.studentProfile?.cgpa ?? '—'] }), _jsxs("p", { className: "text-[11px] text-[#66739A]", children: [app.studentProfile?.course, " \u2022 Backlogs: ", app.studentProfile?.backlogs ?? '—'] })] }), _jsx("td", { className: "px-6 py-4", children: _jsx(StatusBadge, { status: app.status }) }), _jsxs("td", { className: "px-6 py-4 text-right space-x-2", children: [_jsx("button", { onClick: () => setSelectedCandidate(app), className: "px-3 py-1.5 rounded-lg border border-[#DCE3F5] text-[#252B63] font-semibold hover:border-[#3154B8] hover:text-[#3154B8]", children: "Profile" }), _jsx("button", { onClick: () => handleOpenStatusModal(app), className: "px-3 py-1.5 rounded-lg bg-[#3154B8] text-white font-semibold hover:bg-[#4268D5]", children: "Update" })] })] }, app.id))) })] }) })) }), _jsx(Modal, { isOpen: !!selectedCandidate, onClose: () => setSelectedCandidate(null), title: selectedCandidate?.student?.name || 'Candidate Transcript', subtitle: `KMV Roll: ${selectedCandidate?.studentProfile?.enrollmentNumber || ''}`, maxWidth: "lg", children: selectedCandidate && (_jsxs("div", { className: "space-y-5", children: [_jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-[#F5F6FF] border border-[#DCE3F5] text-xs", children: [_jsxs("div", { children: [_jsx("span", { className: "text-[#66739A] block", children: "Course" }), _jsx("span", { className: "font-bold text-[#20245B]", children: selectedCandidate.studentProfile?.course })] }), _jsxs("div", { children: [_jsx("span", { className: "text-[#66739A] block", children: "CGPA" }), _jsx("span", { className: "font-bold text-[#3154B8]", children: (selectedCandidate.studentProfile?.cgpa ?? '—') })] }), _jsxs("div", { children: [_jsx("span", { className: "text-[#66739A] block", children: "10th / 12th" }), _jsxs("span", { className: "font-bold text-[#20245B]", children: [selectedCandidate.studentProfile?.tenthPercentage, "% / ", selectedCandidate.studentProfile?.twelfthPercentage, "%"] })] }), _jsxs("div", { children: [_jsx("span", { className: "text-[#66739A] block", children: "Backlogs" }), _jsx("span", { className: "font-bold text-emerald-600", children: selectedCandidate.studentProfile?.backlogs ?? '—' })] })] }), _jsxs("div", { children: [_jsx("span", { className: "text-xs font-bold uppercase text-[#20245B] block mb-1.5", children: "Technical Skills" }), _jsx("div", { className: "flex flex-wrap gap-1.5", children: selectedCandidate.studentProfile?.skills?.map((sk, i) => (_jsx("span", { className: "px-2.5 py-0.5 rounded-md bg-blue-50 text-[#3154B8] text-xs font-semibold border border-blue-200", children: sk }, i))) })] }), selectedCandidate.studentProfile?.projects && (_jsxs("div", { children: [_jsx("span", { className: "text-xs font-bold uppercase text-[#20245B] block mb-1.5", children: "Applied Projects" }), _jsx("div", { className: "space-y-2", children: selectedCandidate.studentProfile.projects.map((proj, i) => (_jsxs("div", { className: "p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs", children: [_jsx("p", { className: "font-bold text-[#252B63]", children: proj.title }), _jsx("p", { className: "text-slate-600 mt-0.5", children: proj.description })] }, i))) })] }))] })) }), _jsx(Modal, { isOpen: !!updatingApp, onClose: () => setUpdatingApp(null), title: "Update Candidate Recruitment Status", subtitle: `Candidate: ${updatingApp?.student?.name}`, maxWidth: "md", children: updatingApp && (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Recruitment Stage" }), _jsxs("select", { value: newStatus, onChange: (e) => setNewStatus(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]", children: [_jsx("option", { value: "under_review", children: "Under Review" }), _jsx("option", { value: "shortlisted", children: "Shortlisted for Test" }), _jsx("option", { value: "assessment_round", children: "Assessment Round" }), _jsx("option", { value: "interview_scheduled", children: "Interview Scheduled" }), _jsx("option", { value: "selected", children: "Selected / Offer Extended" }), _jsx("option", { value: "rejected", children: "Not Shortlisted (Reject)" })] })] }), newStatus === 'interview_scheduled' && (_jsxs("div", { className: "p-4 rounded-xl bg-amber-50/80 border border-amber-200 space-y-3", children: [_jsx("span", { className: "text-xs font-bold text-amber-900 block", children: "Interview Scheduling Details" }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-[11px] text-amber-900 mb-0.5", children: "Date" }), _jsx("input", { type: "date", value: interviewDate, onChange: (e) => setInterviewDate(e.target.value), className: "w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-[11px] text-amber-900 mb-0.5", children: "Time" }), _jsx("input", { type: "text", value: interviewTime, onChange: (e) => setInterviewTime(e.target.value), placeholder: "e.g. 11:30 AM IST", className: "w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs" })] })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-[11px] text-amber-900 mb-0.5", children: "Meeting / Video Link" }), _jsx("input", { type: "url", value: interviewLink, onChange: (e) => setInterviewLink(e.target.value), placeholder: "https://meet.google.com/...", className: "w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs" })] })] })), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Recruiter Feedback & Notes (Visible to candidate)" }), _jsx("textarea", { rows: 3, value: feedbackNote, onChange: (e) => setFeedbackNote(e.target.value), placeholder: "e.g. Cleared technical screening. Proceeding to virtual panel...", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { className: "pt-3 border-t border-[#DCE3F5] flex items-center justify-between", children: [_jsx("button", { type: "button", onClick: () => setUpdatingApp(null), className: "px-4 py-2 rounded-lg border border-[#DCE3F5] text-xs font-semibold", children: "Cancel" }), _jsx("button", { type: "button", onClick: handleSaveStatus, className: "px-5 py-2.5 rounded-lg bg-[#3154B8] text-white text-xs font-semibold hover:bg-[#4268D5]", children: "Save Status" })] })] })) })] }));
};
