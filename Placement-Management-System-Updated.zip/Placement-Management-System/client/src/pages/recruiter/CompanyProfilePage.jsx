import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Save } from 'lucide-react';
export const CompanyProfilePage = () => {
    const { user, showToast } = useAuth();
    const [companyName, setCompanyName] = useState('');
    const [industry, setIndustry] = useState('');
    const [website, setWebsite] = useState('');
    const [location, setLocation] = useState('');
    const [contactPerson, setContactPerson] = useState('');
    const [designation, setDesignation] = useState('');
    const [aboutCompany, setAboutCompany] = useState('');
    const [saving, setSaving] = useState(false);
    useEffect(() => {
        if (user) {
            api.recruiter.getProfile(user.id).then((prof) => {
                if (prof) {
                    setCompanyName(prof.companyName || '');
                    setIndustry(prof.industry || '');
                    setWebsite(prof.website || '');
                    setLocation(prof.location || '');
                    setContactPerson(prof.contactPerson || '');
                    setDesignation(prof.designation || '');
                    setAboutCompany(prof.aboutCompany || '');
                }
            });
        }
    }, [user]);
    const handleSave = async (e) => {
        e.preventDefault();
        if (!user)
            return;
        setSaving(true);
        try {
            await api.recruiter.updateProfile(user.id, {
                companyName,
                industry,
                website,
                location,
                contactPerson,
                designation,
                aboutCompany,
            });
            showToast('Corporate partner profile updated successfully!', 'success');
        }
        catch (err) {
            showToast(err.message || 'Failed to update company profile', 'error');
        }
        finally {
            setSaving(false);
        }
    };
    return (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs max-w-3xl space-y-6", children: [_jsx("div", { className: "flex items-center justify-between pb-4 border-b border-[#DCE3F5]", children: _jsxs("div", { children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("h2", { className: "text-xl font-bold text-[#20245B]", children: "Company & Recruiter Profile" }), _jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200", children: "Company Profile" })] }), _jsx("p", { className: "text-xs text-[#66739A] mt-0.5", children: "Details visible to placement coordinators and registered students." })] }) }), _jsxs("form", { onSubmit: handleSave, className: "space-y-4", children: [_jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Company Name *" }), _jsx("input", { type: "text", required: true, value: companyName, onChange: (e) => setCompanyName(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Industry Sector *" }), _jsx("input", { type: "text", required: true, value: industry, onChange: (e) => setIndustry(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Corporate Website URL" }), _jsx("input", { type: "url", value: website, onChange: (e) => setWebsite(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Hiring Locations / Offices" }), _jsx("input", { type: "text", value: location, onChange: (e) => setLocation(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Lead Contact Person" }), _jsx("input", { type: "text", value: contactPerson, onChange: (e) => setContactPerson(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Official Designation" }), _jsx("input", { type: "text", value: designation, onChange: (e) => setDesignation(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "About Organization & Culture" }), _jsx("textarea", { rows: 4, value: aboutCompany, onChange: (e) => setAboutCompany(e.target.value), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsx("div", { className: "pt-3 border-t border-[#DCE3F5] flex justify-end", children: _jsxs("button", { type: "submit", disabled: saving, className: "px-6 py-2.5 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-50", children: [_jsx(Save, { className: "w-4 h-4" }), _jsx("span", { children: saving ? 'Updating...' : 'Save Profile' })] }) })] })] }));
};
