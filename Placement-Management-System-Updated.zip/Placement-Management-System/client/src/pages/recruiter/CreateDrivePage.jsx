import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { PlusCircle } from 'lucide-react';
export const CreateDrivePage = ({ onSelectTab }) => {
    const { user, showToast } = useAuth();
    const [formData, setFormData] = useState({
        jobTitle: '',
        companyName: '',
        jobRole: '',
        jobType: 'Full-Time',
        location: '',
        ctcSalary: '',
        stipend: 'N/A',
        minCgpa: 6.5,
        allowedCourses: [],
        maxBacklogs: 0,
        graduationYear: 2026,
        skillsRequired: '',
        description: '',
        selectionRounds: 'Online Aptitude & Coding Test, Technical Interview, HR Interview',
        applicationDeadline: '',
    });
    const [loading, setLoading] = useState(false);
    const [allowedCourseOther, setAllowedCourseOther] = useState('');
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.jobTitle || !formData.ctcSalary || !formData.description) {
            showToast('Please provide all mandatory drive details.', 'error');
            return;
        }
        setLoading(true);
        try {
            const skills = formData.skillsRequired
                .split(',')
                .map((s) => s.trim())
                .filter(Boolean);
            const rounds = formData.selectionRounds
                .split(',')
                .map((r) => r.trim())
                .filter(Boolean);
            await api.recruiter.createDrive(user?.id || 'usr_recruiter_1', {
                companyName: formData.companyName,
                jobTitle: formData.jobTitle,
                jobRole: formData.jobRole,
                jobType: formData.jobType,
                location: formData.location,
                ctcSalary: formData.ctcSalary,
                stipend: formData.stipend,
                eligibilityCriteria: {
                    minCgpa: Number(formData.minCgpa),
                    allowedCourses: [...formData.allowedCourses, ...(allowedCourseOther.trim() ? [allowedCourseOther.trim()] : [])],
                    maxBacklogs: Number(formData.maxBacklogs),
                    graduationYear: Number(formData.graduationYear),
                },
                skillsRequired: skills,
                description: formData.description,
                selectionRounds: rounds,
                applicationDeadline: formData.applicationDeadline,
                driveDate: new Date().toISOString(),
                status: 'open',
            });
            showToast('Placement drive published successfully! Eligible students can now apply.', 'success');
            onSelectTab('my-drives');
        }
        catch (err) {
            showToast(err.message || 'Failed to create drive', 'error');
        }
        finally {
            setLoading(false);
        }
    };
    const handleToggleCourse = (course) => {
        if (formData.allowedCourses.includes(course)) {
            setFormData({
                ...formData,
                allowedCourses: formData.allowedCourses.filter((c) => c !== course),
            });
        }
        else {
            setFormData({
                ...formData,
                allowedCourses: [...formData.allowedCourses, course],
            });
        }
    };
    return (_jsxs("div", { className: "bg-white rounded-2xl border border-[#DCE3F5] p-6 sm:p-8 shadow-xs max-w-4xl space-y-6", children: [_jsxs("div", { className: "border-b border-[#DCE3F5] pb-4", children: [_jsx("h2", { className: "text-xl font-bold text-[#20245B]", children: "Post a Campus Placement Drive" }), _jsx("p", { className: "text-xs text-[#66739A]", children: "Specify role requirements, compensation, academic eligibility, and selection rounds." })] }), _jsxs("form", { onSubmit: handleSubmit, className: "space-y-6", children: [_jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Job Title / Designation *" }), _jsx("input", { type: "text", required: true, placeholder: "e.g. Associate Software Engineer (Full-Stack)", value: formData.jobTitle, onChange: (e) => setFormData({ ...formData, jobTitle: e.target.value }), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:border-[#3154B8]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Company Name *" }), _jsx("input", { type: "text", required: true, value: formData.companyName, onChange: (e) => setFormData({ ...formData, companyName: e.target.value }), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63] focus:border-[#3154B8]" })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Job Type *" }), _jsxs("select", { value: formData.jobType, onChange: (e) => setFormData({ ...formData, jobType: e.target.value }), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]", children: [_jsx("option", { value: "Full-Time", children: "Full-Time (Direct Hire)" }), _jsx("option", { value: "Part-time", children: "Part-time" }), _jsx("option", { value: "Internship", children: "Internship Only" })] })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "CTC Package (Salary) *" }), _jsx("input", { type: "text", required: true, placeholder: "e.g. 7.5 LPA", value: formData.ctcSalary, onChange: (e) => setFormData({ ...formData, ctcSalary: e.target.value }), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Job Location *" }), _jsx("input", { type: "text", required: true, placeholder: "e.g. Mohali / Gurgaon / Pan India", value: formData.location, onChange: (e) => setFormData({ ...formData, location: e.target.value }), className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] })] }), _jsxs("div", { className: "p-5 rounded-xl bg-[#F5F6FF] border border-[#DCE3F5] space-y-4", children: [_jsx("h3", { className: "font-bold text-xs uppercase tracking-wider text-[#20245B]", children: "Eligibility & Academic Prerequisites" }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Minimum CGPA (0 - 10)" }), _jsx("input", { type: "number", step: "0.1", min: "0", max: "10", value: formData.minCgpa, onChange: (e) => setFormData({ ...formData, minCgpa: parseFloat(e.target.value) || 0 }), className: "w-full px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Maximum Active Backlogs" }), _jsx("input", { type: "number", min: "0", max: "5", value: formData.maxBacklogs, onChange: (e) => setFormData({ ...formData, maxBacklogs: parseInt(e.target.value, 10) || 0 }), className: "w-full px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Application Deadline *" }), _jsx("input", { type: "date", required: true, value: formData.applicationDeadline, onChange: (e) => setFormData({ ...formData, applicationDeadline: e.target.value }), className: "w-full px-3 py-2 bg-white border border-[#DCE3F5] rounded-lg text-xs" })] })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1.5", children: "Eligible Academic Programs (Select all allowed)" }), _jsx("div", { className: "flex flex-wrap gap-2", children: ['BCA', 'MCA', 'B.Tech CSE', 'B.Sc IT', 'M.Sc IT', 'B.Com', 'BBA'].map((c) => {
                                            const isSelected = formData.allowedCourses.includes(c);
                                            return (_jsxs("button", { type: "button", onClick: () => handleToggleCourse(c), className: `px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${isSelected
                                                    ? 'bg-[#3154B8] text-white shadow-2xs'
                                                    : 'bg-white border border-[#DCE3F5] text-[#252B63]'}`, children: [isSelected ? '✓ ' : '+ ', " ", c] }, c));
                                        }) }), _jsx("input", { type: "text", value: allowedCourseOther, onChange: (e) => setAllowedCourseOther(e.target.value), placeholder: "Other — write your own eligible course / program (optional)", className: "mt-3 w-full rounded-lg border border-[#DCE3F5] bg-white px-3 py-2 text-xs" })] })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Required Skills (Comma separated)" }), _jsx("input", { type: "text", value: formData.skillsRequired, onChange: (e) => setFormData({ ...formData, skillsRequired: e.target.value }), placeholder: "e.g. Java, Python, SQL, REST APIs, Git", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Recruitment Selection Rounds (Comma separated)" }), _jsx("input", { type: "text", value: formData.selectionRounds, onChange: (e) => setFormData({ ...formData, selectionRounds: e.target.value }), placeholder: "e.g. Aptitude Test, Technical Interview, HR Interview", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-[#252B63] mb-1", children: "Job Description & Responsibilities *" }), _jsx("textarea", { required: true, rows: 5, value: formData.description, onChange: (e) => setFormData({ ...formData, description: e.target.value }), placeholder: "Provide full description of job role, expected technical stack, learning opportunities, and work culture...", className: "w-full px-3.5 py-2.5 bg-[#F5F6FF] border border-[#DCE3F5] rounded-xl text-xs text-[#252B63]" })] }), _jsxs("div", { className: "pt-4 border-t border-[#DCE3F5] flex items-center justify-between", children: [_jsx("button", { type: "button", onClick: () => onSelectTab('my-drives'), className: "px-4 py-2 rounded-xl border border-[#DCE3F5] text-xs font-semibold text-[#252B63]", children: "Cancel" }), _jsxs("button", { type: "submit", disabled: loading, className: "px-6 py-2.5 rounded-xl bg-[#3154B8] hover:bg-[#4268D5] text-white text-xs font-semibold flex items-center gap-2 shadow-xs cursor-pointer disabled:opacity-50", children: [_jsx(PlusCircle, { className: "w-4 h-4" }), _jsx("span", { children: loading ? 'Publishing Drive...' : 'Publish Campus Drive' })] })] })] })] }));
};
