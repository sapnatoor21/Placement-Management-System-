
import { useEffect } from 'react';

import { AuthProvider, useAuth } from './context/AuthContext';
import { Toast } from './components/common/Toast';
import { AuthModals } from './components/auth/AuthModals';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { DashboardLayout } from './components/layout/DashboardLayout';

// Public pages
import { HomePage } from './pages/public/HomePage';
import { AboutPage } from './pages/public/AboutPage';
import { OpportunitiesPage } from './pages/public/OpportunitiesPage';
import { SuccessStoriesPage } from './pages/public/SuccessStoriesPage';
import { CareerPrepPage } from './pages/public/CareerPrepPage';
import { ResourcesPage } from './pages/public/ResourcesPage';
import { ContactPage } from './pages/public/ContactPage';
import NoticesPage from './pages/public/NoticesPage';

// Student pages
import { StudentDashboard } from './pages/student/StudentDashboard';
import { StudentProfilePage } from './pages/student/StudentProfilePage';
import { StudentApplicationsPage } from './pages/student/StudentApplicationsPage';
import { AptitudeTestPage } from './pages/student/AptitudeTestPage';
import { MockInterviewPage } from './pages/student/MockInterviewPage';
import { ResumeBuilderPage } from './pages/student/ResumeBuilderPage';
import { CodingArenaPage } from './pages/student/CodingArenaPage';
import { CareerGuidancePage } from './pages/student/CareerGuidancePage';
import { NotificationsPage } from './pages/student/NotificationsPage';
import PrivateCloudPage from './pages/student/PrivateCloudPage';
import RemindersPage from './pages/student/RemindersPage';

// Recruiter pages
import { RecruiterDashboard } from './pages/recruiter/RecruiterDashboard';
import { MyDrivesPage } from './pages/recruiter/MyDrivesPage';
import { CreateDrivePage } from './pages/recruiter/CreateDrivePage';
import { ApplicantsPage } from './pages/recruiter/ApplicantsPage';
import { CompanyProfilePage } from './pages/recruiter/CompanyProfilePage';

// Admin pages
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { ManageStudentsPage } from './pages/admin/ManageStudentsPage';
import { ManageRecruitersPage } from './pages/admin/ManageRecruitersPage';
import { ManageAnnouncementsPage } from './pages/admin/ManageAnnouncementsPage';
import { AdminAnalyticsPage } from './pages/admin/AdminAnalyticsPage';
import { ManageResourcesPage } from './pages/admin/ManageResourcesPage';
import { ManageSuccessStoriesPage } from './pages/admin/ManageSuccessStoriesPage';
import { ManagePlacementDrivesPage } from './pages/admin/ManagePlacementDrivesPage';
import { ManageAptitudeQuestionsPage } from './pages/admin/ManageAptitudeQuestionsPage';
import { ManageEnquiriesPage } from './pages/admin/ManageEnquiriesPage';
import ManageSiteSettingsPage from './pages/admin/ManageSiteSettingsPage';
import StaffEmailPage from './pages/shared/StaffEmailPage';

function AppContent() {
  const {
    currentRoute,
    navigate,
    user,
    isLoading,
  } = useAuth();

  // Redirect to the correct dashboard when a user is logged in
  useEffect(() => {
    if (isLoading || !user) return;

    const role = user.role?.toLowerCase();

    const dashboardRoutes = {
      student: 'student/dashboard',
      recruiter: 'recruiter/dashboard',
      admin: 'admin/dashboard',
    };

    const requiredRole = currentRoute.startsWith('student/')
      ? 'student'
      : currentRoute.startsWith('recruiter/')
        ? 'recruiter'
        : currentRoute.startsWith('admin/')
          ? 'admin'
          : null;

    // Prevent users from opening another role's dashboard
    if (requiredRole && requiredRole !== role) {
      navigate(dashboardRoutes[role] || 'home');
      return;
    }

    // If logged-in user opens home or login-related public page,
    // take them directly to their dashboard.
    if (
      !requiredRole &&
      ['home', 'login', 'signin', 'sign-in'].includes(currentRoute)
    ) {
      navigate(dashboardRoutes[role] || 'home');
    }
  }, [currentRoute, user, isLoading, navigate]);

  // Consistent Enter-key behavior: submit the nearest form, while preserving multiline textareas.
  useEffect(() => {
    const onEnter = (event) => {
      if (event.key !== 'Enter' || event.shiftKey || event.isComposing) return;
      const target = event.target;
      if (!(target instanceof HTMLElement) || target.tagName === 'TEXTAREA' || target.isContentEditable) return;
      if (target.tagName === 'BUTTON' || target.tagName === 'SELECT') return;
      const form = target.closest('form');
      if (!form) return;
      const submitter = form.querySelector('button[type="submit"],input[type="submit"]');
      if (submitter && !submitter.disabled) { event.preventDefault(); form.requestSubmit(submitter); }
    };
    document.addEventListener('keydown', onEnter);
    return () => document.removeEventListener('keydown', onEnter);
  }, []);

  // Wait until saved login session is restored
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6FF]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600 mx-auto mb-3"></div>
          <p className="text-sm text-gray-600">
            Loading your Placement Management System Portal...
          </p>
        </div>
      </div>
    );
  }

  const protectedRoute =
    currentRoute.startsWith('student/') ||
    currentRoute.startsWith('recruiter/') ||
    currentRoute.startsWith('admin/');

  // Protect dashboards from users who are not logged in
  if (protectedRoute && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6FF]">
        <p className="text-gray-600">
          Please sign in to access your dashboard.
        </p>
      </div>
    );
  }

  // Student portal
  if (currentRoute.startsWith('student/')) {
    const tab = currentRoute.replace('student/', '');

    const handleSelectTab = (newTab) => {
      navigate(`student/${newTab}`);
    };

    let title = 'Student Placement Dashboard';
    let subtitle = 'Welcome to your verified career portal';
    let content = <StudentDashboard onSelectTab={handleSelectTab} />;

    if (tab === 'profile') {
      title = 'Student Profile & Transcripts';
      subtitle = 'Manage academic details, CGPA, skills, certifications, and projects';
      content = <StudentProfilePage />;
    } else if (tab === 'applications') {
      title = 'My Placement Applications';
      subtitle = 'Track round progress, reviews, and scheduled interview meetings';
      content = <StudentApplicationsPage onSelectTab={handleSelectTab} />;
    } else if (tab === 'drives') {
      title = 'Active Placement Drives';
      subtitle = 'Verified on-campus and virtual hiring drives for your batch';
      content = <OpportunitiesPage />;
    } else if (tab === 'aptitude') {
      title = 'Aptitude Practice Diagnostic';
      subtitle = 'Timed quantitative and logical reasoning simulation with real scoring';
      content = <AptitudeTestPage />;
    } else if (tab === 'mock-interview') {
      title = 'Simulated Mock Interviews';
      subtitle = 'Practice HR and technical questions with structured preparation guidance';
      content = <MockInterviewPage />;
    } else if (tab === 'resume-builder') {
      title = 'ATS Resume Builder';
      subtitle = 'Editable collegiate resume format with print-to-PDF';
      content = <ResumeBuilderPage />;
    } else if (tab === 'coding-arena') {
      title = 'Coding & DSA Arena';
      subtitle = 'Practice algorithm problems; secure code execution requires Judge0 setup';
      content = <CodingArenaPage />;
    } else if (tab === 'resources') {
      title = 'Placement Resource Library';
      subtitle = 'Download formula sheets, company syllabi, and technical handbooks';
      content = <ResourcesPage />;
    } else if (tab === 'career-guidance') {
      title = 'Placement Guidance & Strategy';
      subtitle = '4-phase preparation roadmap for competitive campus placements';
      content = <CareerGuidancePage />;
    } else if (tab === 'private-cloud') {
      title = 'Personal Private Cloud';
      subtitle = 'Your private files, secure sharing and complete file history';
      content = <PrivateCloudPage />;
    } else if (tab === 'reminders') {
      title = 'Preparation Reminders';
      subtitle = 'Manage deadlines and receive weekly preparation reports';
      content = <RemindersPage />;
    } else if (tab === 'notifications') {
      title = 'Notifications & Alerts';
      subtitle = 'Official updates regarding your applications and interview calls';
      content = <NotificationsPage />;
    } else if (tab === 'settings') {
      title = 'Account Security & Settings';
      subtitle = 'Manage your password and security credentials';
      content = <StudentProfilePage />;
    }

    return (
      <DashboardLayout
        currentTab={tab}
        onSelectTab={handleSelectTab}
        title={title}
        subtitle={subtitle}
      >
        {content}
      </DashboardLayout>
    );
  }

  // Recruiter portal
  if (currentRoute.startsWith('recruiter/')) {
    const tab = currentRoute.replace('recruiter/', '');

    const handleSelectTab = (newTab) => {
      navigate(`recruiter/${newTab}`);
    };

    let title = 'Recruiter Dashboard';
    let subtitle = 'Corporate placement console for Kanya Maha Vidyalaya';
    let content = <RecruiterDashboard onSelectTab={handleSelectTab} />;

    if (tab === 'my-drives') {
      title = 'My Placement Drives';
      subtitle = 'Manage, edit, or close corporate recruitment drives';
      content = <MyDrivesPage onSelectTab={handleSelectTab} />;
    } else if (tab === 'create-drive') {
      title = 'Create Placement Drive';
      subtitle = 'Define role, package, eligibility criteria, and interview rounds';
      content = <CreateDrivePage onSelectTab={handleSelectTab} />;
    } else if (
      tab === 'applicants' ||
      tab === 'shortlisted' ||
      tab === 'all-applications'
    ) {
      title = 'Candidate Screening & Shortlisting';
      subtitle = 'Review student academic transcripts, projects, and schedule interviews';
      content = <ApplicantsPage />;
    } else if (tab === 'email-center') {
      title = 'Email Students';
      subtitle = 'Send official recruitment communication to students who applied to your company drives';
      content = <StaffEmailPage />;
    } else if (tab === 'company-profile' || tab === 'settings') {
      title = 'Corporate Profile';
      subtitle = 'Update company details, logo, and hiring coordinator contact';
      content = <CompanyProfilePage />;
    }

    return (
      <DashboardLayout
        currentTab={tab}
        onSelectTab={handleSelectTab}
        title={title}
        subtitle={subtitle}
      >
        {content}
      </DashboardLayout>
    );
  }

  // Admin portal
  if (currentRoute.startsWith('admin/')) {
    const tab = currentRoute.replace('admin/', '');

    const handleSelectTab = (newTab) => {
      navigate(`admin/${newTab}`);
    };

    let title = 'Placement Cell Administration';
    let subtitle = 'Institutional management console for Placement Management System';
    let content = <AdminDashboard onSelectTab={handleSelectTab} />;

    if (tab === 'students') {
      title = 'Student Records & Eligibility';
      subtitle = 'Manage student accounts, verify CGPA transcripts, and provision logins';
      content = <ManageStudentsPage />;
    } else if (tab === 'recruiters') {
      title = 'Recruiter Partner Accounts';
      subtitle = 'Manage corporate partner credentials and drive privileges';
      content = <ManageRecruitersPage />;
    } else if (tab === 'placement-drives') {
      title = 'Institutional Placement Drives';
      subtitle = 'Create and manage campus recruitment drives';
      content = <ManagePlacementDrivesPage />;
    } else if (tab === 'applications') {
      title = 'Universal Applications Monitor';
      subtitle = 'All student applications across all active drives';
      content = <ApplicantsPage />;
    } else if (tab === 'site-settings') {
      title = 'Public Website Settings';
      subtitle = 'Manage the footer contact details and interactive campus map';
      content = <ManageSiteSettingsPage />;
    } else if (tab === 'email-center') {
      title = 'Official Email Center';
      subtitle = 'Send messages to students and review the communication history';
      content = <StaffEmailPage />;
    } else if (tab === 'enquiries') {
      title = 'Official Enquiries';
      subtitle = 'Review and manage messages submitted through the public website';
      content = <ManageEnquiriesPage />;
    } else if (tab === 'announcements') {
      title = 'Circulars & Announcements';
      subtitle = 'Publish official circulars, drive dates, and policy notices';
      content = <ManageAnnouncementsPage />;
    } else if (tab === 'resources') {
      title = 'Placement Resources Management';
      subtitle = 'Upload, publish and manage downloadable study materials';
      content = <ManageResourcesPage />;
    } else if (tab === 'aptitude-questions') {
      title = 'Aptitude Question Bank';
      subtitle = 'Manage published practice questions and answer explanations';
      content = <ManageAptitudeQuestionsPage />;
    } else if (tab === 'success-stories') {
      title = 'Success Stories Verification';
      subtitle = 'Review placement evidence before public verification';
      content = <ManageSuccessStoriesPage />;
    } else if (tab === 'analytics' || tab === 'settings') {
      title = 'Comprehensive Placement Analytics';
      subtitle = 'Real database metrics, NAAC reports, and cohort placement rates';
      content = <AdminAnalyticsPage />;
    }

    return (
      <DashboardLayout
        currentTab={tab}
        onSelectTab={handleSelectTab}
        title={title}
        subtitle={subtitle}
      >
        {content}
      </DashboardLayout>
    );
  }

  // Public website routing
  const renderPublicPage = () => {
    switch (currentRoute) {
      case 'about':
        return <AboutPage onNavigate={navigate} />;

      case 'opportunities':
      case 'drives':
        return <OpportunitiesPage />;

      case 'stories':
        return <SuccessStoriesPage />;

      case 'career-prep':
        return <CareerPrepPage onNavigate={navigate} />;

      case 'resources':
        return <ResourcesPage />;

      case 'contact':
        return <ContactPage />;

      case 'notices':
        return <NoticesPage />;

      case 'home':
      default:
        return <HomePage onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F6FF] text-[#252B63]">
      <Navbar activePage={currentRoute} onNavigate={navigate} />
      <main className="flex-1">
        {renderPublicPage()}
      </main>
      <Footer onNavigate={navigate} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
      <Toast />
      <AuthModals />
    </AuthProvider>
  );
}
