import React from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard, User, Briefcase, FileText, CheckSquare, Video, Lock,
  FileSpreadsheet, BookOpen, Compass, Code2, Bell, Settings, LogOut,
  PlusCircle, Users, Building, BarChart3, Megaphone, Layers, GraduationCap,
  X, Mail
} from 'lucide-react';

const navByRole = {
  student: [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'profile', label: 'My Profile', icon: User },
    { id: 'drives', label: 'Placement Drives', icon: Briefcase },
    { id: 'applications', label: 'My Applications', icon: FileSpreadsheet },
    { id: 'aptitude', label: 'Aptitude Practice', icon: CheckSquare },
    { id: 'mock-interview', label: 'Mock Interview', icon: Video },
    { id: 'resume-builder', label: 'Resume Builder', icon: FileText },
    { id: 'coding-arena', label: 'Coding Arena', icon: Code2 },
    { id: 'career-guidance', label: 'Career Guidance', icon: Compass },
    { id: 'reminders', label: 'Reminders & Reports', icon: Bell },
    { id: 'private-cloud', label: 'Personal Cloud', icon: Lock },
    { id: 'resources', label: 'Resources', icon: BookOpen },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'settings', label: 'Settings', icon: Settings },
  ],
  recruiter: [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'my-drives', label: 'My Drives', icon: Briefcase },
    { id: 'create-drive', label: 'Create Drive', icon: PlusCircle },
    { id: 'applicants', label: 'Applicants', icon: Users },
    { id: 'email-center', label: 'Email Students', icon: Mail },
    { id: 'shortlisted', label: 'Shortlisted', icon: CheckSquare },
    { id: 'all-applications', label: 'All Applications', icon: FileSpreadsheet },
    { id: 'company-profile', label: 'Company Profile', icon: Building },
    { id: 'settings', label: 'Settings', icon: Settings },
  ],
  admin: [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'recruiters', label: 'Recruiters', icon: Building },
    { id: 'placement-drives', label: 'Placement Drives', icon: Briefcase },
    { id: 'applications', label: 'Applications', icon: FileSpreadsheet },
    { id: 'enquiries', label: 'Official Enquiries', icon: Mail },
    { id: 'email-center', label: 'Email Center', icon: Mail },
    { id: 'site-settings', label: 'Website Settings', icon: Settings },
    { id: 'announcements', label: 'Announcements', icon: Megaphone },
    { id: 'resources', label: 'Resources', icon: Layers },
    { id: 'success-stories', label: 'Success Stories', icon: GraduationCap },
    { id: 'aptitude-questions', label: 'Question Bank', icon: CheckSquare },
    { id: 'analytics', label: 'Analytics & Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ],
};

export const Sidebar = ({ currentTab, onSelectTab, onCloseMobile }) => {
  const { user, logout, navigate } = useAuth();
  const role = user?.role || 'student';
  const items = navByRole[role] || navByRole.student;
  const initials = (user?.name || 'KMV').split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase();
  const select = (id) => { onSelectTab(id); onCloseMobile?.(); };

  return (
    <aside className="kmv-sidebar flex h-full min-h-screen w-64 flex-col justify-between">
      <div>
        <div className="flex h-[82px] items-center gap-3 border-b border-white/10 px-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-[#20245B]"><GraduationCap size={23}/></div>
          <div className="min-w-0">
            <p className="truncate text-[12px] font-extrabold tracking-wide text-white">PLACEMENT MANAGEMENT SYSTEM</p>
            <p className="mt-0.5 text-[8px] leading-tight font-medium text-indigo-200">An Integrated Platform for Campus Recruitment and Career Development</p>
            <p className="mt-1 text-[10px] font-medium text-indigo-200">{role.toUpperCase()} PORTAL</p>
          </div>
          {onCloseMobile && <button onClick={onCloseMobile} className="ml-auto rounded-lg p-1.5 text-indigo-100 hover:bg-white/10" aria-label="Close menu"><X size={17}/></button>}
        </div>
        <div className="px-3 pb-5 pt-4">
          <p className="kmv-sidebar-caption">Workspace</p>
          <nav className="space-y-1" aria-label={`${role} navigation`}>
            {items.map(({id,label,icon:Icon}) => (
              <button key={id} onClick={() => select(id)} aria-current={currentTab === id ? 'page' : undefined} className="kmv-sidebar-link">
                <Icon/><span className="truncate">{label}</span>
                {id === 'notifications' && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sky-300"/>}
              </button>
            ))}
          </nav>
        </div>
      </div>
      <div className="border-t border-white/10 p-4">
        <div className="flex items-center gap-3 rounded-xl bg-white/8 p-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#dfe5ff] text-xs font-extrabold text-[#20245B]">{initials}</div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-bold text-white">{user?.name || 'User'}</p>
            <p className="truncate text-[10px] text-indigo-200">{user?.email || role}</p>
          </div>
          <button onClick={logout} title="Log out" aria-label="Log out" className="rounded-lg p-2 text-indigo-200 hover:bg-white/10 hover:text-white"><LogOut size={16}/></button>
        </div>
        <p className="mt-3 text-center text-[9px] text-indigo-300/70">Kanya Maha Vidyalaya · Est. 1886</p>
      </div>
    </aside>
  );
};
