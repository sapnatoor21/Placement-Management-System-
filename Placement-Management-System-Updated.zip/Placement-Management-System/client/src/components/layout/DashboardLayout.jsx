import React, { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Sidebar } from './Sidebar';
import { Menu, Bell, Globe, Check, X, ChevronRight, GraduationCap } from 'lucide-react';
import { api } from '../../services/api';
import { io } from 'socket.io-client';

export const DashboardLayout = ({ currentTab, onSelectTab, title, subtitle, children, actions }) => {
  const { user, navigate } = useAuth();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    let active = true;
    async function loadNotifications() {
      try {
        const items = await api.notifications.getMyNotifications(user?.id || user?._id);
        if (active && Array.isArray(items)) setNotifications(items);
      } catch (error) {
        console.error('Could not load notifications:', error);
        if (active) setNotifications([]);
      }
    }
    if (user?.id || user?._id) void loadNotifications();
    else setNotifications([]);
    return () => { active = false; };
  }, [user?.id, user?._id]);

  useEffect(() => {
    const token = localStorage.getItem('kmv_placement_auth_token');
    if (!token || !user?._id && !user?.id) return;
    const apiUrl = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/api\/?$/, '');
    const socket = io(apiUrl, { auth: { token }, transports: ['websocket', 'polling'], reconnection: true });
    socket.on('notification:new', (notification) => setNotifications((items) => [notification, ...items.filter((item) => String(item._id || item.id) !== String(notification._id || notification.id))]));
    socket.on('application:updated', () => api.notifications.getMyNotifications().then(setNotifications).catch(() => {}));
    return () => socket.disconnect();
  }, [user?._id, user?.id]);

  const unreadCount = useMemo(() => notifications.filter((item) => !(item.isRead ?? item.read)).length, [notifications]);
  const markRead = async (id) => {
    try {
      await api.notifications.markRead(id);
      setNotifications((items) => items.map((item) => String(item.id || item._id) === String(id) ? { ...item, read: true, isRead: true } : item));
    } catch (error) { console.error('Could not mark notification as read:', error); }
  };

  const roleLabel = (user?.role || 'student').toUpperCase();
  return (
    <div className="kmv-app-shell flex min-h-screen">
      <div className="sticky top-0 hidden h-screen shrink-0 lg:block"><Sidebar currentTab={currentTab} onSelectTab={onSelectTab}/></div>
      {mobileSidebarOpen && <div className="fixed inset-0 z-50 flex lg:hidden">
        <button aria-label="Close navigation" className="absolute inset-0 bg-[#10143f]/60 backdrop-blur-[2px]" onClick={() => setMobileSidebarOpen(false)}/>
        <div className="relative z-10 h-full max-w-[86vw] shadow-2xl"><Sidebar currentTab={currentTab} onSelectTab={onSelectTab} onCloseMobile={() => setMobileSidebarOpen(false)}/></div>
      </div>}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="kmv-topbar sticky top-0 z-30 flex min-h-[72px] items-center justify-between px-4 sm:px-7">
          <div className="flex min-w-0 items-center gap-3">
            <button onClick={() => setMobileSidebarOpen(true)} className="rounded-xl border border-[#e2e6f3] p-2 text-[#20245B] hover:bg-[#f4f5fc] lg:hidden" aria-label="Open navigation"><Menu size={19}/></button>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eef0ff] text-[#3154b8] sm:hidden"><GraduationCap size={19}/></div>
            <div className="min-w-0">
              <p className="truncate text-[11px] font-extrabold tracking-[.12em] text-[#20245B]">PLACEMENT MANAGEMENT SYSTEM</p>
              <p className="mt-0.5 text-[8px] leading-tight font-medium text-[#8791ae]">An Integrated Platform for Campus Recruitment and Career Development</p>
              <p className="mt-0.5 text-[10px] font-medium text-[#8791ae]">{roleLabel} WORKSPACE</p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <button onClick={() => navigate('home')} className="hidden items-center gap-2 rounded-lg border border-[#e1e5f1] px-3 py-2 text-[11px] font-bold text-[#46527f] hover:border-[#bfc9eb] hover:bg-[#f8f9ff] sm:flex"><Globe size={14}/> Public Website</button>
            <div className="relative">
              <button onClick={() => setNotifOpen((v) => !v)} className="relative rounded-xl border border-[#e1e5f1] p-2.5 text-[#4c5680] hover:bg-[#f7f8ff]" aria-label="Notifications" aria-expanded={notifOpen}>
                <Bell size={17}/>{unreadCount > 0 && <span className="absolute -right-1 -top-1 flex h-[17px] min-w-[17px] items-center justify-center rounded-full bg-[#e34d6b] px-1 text-[9px] font-extrabold text-white">{unreadCount}</span>}
              </button>
              {notifOpen && <div className="absolute right-0 mt-3 w-[min(360px,90vw)] rounded-2xl border border-[#e0e4f1] bg-white p-4 shadow-2xl">
                <div className="flex items-center justify-between border-b border-[#edf0f7] pb-3"><div><p className="text-sm font-extrabold text-[#20245B]">Notifications</p><p className="mt-0.5 text-[10px] text-[#8791ae]">Your latest portal updates</p></div><button onClick={() => setNotifOpen(false)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100" aria-label="Close"><X size={16}/></button></div>
                <div className="mt-2 max-h-72 divide-y divide-[#edf0f7] overflow-y-auto">
                  {notifications.length === 0 ? <p className="py-8 text-center text-xs text-[#8791ae]">No notifications yet.</p> : notifications.map((item, index) => {
                    const id = item.id || item._id || `notification-${index}`;
                    return <div key={String(id)} className={`flex items-start gap-3 py-3 ${(item.isRead ?? item.read) ? 'opacity-65' : ''}`}><span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-[#526bc4]"/><div className="min-w-0 flex-1"><p className="text-xs font-bold text-[#30396f]">{item.title}</p><p className="mt-1 text-[11px] leading-relaxed text-[#7380a2]">{item.message}</p>{item.createdAt && <p className="mt-1 text-[10px] text-[#a1a9bf]">{new Date(item.createdAt).toLocaleDateString()}</p>}</div>{!(item.isRead ?? item.read) && <button onClick={() => markRead(id)} title="Mark as read" className="rounded-md p-1 text-[#3154b8] hover:bg-[#eef0ff]"><Check size={14}/></button>}</div>;
                  })}
                </div>
              </div>}
            </div>
            <div className="flex items-center gap-2 border-l border-[#e4e7f1] pl-3 sm:pl-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-[#d9def3] bg-[#eef0ff] text-xs font-extrabold text-[#3154b8]">{(user?.name || 'S').charAt(0).toUpperCase()}</div>
              <div className="hidden max-w-[150px] sm:block"><p className="truncate text-xs font-extrabold text-[#30396f]">{user?.name || 'User'}</p><p className="mt-0.5 text-[10px] capitalize text-[#8791ae]">{user?.role || 'student'}</p></div>
            </div>
          </div>
        </header>
        <section className="kmv-page-heading px-4 py-5 sm:px-7 sm:py-6">
          <div className="kmv-content flex flex-col justify-between gap-3 md:flex-row md:items-center">
            <div className="min-w-0"><div className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[.13em] text-[#929bb5]"><span>Workspace</span><ChevronRight size={12}/><span className="text-[#5263a2]">{currentTab.replaceAll('-', ' ')}</span></div><h1 className="kmv-mobile-heading text-[25px] font-extrabold leading-tight text-[#20245B] sm:text-[28px]">{title}</h1>{subtitle && <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-[#7883a4] sm:text-[13px]">{subtitle}</p>}</div>
            {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
          </div>
        </section>
        <main className="kmv-content w-full flex-1 px-4 py-5 sm:px-7 sm:py-7">{children}</main>
        <footer className="border-t border-[#e2e6f1] bg-white/70 px-4 py-3 text-center text-[10px] text-[#9aa3ba] sm:px-7">Placement Management System · Kanya Maha Vidyalaya, Jalandhar · Est. 1886</footer>
      </div>
    </div>
  );
};
