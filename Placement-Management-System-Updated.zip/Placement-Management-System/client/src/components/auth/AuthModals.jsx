import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Modal } from '../common/Modal';
import { Login } from './Login';
import { Lock, Mail, User as UserIcon, Phone, GraduationCap, Building2, Eye, EyeOff } from 'lucide-react';

const fieldClass = 'w-full rounded-lg border border-[#DCE3F5] bg-white px-3 py-2.5 text-sm text-[#252B63] placeholder:text-[#66739A] focus:border-[#3154B8] focus:outline-none';

const courses = [
  ['BCA', 'Bachelor of Computer Applications (BCA)'],
  ['MCA', 'Master of Computer Applications (MCA)'],
  ['B.Tech CSE', 'B.Tech Computer Science & Engineering'],
  ['B.Sc IT', 'B.Sc Information Technology'],
  ['M.Sc IT', 'M.Sc Information Technology'],
  ['B.Com', 'B.Com'],
  ['BBA', 'Bachelor of Business Administration (BBA)'],
  ['B.Voc', 'Bachelor of Vocation (B.Voc)'],
  ['B.Sc', 'Bachelor of Science (B.Sc)'],
  ['M.Sc', 'Master of Science (M.Sc)'],
  ['BA', 'Bachelor of Arts (BA)'],
  ['M.Com', 'Master of Commerce (M.Com)'],
];

export const AuthModals = () => {
  const { authModal, setAuthModal, login, loginWithOTP, registerStudent } = useAuth();
  const [regData, setRegData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    course: '',
    semester: '',
    enrollmentNumber: '',
    collegeName: 'Kanya Maha Vidyalaya, Jalandhar',
    termsAccepted: false,
  });
  const [courseOther, setCourseOther] = useState('');
  const [semesterOther, setSemesterOther] = useState('');
  const [showRegPass, setShowRegPass] = useState(false);
  const [regLoading, setRegLoading] = useState(false);
  const [regError, setRegError] = useState('');

  const update = (key, value) => setRegData((previous) => ({ ...previous, [key]: value }));

  const handleRegSubmit = async (event) => {
    event.preventDefault();
    setRegError('');

    if (!regData.name.trim() || !regData.email.trim() || !regData.phone.trim() || !regData.password || !regData.enrollmentNumber.trim()) {
      setRegError('Please fill in all required fields.');
      return;
    }
    if (regData.password !== regData.confirmPassword) {
      setRegError('Passwords do not match.');
      return;
    }
    if (regData.password.length < 6) {
      setRegError('Password must be at least 6 characters long.');
      return;
    }
    if (regData.course === 'Other' && !courseOther.trim()) {
      setRegError('Please write your course / program.');
      return;
    }
    if (regData.semester === 'Other' && !semesterOther.trim()) {
      setRegError('Please write your semester / year.');
      return;
    }
    if (!regData.termsAccepted) {
      setRegError('You must accept the Placement Management System code of conduct.');
      return;
    }

    setRegLoading(true);
    try {
      await registerStudent({
        ...regData,
        email: regData.email.trim().toLowerCase(),
        course: regData.course === 'Other' ? courseOther.trim() : regData.course,
        semester: regData.semester === 'Other' ? semesterOther.trim() : regData.semester,
      });
    } catch (error) {
      setRegError(error.message || 'Registration failed. Please try again.');
    } finally {
      setRegLoading(false);
    }
  };

  const handleForgotPassword = async (emailValue) => {
    const email = String(emailValue || '').trim().toLowerCase();
    if (!email) {
      window.alert('Enter your registered email address first, then choose Forgot password.');
      return;
    }
    try {
      await api.auth.forgotPassword(email);
      const otp = window.prompt('Enter the password-reset OTP sent to your registered email:');
      if (!otp) return;
      await api.auth.verifyForgotPasswordOTP(email, otp.trim());
      const newPassword = window.prompt('Enter your new password (at least 6 characters):');
      if (!newPassword) return;
      const confirmPassword = window.prompt('Re-enter your new password:');
      if (!confirmPassword) return;
      await api.auth.resetPassword(email, otp.trim(), newPassword, confirmPassword);
      window.alert('Password reset successfully. Sign in using your new password.');
    } catch (error) {
      window.alert(error.message || 'Password reset failed. Please try again.');
    }
  };

  return (
    <>
      <Modal
        isOpen={authModal === 'login'}
        onClose={() => setAuthModal(null)}
        title="Sign In to Placement Management System"
        subtitle="An Integrated Platform for Campus Recruitment and Career Development"
        maxWidth="md"
      >
        <Login
          login={login}
          loginWithOTP={loginWithOTP}
          onForgotPassword={handleForgotPassword}
          onRegister={() => { setRegError(''); setAuthModal('register'); }}
        />
      </Modal>

      <Modal
        isOpen={authModal === 'register'}
        onClose={() => { setAuthModal(null); setRegError(''); }}
        title="Student Registration"
        subtitle="Create your student account to access the placement portal"
        maxWidth="lg"
      >
        {regError && <div className="mb-4 rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700" role="alert">{regError}</div>}
        <form onSubmit={handleRegSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className="block text-xs font-semibold text-[#252B63]">Full Name *
              <span className="relative mt-1 block"><UserIcon className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input className={`${fieldClass} pl-9`} value={regData.name} onChange={(e) => update('name', e.target.value)} placeholder="e.g. Priya Sharma" required/></span>
            </label>
            <label className="block text-xs font-semibold text-[#252B63]">KMV Enrollment / Roll No. *
              <span className="relative mt-1 block"><GraduationCap className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input className={`${fieldClass} pl-9`} value={regData.enrollmentNumber} onChange={(e) => update('enrollmentNumber', e.target.value)} placeholder="e.g. KMV/2025/MCA/001" required/></span>
            </label>
            <label className="block text-xs font-semibold text-[#252B63]">Email Address *
              <span className="relative mt-1 block"><Mail className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input type="email" className={`${fieldClass} pl-9`} value={regData.email} onChange={(e) => update('email', e.target.value)} placeholder="your-email@gmail.com" required/></span>
            </label>
            <label className="block text-xs font-semibold text-[#252B63]">Mobile Number *
              <span className="relative mt-1 block"><Phone className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input type="tel" className={`${fieldClass} pl-9`} value={regData.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+91 98765 00000" required/></span>
            </label>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#252B63]">Course / Program *</label>
              <select required className={fieldClass} value={regData.course} onChange={(e) => update('course', e.target.value)}>
                <option value="" disabled>Select course / program</option>
                {courses.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                <option value="Other">Other — Write your own</option>
              </select>
              {regData.course === 'Other' && <input className={`${fieldClass} mt-2`} value={courseOther} onChange={(e) => setCourseOther(e.target.value)} placeholder="Write your course / program" required/>}
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#252B63]">Current Class / Semester *</label>
              <select required className={fieldClass} value={regData.semester} onChange={(e) => update('semester', e.target.value)}>
                <option value="" disabled>Select class / semester</option>
                {Array.from({ length: 8 }, (_, index) => <option key={index + 1} value={`Semester ${index + 1}`}>Semester {index + 1}</option>)}
                <option value="Other">Other — Write your own</option>
              </select>
              {regData.semester === 'Other' && <input className={`${fieldClass} mt-2`} value={semesterOther} onChange={(e) => setSemesterOther(e.target.value)} placeholder="Write your class / semester / year" required/>}
            </div>
          </div>

          <label className="block text-xs font-semibold text-[#252B63]">College Name
            <span className="relative mt-1 block"><Building2 className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input className={`${fieldClass} bg-slate-50 pl-9`} value={regData.collegeName} readOnly/></span>
          </label>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className="block text-xs font-semibold text-[#252B63]">Password (minimum 6 characters) *
              <span className="relative mt-1 block"><Lock className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input type={showRegPass ? 'text' : 'password'} className={`${fieldClass} pl-9 pr-10`} value={regData.password} onChange={(e) => update('password', e.target.value)} placeholder="Create password" required/><button type="button" onClick={() => setShowRegPass((value) => !value)} className="absolute right-3 top-2.5 text-[#66739A]" aria-label="Show or hide password">{showRegPass ? <EyeOff size={16}/> : <Eye size={16}/>}</button></span>
            </label>
            <label className="block text-xs font-semibold text-[#252B63]">Confirm Password *
              <span className="relative mt-1 block"><Lock className="absolute left-3 top-3 h-4 w-4 text-[#66739A]"/><input type={showRegPass ? 'text' : 'password'} className={`${fieldClass} pl-9`} value={regData.confirmPassword} onChange={(e) => update('confirmPassword', e.target.value)} placeholder="Confirm password" required/></span>
            </label>
          </div>

          <label className="flex items-start gap-2.5 rounded-lg border border-[#DCE3F5] bg-[#F5F6FF] p-3 text-xs leading-5 text-[#252B63]">
            <input type="checkbox" className="mt-1" checked={regData.termsAccepted} onChange={(e) => update('termsAccepted', e.target.checked)}/>
            <span>I confirm that the details provided are correct and agree to follow the Placement Management System rules and placement guidelines.</span>
          </label>

          <button type="submit" disabled={regLoading} className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#3154B8] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#25469e] disabled:cursor-not-allowed disabled:opacity-60">
            {regLoading ? 'Creating account…' : 'Create Account & Sign In'}
          </button>
          <p className="text-center text-xs text-[#66739A]">Already registered? <button type="button" onClick={() => setAuthModal('login')} className="font-semibold text-[#3154B8] hover:underline">Sign in here</button></p>
        </form>
      </Modal>
    </>
  );
};
