import React, { useState } from 'react';
import { Mail, Lock, ShieldCheck, Eye, EyeOff } from 'lucide-react';
import { api } from '../../services/api';
import './Login.css';

export const Login = ({ login, loginWithOTP, onForgotPassword, onRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [mode, setMode] = useState('password');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const changeMode = (nextMode) => {
    setMode(nextMode);
    setOtpSent(false);
    setOtp('');
    setError('');
    setNotice('');
  };

  const requestOTP = async () => {
    if (!email.trim()) {
      setError('Enter your registered email address first.');
      return;
    }
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const result = await api.auth.sendLoginOTP(email.trim().toLowerCase());
      setOtpSent(true);
      setNotice(result.message || 'A 6-digit OTP has been sent to your email address.');
    } catch (e) {
      setError(e.message || 'Unable to send email OTP. Check email configuration.');
    } finally {
      setBusy(false);
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    setNotice('');
    try {
      if (mode === 'otp') {
        if (!/^\d{6}$/.test(otp.trim())) throw new Error('Enter the 6-digit OTP sent to your email.');
        await loginWithOTP(email.trim().toLowerCase(), otp.trim());
      } else {
        if (!email.trim() || !password) throw new Error('Enter your email and password.');
        await login(email.trim().toLowerCase(), password);
      }
    } catch (e2) {
      setError(e2.message || 'Sign in failed.');
    } finally {
      setBusy(false);
    }
  };

  return <div className="kmv-login">
    <div className="kmv-login-tabs">
      <button type="button" className={mode === 'password' ? 'active' : ''} onClick={() => changeMode('password')}>Password</button>
      <button type="button" className={mode === 'otp' ? 'active' : ''} onClick={() => changeMode('otp')}>Email OTP</button>
    </div>
    {error && <p className="kmv-login-error" role="alert">{error}</p>}
    {notice && <p className="kmv-login-notice" role="status">{notice}</p>}
    <form onSubmit={submit} className="space-y-4">
      <label className="block text-xs font-semibold text-[#252B63]">Email address
        <span className="kmv-login-input"><Mail size={16}/><input type="email" value={email} onChange={(e) => { setEmail(e.target.value); setOtpSent(false); }} placeholder="you@example.com" autoComplete="email" required/></span>
      </label>
      {mode === 'password' ? <label className="block text-xs font-semibold text-[#252B63]">Password
        <span className="kmv-login-input"><Lock size={16}/><input type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" autoComplete="current-password" required/><button type="button" onClick={() => setShowPassword((v) => !v)} aria-label="Show or hide password">{showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}</button></span>
      </label> : <label className="block text-xs font-semibold text-[#252B63]">6-digit email OTP
        <span className="kmv-login-input"><ShieldCheck size={16}/><input inputMode="numeric" pattern="[0-9]{6}" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))} placeholder="Enter OTP" required/></span>
      </label>}
      {mode === 'password' ? <button type="submit" disabled={busy} className="kmv-login-primary">{busy ? 'Signing in…' : 'Sign In'}</button> : <div className="grid grid-cols-2 gap-2"><button type="button" onClick={requestOTP} disabled={busy} className="kmv-login-secondary">{busy ? 'Sending…' : otpSent ? 'Resend OTP' : 'Send OTP'}</button><button type="submit" disabled={busy || !otpSent} className="kmv-login-primary">{busy ? 'Verifying…' : 'Verify & Sign In'}</button></div>}
    </form>
    {mode === 'password' && <button type="button" onClick={() => onForgotPassword(email)} className="mt-3 text-xs font-semibold text-[#3154B8] hover:underline">Forgot password?</button>}
    <div className="mt-5 border-t border-[#DCE3F5] pt-4 text-center text-xs text-[#66739A]">New student? <button type="button" onClick={onRegister} className="font-semibold text-[#3154B8] hover:underline">Register here</button></div>
    <p className="mt-3 text-[11px] leading-5 text-slate-500">Sign in using your registered email and password, or request a one-time verification code by email.</p>
  </div>;
};
