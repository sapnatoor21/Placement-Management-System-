import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useEffect } from 'react';
import { X } from 'lucide-react';
export const Modal = ({ isOpen, onClose, title, subtitle, children, maxWidth = 'md', }) => {
    useEffect(() => {
        const handleEsc = (e) => {
            if (e.key === 'Escape')
                onClose();
        };
        if (isOpen) {
            document.body.style.overflow = 'hidden';
            window.addEventListener('keydown', handleEsc);
        }
        return () => {
            document.body.style.overflow = 'unset';
            window.removeEventListener('keydown', handleEsc);
        };
    }, [isOpen, onClose]);
    if (!isOpen)
        return null;
    const widthClass = {
        sm: 'max-w-sm',
        md: 'max-w-md',
        lg: 'max-w-lg',
        xl: 'max-w-xl',
        '2xl': 'max-w-2xl',
    }[maxWidth];
    return (_jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto", children: _jsxs("div", { className: `relative w-full ${widthClass} bg-white rounded-2xl border border-[#DCE3F5] shadow-2xl p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-150 my-8`, children: [_jsxs("div", { className: "flex items-start justify-between pb-4 border-b border-[#DCE3F5]", children: [_jsxs("div", { children: [_jsx("h3", { className: "text-xl font-bold text-[#252B63]", children: title }), subtitle && _jsx("p", { className: "text-xs text-[#66739A] mt-1", children: subtitle })] }), _jsx("button", { onClick: onClose, className: "p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors", children: _jsx(X, { className: "w-5 h-5" }) })] }), _jsx("div", { className: "mt-5", children: children })] }) }));
};
