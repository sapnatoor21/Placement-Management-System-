import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
export const Badge = ({ children, variant = 'primary', size = 'sm' }) => {
    const styles = {
        primary: 'bg-[#3154B8]/10 text-[#3154B8] border-[#3154B8]/25',
        secondary: 'bg-[#4268D5]/10 text-[#4268D5] border-[#4268D5]/20',
        success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        warning: 'bg-amber-50 text-amber-700 border-amber-200',
        danger: 'bg-rose-50 text-rose-700 border-rose-200',
        navy: 'bg-[#20245B] text-white border-[#20245B]',
        neutral: 'bg-slate-100 text-slate-700 border-slate-200',
    }[variant];
    const sizeStyles = {
        sm: 'text-xs px-2.5 py-0.5',
        md: 'text-sm px-3 py-1',
    }[size];
    return (_jsx("span", { className: `inline-flex items-center font-medium rounded-full border ${styles} ${sizeStyles}`, children: children }));
};
export const StatusBadge = ({ status }) => {
    const normalized = status.toLowerCase();
    if (normalized === 'applied' || normalized === 'under_review') {
        return _jsx(Badge, { variant: "secondary", children: "Applied" });
    }
    if (normalized === 'shortlisted') {
        return _jsx(Badge, { variant: "primary", children: "Shortlisted" });
    }
    if (normalized === 'assessment_round') {
        return _jsx(Badge, { variant: "warning", children: "Assessment Round" });
    }
    if (normalized === 'interview_scheduled') {
        return _jsx(Badge, { variant: "warning", children: "Interview Scheduled" });
    }
    if (normalized === 'selected' || normalized === 'placed' || normalized === 'verified') {
        return _jsx(Badge, { variant: "success", children: "Selected / Placed" });
    }
    if (normalized === 'rejected') {
        return _jsx(Badge, { variant: "danger", children: "Not Shortlisted" });
    }
    if (normalized === 'open') {
        return _jsx(Badge, { variant: "success", children: "Open" });
    }
    if (normalized === 'closed') {
        return _jsx(Badge, { variant: "neutral", children: "Closed" });
    }
    if (normalized === 'upcoming') {
        return _jsx(Badge, { variant: "primary", children: "Upcoming" });
    }
    return _jsx(Badge, { variant: "neutral", children: status });
};
