import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React from 'react';
export const StatCard = ({ title, value, subtitle, icon: Icon, trend, variant = 'blue', }) => {
    const iconTheme = {
        blue: 'bg-[#3154B8]/10 text-[#3154B8]',
        navy: 'bg-[#20245B]/10 text-[#20245B]',
        emerald: 'bg-emerald-50 text-emerald-600',
        amber: 'bg-amber-50 text-amber-600',
    }[variant];
    return (_jsxs("div", { className: "bg-white rounded-xl border border-[#DCE3F5] p-5 shadow-xs hover:border-[#3154B8]/40 transition-all", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("span", { className: "text-xs font-semibold uppercase tracking-wider text-[#66739A]", children: title }), _jsx("div", { className: `p-2.5 rounded-lg ${iconTheme}`, children: _jsx(Icon, { className: "w-5 h-5" }) })] }), _jsxs("div", { className: "mt-3 flex items-baseline gap-2", children: [_jsx("span", { className: "text-2xl lg:text-3xl font-bold text-[#252B63]", children: value }), trend && _jsx("span", { className: "text-xs font-medium text-emerald-600", children: trend })] }), subtitle && _jsx("p", { className: "mt-1 text-xs text-[#66739A]", children: subtitle })] }));
};
