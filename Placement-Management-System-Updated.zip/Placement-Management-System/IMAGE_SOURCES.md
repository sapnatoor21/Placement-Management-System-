# Image source record

No third-party photo files were copied into this archive. The project previously requested authentic KMV campus and placement photographs. A direct downloadable official asset URL and reuse permission could not be verified in this build environment, so this update deliberately avoids copying images from unrelated college directories or copyrighted news publishers.

Official KMV pages linked from the redesigned About page:

- KMV official Placement Cell photo gallery: https://www.kmvjalandhar.ac.in/photo_galleries/placement-cell/
- KMV official Campus Profile: https://www.kmvjalandhar.ac.in/sitepages/campus-profile/
- KMV official institutional website: https://www.kmvjalandhar.ac.in/

Before adding local images, obtain them from KMV's authorized media/website team or confirm the usage terms with the source. Add each downloaded file's source URL, author/attribution, licence/permission and component location to this file.
