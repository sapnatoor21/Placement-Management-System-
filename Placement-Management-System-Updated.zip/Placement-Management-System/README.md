# Placement Management System

**An Integrated Platform for Campus Recruitment and Career Development**

A JavaScript full-stack placement platform with Student, Recruiter and Admin workspaces.

## Stack

- React 19, Vite, Tailwind CSS and Monaco Editor
- Node.js, Express and MongoDB/Mongoose
- JWT authentication, bcrypt password hashing
- Socket.IO notifications
- Gemini API for AI-assisted career guidance, skill-gap analysis and interview feedback
- Cloudinary for uploaded files and resumes
- Judge0 for remote code execution
- Mailjet SMTP for login OTP, password reset and transactional emails

## Setup

1. Install Node.js 20+ (Node 22 recommended).
2. Copy `server/.env.example` to `server/.env`.
3. Add your MongoDB URI and a long random JWT secret. Set `ADMIN_EMAIL=admin@gmail.com`, `ADMIN_PASSWORD=admin123` and `ADMIN_NAME=KMV Placement Cell Admin` for local demo admin access.
4. Add only the provider credentials you intend to use (see Configuration below).
5. In the project root, run `npm install`.
6. Run `npm --prefix client install` and `npm --prefix server install`.
7. Run `npm run dev` from the project root.
8. Open `http://localhost:5173`; API health check is `http://localhost:5000/api/health`.

## Configuration

- **MongoDB:** `MONGODB_URI` is required. Keep a database backup before running migrations.
- **JWT:** `JWT_SECRET` is required and must be private.
- **Gemini:** Set `AI_API_KEY`, `AI_MODEL=gemini-3.8-flash`, and `AI_API_URL=https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent`. Model access depends on your Google AI Studio project. The backend uses the Gemini `generateContent` REST format.
- **Email:** Configure Mailjet SMTP with `SMTP_HOST=in-v3.mailjet.com`, `SMTP_PORT=587`, `SMTP_USER`, `SMTP_PASS`, and a verified `MAIL_FROM` sender. Student registration does not require OTP; Email OTP remains available for sign-in and password reset.
- **Resume/resource uploads:** Configure `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, and `CLOUDINARY_API_SECRET`.
- **CodeForge:** Configure `JUDGE0_API_URL`, `JUDGE0_API_KEY`, and (for RapidAPI) `JUDGE0_API_HOST`.

## Database maintenance

If the database has an old unique index on `studentId` alone in the `applications` collection, it can incorrectly block a student from applying to a second drive. Back up MongoDB, then run:

```bash
cd server
npm run fix:application-index
```

The migration removes only that legacy single-field unique index and ensures a compound unique index on `(studentId, driveId)`. The application controller also checks duplicates by both student and drive.

## Important notes

- Never commit or share `server/.env`. Do not paste API keys, MongoDB credentials, passwords or JWT secrets into chat or GitHub.
- AI suggestions and scores are preparation aids, not official hiring decisions or guarantees.
- The readiness score is an indicative calculation from saved profile and practice data; it is not a probability of getting placed.
- Speech-to-text depends on browser support and microphone permission.
- Real provider flows require the owner's valid credentials and have to be tested in the owner's environment.

## Additional features

- **Student skills:** Profile > Skills & Tools contains separate Technical Skills, Programming Languages and Professional / Soft Skills lists.
- **Personal Cloud:** Student sidebar > Personal Cloud. Requires Cloudinary authenticated raw-file support.
- **Resume Studio:** Student > Resume Builder. Reorder sections, save versions, print to A4 PDF, and create/revoke share links.
- **Reminders and weekly reports:** Student > Reminders & Reports. Requires email delivery and a running API instance.

## Admin account

After copying `server/.env.example` to `server/.env` and setting `ADMIN_EMAIL` and `ADMIN_PASSWORD`, run:

```bash
npm --prefix server run seed:admin
```

For the local demo values in the example file, sign in with `admin@gmail.com` and `admin123`. Change the password before deployment.

To seed the DBMS, OOP and DSA assessment banks (30 questions per category):

```bash
cd server
npm run seed:question-banks
```

The seed is idempotent for matching category/question text and preserves existing questions. Back up your database before seeding.

See [IMPLEMENTATION-STATUS.md](IMPLEMENTATION-STATUS.md) for feature scope, validation performed, and items that still require real-account acceptance testing.
